# Portfolio research archive

Review date: 23 November 2026

Start with `data/website_coverage.csv` for the 115 requested domains or `data/active_investments.csv` for the 1,703 investor–investment rows. Open `outputs/index.html` after extraction to browse the HTML evidence. The delivered Excel workbook is in `outputs/`.

## Coverage and review

- **Verified (78 sites)** means the identifiable public current portfolio was reviewed. Some firms limit what they publish. The source coverage and any additional review flag are shown separately.
- **Partial (30 sites)** means the public record supports only a subset or leaves unresolved status or disclosure questions.
- **Unavailable (7 sites)** means a public current portfolio was not available. Zero extracted rows do not establish zero holdings.
- **Review needed** identifies specific exceptions in `data/review_needed.csv`. It contains 51 firm-level entries and 224 investment-level entries. The two review fields in the investment CSV let you filter a firm-level gap separately from a record-level evidence issue.

The CSVs retain the original status evidence and source URLs. Their review flags distinguish inferences, dates and naming limits without changing the original investment roster.

## Archive layout

- `outputs/` contains the delivered workbook, the HTML index and the evidence files. Local links resolve within this directory. The earlier HTML-only ZIP is expanded here, so it does not need to be unpacked separately.
- `work/` retains scripts, configurations, raw HTML/text/JSON, intermediate extracts, original batch results, validation files and previews in their original paths. Raw and intermediate captures may show exited, historical, duplicated, blocked or superseded material. The consolidated CSVs and workbook identify the final selections. Browser-rendered raw HTML can include original site scripts or external resources. Use the evidence index for ordinary browsing.
- `file_manifest.csv` lists every included member other than itself, with its path, role, byte count and SHA-256 digest.

Dependency directories, browser profiles/session state, runtime caches and compiled libraries are excluded. The copied workbook in the working directory is omitted when its bytes match the delivered workbook. The original research scripts may reference locally installed Chrome, Python packages or the artifact-tool runtime. No dependencies are required to open the CSVs or read the HTML index.
