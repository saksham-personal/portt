import re
from root_evidence import RAW, WORK, add, firms, metadata, source_html
import json


domain = "www.decheng.com"
decheng_stages = []
decheng_rows = {}
decheng_exits = {"acelyrin", "excellergy therapeutics", "immpact bio", "aadi bioscience"}
for path in sorted((RAW / domain).glob("bio-*.json")):
    stage = path.stem
    source = metadata(domain, stage)["url"]
    soup = source_html(domain, stage)
    heading = soup.find("h3", string=re.compile(r"^Current Companies$", re.I))
    if not heading:
        continue
    count = 0
    for tag in heading.parent.select("ul li"):
        published_name = tag.get_text(" ", strip=True)
        name = re.sub(r"\s+\(NASDAQ: [^)]+\)$", "", published_name)
        if name.casefold() in decheng_exits or not name:
            continue
        link = tag.find("a", href=True)
        decheng_rows.setdefault(name, {
            "name": name, "url": link["href"] if link else "", "source": source,
            "status": "Current Companies in investor biography",
        })
        count += 1
    if count:
        decheng_stages.append(stage)
sec = "https://www.sec.gov/Archives/edgar/data/2010850/000110465926127247/xslForm13F_X02/infotable.xml"
for name in ("Aardvark Therapeutics", "Aclaris Therapeutics", "Arcus Biosciences", "BeyondSpring", "CG Oncology",
             "Equillium", "Lyell Immunopharma", "Nuvation Bio", "Pyxis Oncology", "Upstream Bio", "Zentalis Pharmaceuticals"):
    item = decheng_rows.setdefault(name, {"name": name, "url": ""})
    item.update(source=sec, status="Decheng 13F public equity holding at 30 September 2026")
add(domain, "Decheng Capital", "Partial", "Current Companies sections in the firm’s investor biographies and September 2026 SEC holdings",
    "The public grid is mixed and has industry filters. Investor bios do not cover every portfolio entry. ACELYRIN, Excellergy, ImmPACT Bio and the former Aadi identity were omitted following transactions or obsolete listings. Public securities reflect the 13F's quarter-end snapshot.",
    sorted(decheng_rows.values(), key=lambda row: row["name"].casefold()),
    stages=("portfolio", *decheng_stages),
    hide={stage: "section:has(> h3:-soup-contains('Alumni Investments'))" for stage in decheng_stages})

domain = "www.ewhealthcare.com"
ew_names = [
    ("BioTissue", "bio-bob-white"),
    ("Bioventus", "bio-marty-sutter"),
    ("Enercon Technologies", "bio-guido-j-neels"),
    ("Germfree", "bio-andrew-thomson"),
    ("Grundium Oy", "bio-petri-vainio"),
    ("Laboratoires Majorelle", "bio-petri-vainio"),
    ("Metabolon", "bio-scott-barry"),
    ("MiMedx", "bio-marty-sutter"),
    ("Prolacta Bioscience", "bio-marty-sutter"),
    ("Suneva Medical", "bio-ron-eastman"),
    ("TELA Bio", "bio-guido-j-neels"),
    ("VitalConnect", "bio-bob-white"),
]
ew_rows = [{"name": name, "url": "", "source": metadata(domain, stage)["url"],
            "status": "Named current portfolio company or board position in firm biography"}
           for name, stage in ew_names]
ew_rows.append({
    "name": "Boiron", "url": "",
    "source": "https://ewhealthcare.com/team/evis-hursever/",
    "status": "Firm names the investment in its bio and lists it in the selected portfolio",
})
ew_rows.append({
    "name": "Ascend Advanced Therapies", "url": "https://www.ascend-adv.com/",
    "source": "https://www.ascend-adv.com/ascend-advanced-therapies-partners-with-ew-healthcare-partners-to-expand-united-states-capacity-and-capabilities/",
    "status": "Named EW investment in official company announcement",
})
add(domain, "EW Healthcare Partners", "Partial", "Current board roles and official investment announcements",
    "The public portfolio is selected and does not provide a current status filter. This list relies on named current figures in the firm's partner biographies and an official investment announcement. Venus Concept was excluded following its completed sale.",
    sorted(ew_rows, key=lambda row: row["name"].casefold()),
    stages=tuple(dict.fromkeys(["portfolio", *[stage for _, stage in ew_names], "bio-evis-hursever", "ascend-announcement"])))

(WORK / "team-overrides.json").write_text(json.dumps(firms, indent=2, ensure_ascii=False), encoding="utf-8")
print({f["domain"]: len(f["investments"]) for f in firms})
