from pathlib import Path
import html
import json
import re
from urllib.parse import urljoin
from bs4 import BeautifulSoup

ROOT=Path(__file__).parent
DEST=ROOT.parent.parent/'outputs'/'html'/'c'
PORTFOLIOS=dict(json.loads((ROOT/'portfolio-urls.json').read_text(encoding='utf8')))
NAMES=['1315 Capital','BelHealth Investment Partners','Amulet Capital Partners','MedEquity Capital',"Tyree & D’Angelo Partners",'Lorient Capital','Questa Capital','B-FLEXION','NaviMed Capital','Aldrich Capital Partners','Ardan Equity','Avego','Iron Path Capital','Consonance Capital Partners','Achieve Partners','Grant Avenue Capital','Assured Healthcare Partners','Avesi Partners','Concord Health Partners','Peloton Equity','Hildred','QHP Capital','Rallyday Partners','Rubicon Founders','Heritage Group (Monaco)','Havencrest Capital Management','RiverGlade Capital','Ashlar Capital']
FIRMS=dict(zip(PORTFOLIOS,NAMES,strict=True))
RECORDS={}
RAW={
 '1315capital.com':['1315capital.com-filtered2'], 'belhealth.com':['belhealth.com-filtered2'],
 'amuletcapital.com':['amuletcapital.com-filtered2'], 'lorientcap.com':['lorientcap.com-filtered2'],
 'navimed.com':['navimed.com-filtered2'], 'avego.com':['avego.com-filtered2'],
 'grantave.com':['grantave.com-filtered2'], 'avesipartners.com':['avesipartners.com-filtered2'],
 'qhpcapital.com':['qhpcapital.com-filtered2'], 'rallydaypartners.com':['rallydaypartners.com-filtered2'],
 'riverglade.com':['riverglade.com-filtered2'], 'medequity.com':['medequity.com-current-details'],
 'havencrest.com':['havencrest-focused'], 'concordhp.com':['concordhp.com-portfolio'],
}
CROSSCHECK={
 '1315capital.com':[('Surmodics change of control','https://surmodics.gcs-web.com/static-files/96c4e176-ade6-470b-9221-f52475463083')],
 'achievepartners.com':[('Achieve portfolio and transaction news','https://www.achievepartners.com/news.html')],
 'ardanequity.com':[('Investment and disposition announcements','https://www.ardanequity.com/ardan-equity-news')],
 'ashlarcap.com':[('Amulet’s description of the exit','https://amuletcapital.com/about/')],
 'ahpartners.com':[('AHP portfolio operating partners','https://www.ahpartners.com/people/'),('AHP impact report','https://www.ahpartners.com/wp-content/uploads/2025/02/Digital_AHP_ImpactReport2024_0221.pdf')],
 'bflexion.com':[('Paratek and Radius combination announcement','https://www.bflexion.com/news/paratek-pharmaceuticals-completes-combination-radius-health-expanding-its-multi-product')],
 'havencrest.com':[('Havencrest portfolio transaction news','https://havencrest.com/news/')],
 'heritagemonaco.com':[('Heritage Group press releases','https://www.heritagemonaco.com/press/'),('Abercrombie & Kent Travel Group brands','https://www.abercrombiekent.com/privacy-policy')],
 'pelotonequity.com':[('2026 AdaptHealth SEC filing','https://www.sec.gov/Archives/edgar/data/1725255/000162828026027965/ahco-20260428.htm'),('Peloton investment and disposition news','https://www.pelotonequity.com/news')],
}

def load(d,v=None):
    for m in ([v] if v else ['filtered2','filtered','portfolio','home']):
        path=ROOT/f'{d}-{m}.html'
        j=path.with_suffix('.json')
        if path.exists() and read(j).get('http')==200:
            return BeautifulSoup(path.read_text(encoding='utf8'),'lxml'), read(j)
    return BeautifulSoup('','lxml'), {}

def read(p):
    return json.loads(p.read_text(encoding='utf8')) if p.exists() else {}

def txt(el):
    return el.get_text(' ',strip=True) if el else ''

def attr(el,k,default=''):
    return el.get(k,default) if el else default

def item(name,url='',status='Current',source=None):
    return (name.strip(),url,status,source)

def list_items(names,url='',status='Current'):
    return [item(n,url,status) for n in names.split('|')]

def absurl(base,source):
    result=urljoin(base,source or '')
    return result if result.startswith(('https://','http://')) else base

def tidy_evidence(el):
    if not el:
        return ''
    tags=[el]
    tags.extend(el.select('h1,h2,h3,h4,h5,h6,[data-status],.status,[aria-label],a[href],img[alt]')[:10])
    lines=[]
    for tag in tags:
        allowed={k:v for k,v in tag.attrs.items() if k in ['href','aria-label','alt','data-status','data-target','data-rel','data-groups','data-attribute','class','id'] and v}
        note={k:' '.join(v) if isinstance(v,list) else v for k,v in allowed.items()}
        attrs=''.join(f' {k}="{v}"' for k,v in note.items())
        inner=txt(tag)
        if len(inner)>100:
            inner=''
        line=f'<{tag.name}{attrs}>'+(inner+f'</{tag.name}>' if inner else '')
        if line not in lines:
            lines.append(line)
    return '\n'.join(lines)

def record(domain,method,items,notes='',state='Verified',url='',capture=None):
    url=url or PORTFOLIOS[domain]
    checked=[]
    evidence=[]
    seen=set()
    for name,target,status,source in items:
        assert name, domain
        key=name.casefold()
        if key in seen: continue
        seen.add(key)
        checked.append({'name':name,'url':absurl(url,target),'status':status})
        if source:
            markup=source if isinstance(source,str) else tidy_evidence(source)
            evidence.append((name,markup))
    backups=[]
    extras=[]
    if checked or capture:
        DEST.mkdir(parents=True,exist_ok=True)
        suffix='current' if checked else 'review'
        filename=f'{domain}-{suffix}.html'
        backup=DEST/filename
        escape=lambda s: html.escape(str(s),quote=True)
        original_links=[]
        for stem in RAW.get(domain,[]):
            source=(ROOT/f'{stem}.html')
            info=read(source.with_suffix('.json'))
            if info.get('http')!=200 or info.get('error') or not source.exists(): continue
            raw=source.read_text(encoding='utf8')
            base=escape(info.get('url',url))
            head=f'<head><meta http-equiv="Content-Security-Policy" content="script-src \'none\'; object-src \'none\'; frame-src \'none\'; form-action \'none\'"><base href="{base}">'
            raw=re.sub(r'<head(?:\s[^>]*)?>',lambda _:head,raw,count=1,flags=re.I)
            original=DEST/'source'/f'{domain}.html'
            original.parent.mkdir(parents=True,exist_ok=True)
            original.write_text(raw,encoding='utf8')
            original_links.append(f'<p><a href="source/{escape(original.name)}">Open serialized browser HTML</a> (scripts disabled for offline review)</p>')
            extras.append(f'html/c/source/{original.name}')
        rows=''.join(f'<tr><td><a href="{escape(x["url"])}">{escape(x["name"])}</a></td><td>{escape(x["status"])}</td></tr>' for x in checked)
        snippets=''.join(f'<h3>{escape(n)}</h3><pre>{escape(m)}</pre>' for n,m in evidence)
        table=f'<table><thead><tr><th>Investment</th><th>Source basis</th></tr></thead><tbody>{rows}</tbody></table>' if rows else '<p>No holdings verified from the available status evidence.</p>'
        appendix=f'<details><summary>Rendered page evidence</summary>{snippets}</details>' if snippets else ''
        other=''.join(f'<li><a href="{escape(link)}">{escape(label)}</a></li>' for label,link in CROSSCHECK.get(domain,[]))
        if other: appendix+=f'<h2>Additional sources</h2><ul>{other}</ul>'
        backup.write_text(f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{escape(FIRMS[domain])} | Portfolio evidence</title><style>body{{font:16px/1.5 system-ui,sans-serif;margin:2rem auto;padding:0 1rem;max-width:58rem;color:#172c42}}h1{{margin-bottom:0}}p{{margin:.5rem 0 1rem}}a{{color:#175782}}table{{margin:1.5rem 0;border-collapse:collapse;width:100%;text-align:left}}td,th{{padding:.5rem .7rem;border-bottom:1px solid #dae2e8;vertical-align:top}}th{{background:#17334f;color:white}}tr:nth-child(even){{background:#f2f6f9}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f6f9;padding:.7rem}}</style><body><main><h1>{escape(FIRMS[domain])}</h1><p>Portfolio evidence • 23 November 2026 • {escape(state)}</p><p><a href="{escape(url)}">Open original firm page</a></p><p>{escape(method)}</p><p>{escape(notes)}</p><p>Portable HTML reconstruction of the reviewed browser state. Available card markup is preserved as readable source evidence.</p>{''.join(original_links)}{table}{appendix}</main></body></html>''',encoding='utf8')
        backups=[f'html/c/{filename}']
    RECORDS[domain]={'domain':domain,'firm':FIRMS[domain],'url':url,'state':state,'method':method,'notes':notes,'backups':backups,'investments':checked}
    if extras: RECORDS[domain]['archive_extras']=extras

d='1315capital.com'; s,_=load(d)
record(d,'Applied the Active filter and matched each visible card’s status.',[item(attr(a,'aria-label'),attr(a,'href'),'Active',el) for el in s.select('.company-card[data-status=active]') if (a:=el.select_one('a[aria-label]'))],'The firm excludes investments it has not announced. Its Surmodics (fka Biocoat) card has no status and is excluded from the site’s Active filter.')

d='belhealth.com'; s,_=load(d)
rows=[]
for el in s.select('.shuffle-item[data-groups]'):
    if 'current' not in attr(el,'data-groups'): continue
    a=el.select_one('a[href]'); label=txt(a); name=re.sub(r'^current\s+','',label,flags=re.I)
    img=attr(el.select_one('img'),'alt')
    rows.append(item(img if img and len(img)>3 else name.title(),attr(a,'href'),'Current',el))
record(d,'Applied the Current filter and checked the card status.',rows)

d='amuletcapital.com'; s,_=load(d)
record(d,'Applied the Current status filter across all subsectors.',[item(attr(el,'aria-label').removeprefix('Open details about '),status='Current',source=el) for el in s.select('.portfolio-grid-inner .portfolio-card[data-status=current]')],'The firm excludes investments it has not announced.')

d='tdpfund.com'; s,_=load(d)
rows=[]
for a in s.select('.investment_list a[href]'):
    u=attr(a,'href'); slug=u.rstrip('/').split('/')[-1]; sd, dd=load(d+'-'+slug,'details')
    label=next((v for v in dd.get('text','').splitlines() if re.fullmatch(r'Investment Status:\s*Current',v.strip(),re.I)),None)
    if label: rows.append(item(dd['title'].split(' » ')[0],u,'Current',sd.find(string=lambda x:x and label.strip() in x.strip()).parent if sd.find(string=lambda x:x and label.strip() in x.strip()) else a))
record(d,'Opened all 13 investment detail pages and selected the Current status.',rows)

d='lorientcap.com'; s,_=load(d)
record(d,'Applied the Current filter and read the status on each card.',[item(txt(el.select_one('.company-card__title')),attr(el,'href'),'Current',el) for el in s.select('a.company-card[data-status=current]')])

d='navimed.com'; s,_=load(d)
rows=[]
nav_names={'advantage':'Advantage Surgical','argos-health':'EnableComp (f/k/a Argos Health)','brantcare':'BrentCare','citrus':'CiTRUS Health','clarimed':'ClariMed','infusive':'Infusive','lighthouse-lab-services':'Lighthouse Lab Services','metrix':'Metrix','neulife':'NeuLife','opn_healthcare':'OPN Healthcare','tilt':'TILT','vitoria':'Vitoria'}
for el in s.select('img.mix.current'):
    key=attr(el,'data-target'); modal=s.select_one(key); name=nav_names[key[1:].removesuffix('-modal')]
    rows.append(item(name,attr(modal.select_one('a[href]'),'href'),'Current',el))
record(d,'Applied the Current filter and matched investment details against its output.',rows,'The site puts EnableComp and Lighthouse Lab Services in a separate Partially Exited category. Both are outside the Current filter.')

d='aldrichcap.com'; s,_=load(d,'portfolio')
rows=[]
for a in s.select('a.company-contain[href]'):
    u=attr(a,'href'); slug=u.rstrip('/').split('/')[-1]; sd,dd=load(d+'-'+slug,'details')
    status=next((line.strip() for line in dd.get('text','').splitlines() if line.strip()=='Active'),None)
    tag=sd.find(string=lambda x:x and x.strip()=='Active')
    if status: rows.append(item(txt(a),u,'Active',tag.parent if tag else a))
record(d,'Opened all 23 portfolio cards and kept each company whose detail page says Active.',rows)

d='avego.com'; s,_=load(d)
rows=[]
for el in s.select('.status-current-private'):
    trigger=el.select_one('[data-open]'); modal=s.find(id=attr(trigger,'data-open')); name=txt(modal.select_one('h3')) if modal else ''
    if name: rows.append(item(name,attr(modal.select_one('a[href]'),'href'),'Current',el))
record(d,'Applied Current Investments across all displayed strategies and read the corresponding company cards.',rows,'The site directs readers to separate 13F filings for Velan holdings. The records here cover the Avego portfolio page.')

d='grantave.com'; s,_=load(d)
rows=[]
for el in s.select('.portfolio-item-2[data-status=Active]'):
    a=el.select_one('a[href]'); u=attr(a,'href'); slug=u.rstrip('/').split('/')[-1]; sd,dd=load(d+'-'+slug,'details')
    lines=[l.strip() for l in dd.get('text','').splitlines() if l.strip()]
    name=lines[lines.index('Date of Investment:')-1]
    rows.append(item(name,u,'Active',el))
record(d,'Applied Active and cross-checked the surviving cards’ detail-page labels.',rows,'Investments made by staff at other firms are outside the listed Grant Avenue portfolio.')

d='avesipartners.com'; s,j=load(d)
rows=[item(txt(a),attr(a,'href'),'Current',a.parent.parent.parent) for a in s.select('.portfolio-card--content--title a[href]')]
record(d,'Expanded the Current Investments list with Load More until the control disappeared.',rows,url=j.get('url',''))

d='qhpcapital.com'; s,_=load(d)
record(d,'Applied Active and checked membership against the original status classes.',[item(attr(el.select_one('img'),'alt'),'/portfolio/'+attr(el.select_one('[data-attribute]'),'data-attribute'),'Active',el) for el in s.select('.companies .company.active')])

d='rallydaypartners.com'; s,_=load(d)
names=['Simplistic','Elder Care Homecare','Insero','Nimble Gravity','Kicksaw','Livefront','Espire Dental','Power Technologies','Highbar Physical Therapy']
cards=s.select('.e-loop-item.type-portfolio.portfolio_category-active')
record(d,'Applied Active and cross-checked the site’s portfolio-category classes.',[item(name,attr(el.select_one('.colored-logo a'),'href'),'Active',el) for name,el in zip(names,cards,strict=True)])

d='riverglade.com'; s,_=load(d)
rows=[]
for el in s.select('#awsm-team-5409 .awsm-team-item.awsm-40'):
    heading=txt(el.select_one('h3')); detail=s.select_one(attr(el,'data-griddercontent'))
    rows.append(item(heading.rstrip(' *'),attr(detail.select_one('a[href]'),'href') if detail else '', 'Current',el))
record(d,'Applied Current and matched the firm’s tagged company cards.',rows,'The firm separately lists pre-RiverGlade investments. Asterisks on the original cards are retained in the source evidence.')

d='medequity.com'; s,j=load(d+'-current','details')
record(d,'Opened the firm’s Type: Current archive and matched all six records.',[item(txt(el),attr(el.select_one('a[href]'),'href'),'Current',el) for el in s.select('.post h2')],url=j.get('url',''))

d='questacapital.com'; one,_=load(d,'portfolio'); two,j2=load(d+'-page2','details'); rows=[]
for s in [one,two]:
    for el in s.select('.portfolio-grid .item-inside'):
        active_content=el.select_one('.item-content'); heading=txt(el.select_one('h2'))
        status_text=txt(active_content)
        if not heading or re.search(r'\b(exited|realized)\b',status_text,re.I): continue
        a=el.select_one('a[href*="/portfolio-companies/"]')
        if a: rows.append(item(heading,attr(a,'href'),'Listed portfolio company; no exit flag',el))
record(d,'Checked both pages and all sector panels. Excluded companies explicitly tagged Exited.',rows,'The website publishes exit flags in the cards and no separate Current filter.')

d='consonancecapital.com'; s,j=load(d+'-more','details'); rows=[]
consonance_current=['Bako Diagnostics','Orsini Pharmaceutical Services','Psychiatric Medical Care','Priority OnDemand','Sellers Dorsey','Summit Medical Group & CityMD']
for name in consonance_current:
    if name=='Summit Medical Group & CityMD': continue
    found=s.find(string=lambda x:x and x.strip()==name)
    if found: rows.append(item(name,'','Current',found.parent))
record(d,'Opened the private equity division’s official Portfolio Detail page and read the individual status blocks.',rows,'Summit Medical Group & CityMD is excluded because the reported 2023 acquisition conflicts with the site’s Current label. The public equity division has no firm-site current company roster.',state='Partial',url=j.get('url',''))

d='achievepartners.com'; s,_=load(d,'portfolio'); rows=[]
included={"Ascend Partners","RiseNow","SkillStorm","Alchemy","Ultraviolet","Helios Consulting","Westside Children's Therapy","Celito","MasteryPrep","Elentra","MusicFirst","Beanstack","FutureFit AI","KickUp","Juno"}
for h in s.select('h3'):
    name=txt(h)
    if name not in included: continue
    block=h.parent; a=block.select_one('a[href]') or block.parent.select_one('a[href]')
    rows.append(item(name,attr(a,'href'),'Listed in firm fund portfolio',block))
record(d,'Read both Achieve fund portfolios and excluded the separately labeled prior adviser investments.',rows,'Optimum Healthcare IT remains on the portfolio grid but is excluded because Achieve’s news page confirms its acquisition by Infosys.')

d='hildred.com'; s,_=load(d,'portfolio'); rows=[]
for a in s.select('a.portfolio-thumb-linkblock[href]'):
    u=attr(a,'href'); slug=u.rstrip('/').split('/')[-1]; sd,dd=load(d+'-'+slug,'details')
    lines=[v.strip() for v in dd.get('text','').splitlines() if v.strip()]
    status=next((lines[i+1] for i,v in enumerate(lines[:-1]) if v=='Status:'),'')
    if not status or status.casefold()=='exited': continue
    name=txt(sd.select_one('h1')) or txt(a)
    tag=sd.find(string=lambda x:x and x.strip()==status)
    rows.append(item(name,u,status,tag.parent.parent if tag else a))
record(d,'Opened every portfolio company detail page and read the Status field.',rows,'A company with both an exited and a private position is included when Hildred explicitly lists a continuing private position in another fund.')

d='havencrest.com'; s,j=load('havencrest','focused'); s0,j0=load(d+'-retry','details'); s=s if j else s0
items_havencrest={'Apara Autism Centers':'https://aparaautism.com/','Avid Health at Home':'https://www.avidhealthathome.com/','Deep Centered Mental Health':'https://deepcentered.com/','Effective School Solutions':'http://www.effectiveschoolsolutions.com/','Focus Staff':'https://focus-staff.com/','Paradigm Health':'https://www.myparadigmhealth.com/','Tekton Research':'https://tektonresearch.com/','ThermoTek':'https://www.thermotekusa.com/'}
rows=[]
for name,u in items_havencrest.items():
    tag=s.find(string=lambda x:x and x.strip()==name)
    if tag: rows.append(item(name,u,'Active',tag.parent))
record(d,('Applied the Current portfolio selector and checked card-level active labels.' if j else 'Checked the firm-portfolio and card-level Active labels.'),rows,'Exited and prior-firm assets are excluded. Havencrest still labels Paradigm Health Active after reporting a majority exit.')

d='ashlarcap.com'; s,_=load(d,'portfolio'); rows=[]
for el in s.select('h6'):
    name=txt(el)
    if not name or name.casefold()=='us digestive health': continue
    rows.append(item(name,status='Listed under active portfolio',source=el))
record(d,'Read all seven investment entries and the firm’s description of an active portfolio.',rows,'US Digestive Health is omitted because contemporaneous evidence confirms the Amulet-led investment was exited, and Ashlar does not disclose whether it retained a stake.',state='Partial')

d='ironpathcapital.com'; s,_=load(d,'portfolio')
names={'Boulder Scientific','Nalas','Aetherion','PRO-SET','TruTech Servo Motors & Systems','PureTech Scientific','VION Biosciences','Capitol Pain Institute','Emergence Health (Urgent Care)','Versant Diagnostics'}
record(d,'Read all companies in the firm’s IPC Investments section.',[item(txt(el),status='Listed portfolio company; no exit flag',source=el) for el in s.select('h1,h2,h3,h4,h5,h6') if txt(el) in names],'The grid has no investment-status field or exit filter. Iron Path says holdings differ across funds.',state='Partial')

d='rubiconfounders.com'; s,_=load(d,'portfolio'); rows=[]
for a in s.select('a[href*="/portfolio/"]'):
    u=attr(a,'href'); slug=u.rstrip('/').split('/')[-1]; sd,dd=load(d+'-'+slug,'details')
    name=dd.get('title','').split(' | ')[0]
    if name: rows.append(item(name,u,'Firm-disclosed portfolio company',a))
record(d,'Read all portfolio cards and matched their linked company detail pages.',rows,'The site calls this list representative and omits exploratory seed investments below $5 million. There is no per-company exit marker.',state='Partial')

d='concordhp.com'; s,_=load(d,'portfolio'); rows=[]
_,modal_data=load('concord','focused')
concord_cards={cid:(status,links) for cid,status,links in modal_data['cards']}
for el in s.select('.pr[data-bs-target="#portfolioModal"]'):
    name=attr(el.select_one('img'),'alt').strip()
    full_status,links=concord_cards[el['id']]
    clean_status=[p.strip() for p in full_status.splitlines() if p.strip()]
    if name and clean_status[:2]==['Status','Active']:
        exact={'Highridge':'Highridge Medical','Clarify':'Clarify Health'}.get(name,name)
        markup=tidy_evidence(el)+'\n\nDetail panel excerpt\n'+'\n'.join(clean_status[:5])
        rows.append(item(exact,links[0][1] if links else '',status='Active',source=markup))
record(d,'Opened all 14 company detail panels and confirmed each explicitly says Status: Active.',rows)

d='pelotonequity.com'; s,_=load(d,'portfolio'); rows=[]
peloton_candidates=[('AeroSafe Global','https://www.aerosafeglobal.com/'),('ClearSky Health','https://www.clearskyhealth.com/'),('Grenova','https://grenovasolutions.com/'),('HealthPlanOne (HPOne)','https://www.hpone.com/'),('Journey Health & Lifestyle','https://www.journeyhealthandlifestyle.com/'),('OnPoint Healthcare Partners','https://www.onpointhealthcarepartners.com/'),('Ria Health','https://www.pelotonequity.com/news/arcadia-acquires-carejourney-644z4')]
for name,u in peloton_candidates:
    domain=u.split('/')[2].removeprefix('www.')
    anchor=next((x for x in s.select('a[href]') if domain in x.get('href','') and '#investments' not in x.get('href','')),None)
    rows.append(item(name,u,'Firm-disclosed position',anchor))
record(d,'Reviewed Peloton’s own investment cards and announcements and checked the 2026 AdaptHealth SEC filing that identifies Peloton investments.',rows,'Past Ferrer Freeman investments, AeroCare, IDX, and Arcadia are excluded. Ria Health is disclosed in the firm’s news. The investment grid and transaction announcements are not synchronized.',state='Partial')

d='bflexion.com'; s,_=load(d+'-investing','confirm'); rows=[]
managers={'strategic-investment-group':'Strategic Investment Group','longview-partners':'Longview Partners','twelve-securis':'Twelve Securis','landfair-capital':'Landfair Capital','forge-life-sciences-partners':'Forge Life Sciences Partners','kedge-capital':'Kedge Capital','crosstree-real-estate':'Crosstree Real Estate Partners','forestay-capital':'Forestay Capital','roxbury':'Roxbury','capital-four':'Capital Four'}
holdings={'corium':'Corium','stallergenes-greer':'Stallergenes Greer','allergy-partners':'Allergy Partners','paratek-pharmaceuticals':'Paratek Pharmaceuticals','corium-innovations':'Corium Innovations'}
for records,status in [(managers,'Disclosed investment partnership'),(holdings,'Disclosed operating investment')]:
    for slug,name in records.items():
        url=f'/businesses/{slug}'
        card=s.select_one(f'a[href$="{url}"]')
        if card: rows.append(item(name,url,status,card))
record(d,'Reviewed the Investment Partnerships and B-FLEXION Life Sciences sections of the Investing page.',rows,'Internal service platforms are excluded. Radius Health was combined into Paratek in March 2026. The group does not publish underlying holdings of the listed partnerships.',state='Partial',url='https://www.bflexion.com/investing')

d='ardanequity.com'; s,j=load(d+'-news','details')
news_url=j.get('url','')
rows=[]
for name,needle in [('Clinical ink','Clinical ink Announces Strategic Investment'),('Datavant','Datavant Acquires Ontellus'),('Knowtion Health','Knowtion Health Acquires Switch RCM'),('Machinify','Performant Healthcare, Inc. (Nasdaq: PHLT) acquired by Machinify'),('HealthEdge','powerful combination of HealthEdge and UST HealthProof'),('WellSky','WellSky® Acquires Bonafide Health'),('Norstella','Norstella Appoints Kris Joshi as CEO')]:
    tag=s.find(string=lambda x:x and needle.casefold() in x.strip().casefold() and len(x)<180)
    if not tag:
        tag=s.find(string=lambda x:x and needle.casefold() in x.strip().casefold())
    if tag: rows.append(item(name,news_url,'Firm-announced investment',tag.parent))
record(d,'Read all 10 portfolio logos in the browser and cross-checked the investment and disposition announcements.',rows,'Corevitas, Intelerad, and Apixio are omitted after disclosed acquisitions or integration into other platforms. The firm does not publish card-level status labels.',state='Partial')

d='ahpartners.com'; s,_=load(d,'portfolio'); found={
    'Acelpa.png':'Acelpa Health','client-02.svg':'Advantia Health','client-03.svg':'Allied Digestive Health','athenacare_logo_lockup_horizontal_rgb_600.png':'Athena Care','client-05.svg':'Bridge Home Health & Hospice','Collabrios-Health-Logo.png':'Collabrios Health','DH_Logo_Linear_Color_1220.png':'DeliverHealth Solutions','HVP-Main-Logo_RGB_Color.png':'Heart & Vascular Partners','client-11.svg':'National Partners in Healthcare','PharmaLogistics_Logo_RGB_Hex-006-e1706051691723.png':'Pharma Logistics','Prolerity_blk.png':'Prolerity Clinical Research'}
rows=[]
for el in s.select('.client-list .client'):
    im=el.select_one('img'); filename=attr(im,'src').rsplit('/',1)[-1]
    if filename in found: rows.append(item(found[filename],status='Listed by AHP; recent or ongoing evidence',source=el))
record(d,'Read the 21 portfolio logos in the browser and matched corroborated company names against AHP’s Recent Investments, People, impact report and announcements.',rows,'AHP’s grid mixes current and exited investments and supplies no per-card status labels. Holdings without sufficient ongoing-investment evidence were excluded.',state='Partial')

d='heritagemonaco.com'; s,_=load(d,'portfolio'); rows=[]
for name,url in [('Crystal Cruises','https://crystalcruises.com/'),('Abercrombie & Kent','https://www.abercrombiekent.com/'),('Cox & Kings','https://www.coxandkings.co.uk/')]:
    card=s.select_one(f'#travel a[href="{url}"]')
    if card: rows.append(item(name,url,'Current group company or brand',card.parent.parent))
arqit=s.select_one('#financial a[href="https://arqit.uk/"]')
if arqit:
    rows.append(item('Arqit Quantum Inc.','https://www.sec.gov/Archives/edgar/data/1859690/000110465925119500/arqq-20250930x20f.htm','Heritage ownership disclosed in Form 20-F',arqit.parent.parent))
record(d,'Reviewed all seven sector panels, corroborating the travel holdings through group disclosures and the Arqit ownership through a filing.',rows,'The combined Portfolio and Track Record page mixes historical transactions and ongoing positions without a current holdings filter. Only corroborated positions are included.',state='Partial',capture=s.select_one('#posts-container'))

assert list(FIRMS)==list(PORTFOLIOS)
assert set(RECORDS)==set(PORTFOLIOS), sorted(set(PORTFOLIOS)-set(RECORDS))
for domain,row in RECORDS.items():
    assert row['state'] in {'Verified','Partial','Unverified','No public portfolio'}
    assert all((DEST.parent.parent/rel).is_file() for rel in row['backups']+row.get('archive_extras',[]))
    assert all(x['name'] in html.unescape((DEST.parent.parent/row['backups'][0]).read_text(encoding='utf8')) for x in row['investments'])
    print(domain,row['state'],len(row['investments']))
results=ROOT/'results.json'
pending=results.with_suffix('.tmp')
pending.write_text(json.dumps([RECORDS[d] for d in PORTFOLIOS],ensure_ascii=False,indent=2),encoding='utf8')
pending.replace(results)
