from pathlib import Path
import sys,re,json
from bs4 import BeautifulSoup

R=Path(__file__).parent
for dom, tokens in {
 '1315capital':['Aluris','3B Scientific'], 'belhealth':['Beach House'], 'amuletcapital':['Alliance Clinical Network','Current'], 'lorientcap':['American Family Care'], 'navimed':['advantage-grid','clarimed-blue'], 'avego':['Alveus Therapeutics'], 'qhpcapital':['Applied StemCell'], 'rallydaypartners':['/portfolio/simplistic/'], 'riverglade':['Sentinel Care Group','awsm-40'], 'grantave':['21st-century','Active-2'], 'avesipartners':['New Age Medical','Load More'], 'medequity':['MAX Surgical'], 'aldrichcap':['TempusDirect','Exited'], 'tdpfund':['/investment/generational'], 'ardanequity':['Our Investments'], 'ahpartners':['Acelpa.png'], 'pelotonequity':['5ced424f0852296f64761c50-title'], 'hildred':['OrangeTwist'], 'heritagemonaco':['Travel'], 'concordhp':['Thyme Care'], 'ashlarcap':['Pivotal Healthcare Partners'], 'questacapital':['Aerin Medical'], 'ironpathcapital':['Boulder Scientific'], 'rubiconfounders':['Evergreen Nephrology Logo Image']}.items():
  if len(sys.argv)>1 and not any(x in dom for x in sys.argv[1:]): continue
  files=list(R.glob(f'{dom}.com-filtered.html')) or list(R.glob(f'{dom}.com-portfolio.html'))
  for f in files:
    s=BeautifulSoup(f.read_text(encoding='utf8'),'lxml')
    print('\n===',f.name)
    for token in tokens:
      tags=[t for t in s.find_all(['a','button','h1','h2','h3','h4','h5','div','span','input','img','p']) if any(token.casefold() in str(t.get(k,'')).casefold() for k in ['href','src','alt','id','for','data-rel']) or (t.string and len(t.string)<160 and token.casefold() in t.string.casefold())]
      for t in tags[:4]:
        print(token)
        for p in [t,t.parent,t.parent.parent,t.parent.parent.parent,t.parent.parent.parent.parent]:
          print('  ',p.name,p.get('class') or '',{k: v for k,v in p.attrs.items() if (k.startswith(('data-','aria-')) and len(str(v))<100) or k in ['id','href','style']}, p.get_text(' ',strip=True)[:155] if p is t else '')
