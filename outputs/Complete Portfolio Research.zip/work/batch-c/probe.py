from pathlib import Path
import sys,re,json
from bs4 import BeautifulSoup
R=Path(__file__).parent
def soup(d, variant=None):
    variants=[variant] if variant else ['filtered2','filtered','portfolio','home']
    for v in variants:
        p=R/f'{d}-{v}.html'
        if p.exists(): return BeautifulSoup(p.read_text(encoding='utf8'),'lxml')
    return BeautifulSoup('', 'lxml')
def txt(t): return t.get_text(' ',strip=True) if t else ''
targets={
 '1315capital.com': ('.company-card', lambda t:[t.get('data-status'),t.select_one('a').get('aria-label'),t.get('style')]),
 'amuletcapital.com': ('.portfolio-grid-inner .portfolio-card', lambda t:[t.get('data-status'),t.get('aria-label'),t.get('class'),[x.get('href') for x in t.select('a[href]')]]),
 'avego.com': ('.status-current-private', lambda t:[t.name,t.get('class'),txt(t.select_one('h3,h4,h5,h6')),[(x.get('name'),x.get('id'),x.get('href')) for x in t.select('a')],[(x.get('src') or x.get('data-src')) for x in t.select('img')]]),
 'pelotonequity.com': ('.image-slide-title', lambda t:[txt(t),t.parent.select_one('img').attrs.get('alt') if t.parent.select_one('img') else None,t.parent.select_one('img').attrs.get('data-image') if t.parent.select_one('img') else None]),
 'navimed.com': ('img.mix', lambda t:[t.get('class')[-2:],t.get('data-target'),txt(t.find_parent('body').select_one((t.get('data-target') or '#none')+' .modal-title')), [(x.get('href'),txt(x)) for x in t.find_parent('body').select((t.get('data-target') or '#none')+' a[href]')][:2]]),
 'riverglade.com': ('#awsm-team-5409 .awsm-team-item', lambda t:[t.get('class')[-2:],txt(t.select_one('h3')),t.get('style')]),
 'qhpcapital.com': ('.companies .company', lambda t:[t.get('class'),t.select_one('img').get('alt'),t.select_one('a').get('data-attribute')]),
 'rallydaypartners.com': ('.e-loop-item.type-portfolio', lambda t:[t.get('class')[-1],t.select_one('.colored-logo a').get('href') if t.select_one('.colored-logo a') else None,t.get('style')]),
 'grantave.com': ('.portfolio-item-2', lambda t:[t.get('data-status'),t.select_one('a').get('href'),t.select_one('img').get('alt') if t.select_one('img') else '',t.get('style')]),
 'avesipartners.com': ('.portfolio-card--content--title', lambda t:[txt(t),t.select_one('a').get('href') if t.select_one('a') else '']),
 'medequity.com': ('h2,h3,h4', lambda t:[t.get('class'),txt(t),t.find_parent('section').get('class') if t.find_parent('section') else None]),
 'tdpfund.com':('.investment_list .column',lambda t:[t.get('class'),t.select_one('a').get('href'),t.select_one('a').get('title'),txt(t)]),
 'aldrichcap.com':('.status input',lambda t:[t.get('value'),t.get('id'),t.get('checked'),t.parent.attrs]),
 'ahpartners.com':('.client-list .client',lambda t:[t.attrs,txt(t),[(x.get('src'),x.get('alt')) for x in t.select('img')],[(x.get('href'),txt(x)) for x in t.select('a[href]')]]),
 'ardanequity.com':('#comp-mdyxfpod img',lambda t:[t.get('src'),t.get('alt'),t.find_parent('a').get('href') if t.find_parent('a') else None]),
 'heritagemonaco.com':('#posts-container section',lambda t:[t.get('id'),[(txt(x),x.attrs) for x in t.select('article h3, article h2, a[href]')][:30],txt(t)[:320],[(x.get('src'),x.get('alt')) for x in t.select('img')][:20]]),
 'questacapital.com':('.portfolio-grid .item-inside',lambda t:[txt(t.select_one('h2')),t.select_one('a[href*="/portfolio-companies/"]')['href'] if t.select_one('a[href*="/portfolio-companies/"]') else '', [txt(x) for x in t.select('.item-content .w-condition-invisible, .item-content .tag, .item-content [class*=category]')], txt(t.select_one('.item-content'))[:110]]),
 'havencrest.com':('h1,h2,h3,h4',lambda t:[t.name,t.get('class'),txt(t)]),
}
for dom,(selector, fn) in targets.items():
  if len(sys.argv)>1 and not any(x in dom for x in sys.argv[1:]): continue
  print('\n===',dom)
  for t in soup(dom).select(selector):
    try: print(fn(t))
    except (AttributeError,TypeError,KeyError) as e: print('err',str(e),str(t)[:220])
