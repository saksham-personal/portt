from collections import Counter
import json
import re
from pathlib import Path
from bs4 import BeautifulSoup

ROOT=Path(__file__).parent
OUTPUT=ROOT.parent.parent/'outputs'
listings=json.loads((ROOT/'results.json').read_text(encoding='utf8'))
domains=[d for d,u in json.loads((ROOT/'portfolio-urls.json').read_text(encoding='utf8'))]
assert [entry['domain'] for entry in listings] == domains
assert len(set(domains)) == len(domains) == 28
totals=Counter()
for entry in listings:
    assert len(entry['backups']) == 1
    f=OUTPUT/entry['backups'][0]
    source=BeautifulSoup(f.read_text(encoding='utf8'),'lxml')
    captured=[(tr.select_one('td a').get_text(),tr.select_one('td a')['href'],tr.select('td')[1].get_text()) for tr in source.select('table tbody tr')]
    expected=[(item['name'],item['url'],item['status']) for item in entry['investments']]
    assert captured==expected,(entry['domain'],expected,captured)
    names=[re.sub(r'\W+','',row[0].casefold()) for row in captured]
    assert len(names)==len(set(names)),(entry['domain'],names)
    assert all(re.match(r'https?://',u) for _,u,_ in captured)
    extras=entry.get('archive_extras',[])
    local=[f.parent.joinpath(link['href']) for link in source.select('a[href^="source/"]')]
    assert local==[OUTPUT/p for p in extras], (entry['domain'],local,extras)
    for p in local:
        assert p.is_file() and 'Content-Security-Policy' in p.read_text(encoding='utf8')[:4000]
    totals[entry['state']]+=1
    totals['investment rows']+=len(captured)
    totals['browser HTML exports']+=len(extras)
print(dict(totals))
