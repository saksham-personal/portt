const fs=require('node:fs/promises');
const path=require('node:path');
const {chromium}=require('C:/Users/eskay/AppData/Local/npm-cache/_npx/31e32ef8478fbf80/node_modules/playwright');
const {collect}=require('./review.cjs');

const specs=[
 ['arden','https://www.ardanequity.com/','#comp-mdyxfpod'],
 ['ahp','https://www.ahpartners.com/portfolio/','.client-list'],
 ['concord','https://www.concordhp.com/portfolio',''],
 ['havencrest','https://havencrest.com/investments/',''],
 ['bflexion','https://www.bflexion.com/',''],
 ['peloton','https://www.pelotonequity.com/#investments',''],
 ['surmodics','https://1315capital.com/portfolio/surmodics-fka-biocoat/',''],
];

async function inspect(ctx,[name,url,selector]) {
 const page=await ctx.newPage();
 try {
  const res=await page.goto(url,{waitUntil:'commit',timeout:35000});
  await page.waitForLoadState('domcontentloaded',{timeout:12000}).catch(()=>{});
  await page.evaluate(()=>{
   for (const el of document.querySelectorAll('button')) if(el.getClientRects().length && /^(close dialog|reject all|deny|decline)$/i.test(el.innerText.trim() || el.getAttribute('aria-label') || '')) el.click();
  });
  let meta={};
  if (selector) {
   const el=page.locator(selector).first();
   await el.scrollIntoViewIfNeeded();
   await el.locator('img').evaluateAll(els=>els.forEach(e=>{e.setAttribute('loading','eager');}));
   await page.waitForTimeout(2500);
   await el.screenshot({path:path.join(__dirname,name+'.png'),timeout:11000});
  }
  if(name==='concord') {
   const card=page.locator('.pr[data-bs-target="#portfolioModal"]');
   const ids=await card.evaluateAll(els=>els.map(e=>e.id));
   meta.cards=[];
   for (const id of ids) {
    const target=page.locator(`[id="${id}"]`).first();
    try {
     await target.click({timeout:4500}).catch(()=>target.evaluate(e=>e.click()));
     const modal=page.locator('#portfolioModal');
     await modal.waitFor({state:'visible',timeout:4500});
     await page.waitForTimeout(260);
     meta.cards.push([id,await modal.innerText(),await modal.locator('a[href]').evaluateAll(els=>els.map(e=>[e.textContent,e.href]))]);
     await modal.locator('button').first().click({timeout:4500}).catch(()=>page.keyboard.press('Escape'));
     await modal.waitFor({state:'hidden',timeout:4500});
    } catch(error) {meta.cards.push([id,error.message]);}
   }
  }
  if(name==='havencrest') {
    const dropdown=page.locator('.Portfolio-filter .CustomDropdown:not(select)').first();
    await dropdown.click({timeout:7000});
    await dropdown.locator('li[data-value=".firm-current"]').click({timeout:7000});
    await page.waitForTimeout(1200);
  }
  const data=await collect(page);
  await fs.writeFile(path.join(__dirname,name+'-focused.json'),JSON.stringify({...data,http:res?.status(),...meta},null,2));
  await fs.writeFile(path.join(__dirname,name+'-focused.html'),await page.content());
  console.log(name,res?.status(),page.url());
 } catch(error) {console.log(name,error.message);}
 finally{await page.close();}
}

(async()=>{const ctx=await chromium.launchPersistentContext(path.join(__dirname,'profile-focus'),{channel:'chrome',headless:true,ignoreHTTPSErrors:true,viewport:{width:1420,height:950},args:['--disable-gpu','--disk-cache-size=8388608']});await Promise.all(specs.map(spec=>inspect(ctx,spec)));await ctx.close();})().catch(e=>{console.error(e);process.exitCode=1;});
