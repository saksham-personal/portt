import json,re,sys
from pathlib import Path

R=Path(__file__).parent
for p in sorted(R.glob('*-details.json')):
    if len(sys.argv)>1 and not any(x in p.name for x in sys.argv[1:]): continue
    d=json.loads(p.read_text(encoding='utf8'))
    print(p.name,d.get('http'),d.get('title'),d.get('url'), [l.strip()[:300] for l in d.get('text','').splitlines() if re.search(r'\b(current|active|realized|exited|exit|acquired|prior|holdings)\b',l,re.I)][:3])
