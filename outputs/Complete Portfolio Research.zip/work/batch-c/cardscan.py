import json,re,sys
from pathlib import Path
from urllib.parse import urlparse
R=Path(__file__).parent
for f in sorted(R.glob('*-'+(sys.argv[1] if len(sys.argv)>1 else 'portfolio')+'.json')):
    if len(sys.argv)>2 and not any(x in f.name for x in sys.argv[2:]): continue
    d=json.loads(f.read_text(encoding='utf8'))
    print('\n===',f.name,d.get('url'),d.get('http'))
    text=d.get('text','')
    if len(sys.argv)>2:
        print('TEXT:',text[:4500].replace('\n\n','\n'))
    else:
        print('STATUS:',[l.strip() for l in text.splitlines() if re.search(r'\b(current|realized|inactive|exited|active|holdings|platform investments|prior investments|portfolio companies)\b',l,re.I)][:34])
    if len(sys.argv)>2:
        print('LINKS:',list(dict.fromkeys((t,u.replace(urlparse(u).scheme+'://'+urlparse(u).netloc,'',1) if f.name.split('-')[0] in u else u) for t,u in d.get('links',[]) if u and re.search(r'(/investment|portfolio|companies|businesses|project|company|asset|current|exit|realized)',u,re.I) and u!=d.get('url')))[:45])
        print('IMGS:',list(dict.fromkeys((a,s.rsplit('/',1)[-1].split('?')[0]) for a,s,v in d.get('imgs',[]) if s and len(s)<350 and not re.search(r'logo|icon|banner|bg|arrow',s,re.I) or a and a.strip()))[:70])
