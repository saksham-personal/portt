import json,re
from pathlib import Path
from urllib.parse import urlparse
root=Path(__file__).parent
details=[]
for dom,rule in {'aldrichcap.com':r'/company/[^/]+/?$','tdpfund.com':r'/investment/[^/]+/?$','hildred.com':r'/portfolio/[^/#?]+/?$','rubiconfounders.com':r'/portfolio/[^/#?]+/?$','grantave.com':r'/portfolio/[^/#?]+/?$'}.items():
    data=json.loads((root/f'{dom}-portfolio.json').read_text(encoding='utf8'))
    for url in dict.fromkeys(l[1] for l in data['links']):
        m=re.fullmatch(rule,urlparse(url).path)
        if m:
            details.append((dom+'-'+m[0].strip('/').split('/')[-1],url))
details.extend([
 ('questacapital.com-page2','https://www.questacapital.com/portfolio?c0fdbb90_page=2&ac2c066e_page=2'),
 ('medequity.com-retry','https://medequity.com/our-portfolio/'),
 ('medequity.com-www','https://www.medequity.com/our-portfolio/'),
 ('medequity.com-current','https://medequity.com/current-or-realized/current/'),
 ('havencrest.com-retry','https://havencrest.com/investments/'),
 ('havencrest.com-www','https://www.havencrest.com/investments/'),
 ('consonancecapital.com-more','https://www.consonancecapitalpartners.com/portfolio-detail'),
 ('consonancecapital.com-venture','https://www.consonancecapital.com/'),
 ('bflexion.com-retry','https://bflexion.com/businesses'),
 ('bflexion.com-about','https://www.bflexion.com/about'),
 ('ardanequity.com-news','https://www.ardanequity.com/ardan-equity-news'),
 ('achievepartners.com-news','https://www.achievepartners.com/news.html')])
(root/'detail-urls.json').write_text(json.dumps(details),encoding='utf8')
