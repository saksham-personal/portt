from pathlib import Path
from bs4 import BeautifulSoup
import json,re,sys
R=Path(__file__).parent
def sp(name):
 return BeautifulSoup((R/f'{name}.html').read_text(encoding='utf8'),'lxml')
def txt(t): return t.get_text(' ',strip=True) if t else ''
def j(name): return json.loads((R/f'{name}.json').read_text(encoding='utf8'))
def show(h,x): print('\n',h,x)
if 'avego' in sys.argv:
 s=sp('avego.com-filtered2')
 for x in s.select('.status-current-private'):
  a=x.select_one('[data-open]'); target=s.find(id=a['data-open']) if a else None
  show(a and a.attrs,[(y.name,txt(y)) for y in target.select('h2,h3,h4,h5,h6')] if target else str(x)[:500]);
if 'medequity' in sys.argv:
 for n in ['medequity.com-filtered2','medequity.com-filtered','medequity.com-current-details','medequity.com-retry-details']:
  show(n,j(n).get('text','')[:6500]); print([(h.name,txt(h),h.parent.get('class')) for h in sp(n).select('h1,h2,h3,h4')][:40])
if 'havencrest' in sys.argv:
 s=sp('havencrest.com-retry-details')
 for x in s.find_all(string=lambda t:t and t.strip().casefold() in ['active','exited','current','former','prior firm investment','current & former']):
  y=x.parent; print([(p.name,p.attrs,txt(p)[:120]) for p in [y,y.parent,y.parent.parent,y.parent.parent.parent]])
if 'consonance' in sys.argv:
 d=j('consonancecapital.com-more-details'); print(d['text'][:4500]);
 for x in sp('consonancecapital.com-more-details').find_all(string=lambda t:t and t.strip().casefold()=='status: current'):
  p=x.parent
  print([(y.name,y.get('class'),txt(y)[:75]) for y in [p,p.parent,p.parent.parent,p.parent.parent.parent,p.parent.parent.parent.parent]])
if 'peloton' in sys.argv:
 s=sp('pelotonequity.com-filtered2')
 for x in s.select('.slide'):
  p=x.find('img'); q=x.select_one('.image-slide-title')
  print(txt(q), [p.get(y) for y in ['src','data-image','data-src','alt','data-image-focal-point']] if p else [], [a.get('href') for a in x.select('a[href]')])
if 'hildred' in sys.argv:
 for f in sorted(R.glob('hildred*-details.json')):
  d=j(f.stem); print(f.stem,d['title'],[d['text'].splitlines()[i:i+4] for i,l in enumerate(d['text'].splitlines()) if l.strip().lower() in ['status','fund','funds']][:5])
if 'navimed' in sys.argv:
 s=sp('navimed.com-filtered2')
 for i in s.select('img.mix.current,img.mix.partially-exited'):
  tar=s.select_one(i.get('data-target') or '#none'); print(i.get('data-target'),txt(tar)[:450],[(q.get('href'),txt(q)) for q in tar.select('a[href]')])
