const fs = require('node:fs/promises');
const path = require('node:path');
const { chromium } = require('C:/Users/eskay/AppData/Local/npm-cache/_npx/31e32ef8478fbf80/node_modules/playwright');

const domains = `www.1315capital.com www.belhealth.com www.amuletcapital.com www.medequity.com www.tdpfund.com www.lorientcap.com www.questacapital.com www.bflexion.com www.navimed.com www.aldrichcap.com www.ardanequity.com www.avego.com www.ironpathcapital.com www.consonancecapital.com achievepartners.com www.grantave.com www.ahpartners.com www.avesipartners.com www.concordhp.com www.pelotonequity.com www.hildred.com www.qhpcapital.com rallydaypartners.com rubiconfounders.com heritagemonaco.com www.havencrest.com riverglade.com www.ashlarcap.com`.split(' ');
const base = __dirname;
const slug = domain => domain.replace(/^www\./, '');
const nap = ms => new Promise(resolve => setTimeout(resolve, ms));
const collect = async page => page.evaluate(() => {
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const looksLikePortfolio = /\b(portfolio|investments|companies|investment portfolio|our investments|our holdings)\b/i;
  const links = Array.from(document.querySelectorAll('a[href]')).map(a => [clean(a.innerText || a.textContent || a.getAttribute('aria-label')), a.href]);
  const controls = [...document.querySelectorAll('button,select,[role=tab],[role=button],input[type=checkbox],input[type=radio],a[href]')]
    .filter(el => el.getClientRects().length)
    .map(el => [el.tagName, clean(el.innerText || el.textContent || el.getAttribute('aria-label')), el.getAttribute('href') || '', el.className?.baseVal || el.className, el.getAttribute('aria-pressed'), el.getAttribute('aria-selected')])
    .filter(([tag, label]) => tag !== 'A' || /^(current|active|realized|exited|past|all|former|next|more|load more|unrealized|as of|investment status)\b/i.test(label));
  const headings = [...document.querySelectorAll('main h1,main h2,main h3,main h4,main h5,main h6,article h1,article h2,article h3,h1,h2,h3')].map(el => [el.tagName, clean(el.innerText || el.textContent), el.getClientRects().length > 0]);
  const imgs = [...document.querySelectorAll('main img,article img,img')].map(el => [el.getAttribute('alt'),el.getAttribute('data-src') || el.getAttribute('src'), el.getClientRects().length > 0]);
  const cards = [...document.querySelectorAll('main a[href],#main a[href],[class*=portfolio] a[href],[class*=investment] a[href],a[href*="portfolio"],a[href*="investment"]')].map(el=>[clean(el.innerText || el.textContent || el.getAttribute('aria-label')),el.href,el.getClientRects().length>0,el.querySelector('img')?.alt || '',el.className,el.parentElement?.className]);
  return {title: document.title, url: location.href, links, nav: links.filter(([t,u]) => looksLikePortfolio.test(t) || /\/(portfolio|investments|companies)([/#?]|$)/i.test(u)), controls, headings, imgs, cards, text: document.body?.innerText || ''};
});

async function capture(page, url, target, filter='') {
  let response;
  let error = '';
  try {
    response = await page.goto(url, {waitUntil:'commit', timeout: 23000});
    await page.waitForLoadState('domcontentloaded', {timeout:10000}).catch(() => {});
    await page.waitForLoadState('load', {timeout:4000}).catch(() => {});
    await nap(400);
    if (filter) {
      await page.evaluate(() => {
        for (const el of document.querySelectorAll('button')) {
          if (/^(close dialog|reject all|deny|decline)$/i.test(el.innerText.trim() || el.getAttribute('aria-label') || '') && el.getClientRects().length) el.click();
        }
      });
      const role = filter === 'Load More' ? 'link' : 'button';
      const button = typeof filter === 'string' ? page.getByRole(role, {name:filter, exact:true}).first() : page.locator(filter.css).first();
      await button.click({timeout:4000}).catch(() => button.evaluate(el => el.click(), {timeout:4000}));
      await nap(1500);
      if (filter === 'Load More') {
        for (let step=0; step<10 && await button.isVisible(); step++) {
          await button.click({timeout:3000});
          await nap(900);
        }
      }
    }
  } catch (err) { error = err.message; }
  try {
    const info = await collect(page);
    info.http = response?.status();
    info.error = error;
    info.filter = filter;
    await fs.writeFile(target + '.json', JSON.stringify(info, null, 2));
    await fs.writeFile(target + '.html', await page.content());
    return info;
  } catch (err) {
    await fs.writeFile(target + '.json', JSON.stringify({error: error || err.message}, null, 2));
    return {error: error || err.message};
  }
}

async function main() {
  const pages = process.argv[2] ? JSON.parse(await fs.readFile(path.join(base, process.argv[2]), 'utf8')) : domains.map(d => [slug(d),'https://' + d]);
  const suffix = process.argv[3] || 'home';
  const filters = suffix.startsWith('filtered') ? JSON.parse(await fs.readFile(path.join(base,'filters.json'),'utf8')) : {};
  const ctx = await chromium.launchPersistentContext(path.join(base, `profile-${suffix}`), {channel:'chrome',headless:true,ignoreHTTPSErrors:true,viewport:{width:1420,height:1000},args:['--disable-gpu','--disk-cache-size=8388608']});
  await ctx.route('**/*', route => ['media','font'].includes(route.request().resourceType()) ? route.abort() : route.continue());
  const queue = [...pages];
  const workers = Array.from({length:7}, async () => {
    const page = await ctx.newPage();
    while (queue.length) {
      const [domain, url] = queue.shift();
      const data = await capture(page, url, path.join(base, slug(domain) + '-' + suffix), filters[domain]);
      process.stdout.write(`${domain} ${data.http || ''} ${data.url || ''} ${data.error?.split('\n')[0] || ''}\n`);
    }
    await page.close();
  });
  await Promise.all(workers);
  await ctx.close();
}

if (require.main === module) main().catch(err => {console.error(err); process.exitCode=1;});
module.exports = { collect, capture, domains, slug };
