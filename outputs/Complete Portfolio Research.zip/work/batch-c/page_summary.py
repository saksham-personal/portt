import json
import re
import sys
from pathlib import Path

root = Path(__file__).parent

for p in sorted(root.glob('*-portfolio.json')):
    if len(sys.argv)>1 and not any(x in p.name for x in sys.argv[1:]):
        continue
    d=json.loads(p.read_text(encoding='utf8'))
    print('\n' + p.name, d.get('url'), d.get('http'), (d.get('error') or '').splitlines()[:1])
    print('CONTROLS:', [(t,l,u) for t,l,u,*_ in d.get('controls',[]) if l and (re.search(r'current|active|realiz|all|past|exit|status|inactive|next|load|investment type',l,re.I) or t=='SELECT')][:35])
    rows=list(dict.fromkeys((l,visible) for t,l,visible in d.get('headings',[]) if l))
    print('HEAD:',rows[:180 if len(sys.argv)>1 else 36])
    if len(sys.argv)>1:
        print('TEXT:',d.get('text','')[:24000])
        print('IMAGES:',list(dict.fromkeys((a,s,v) for a,s,v in d.get('imgs',[]) if a or s))[:110])
