import html
import json
import re
from pathlib import Path
from urllib.parse import urljoin

from bs4 import BeautifulSoup

WORK = Path(__file__).resolve().parent
RAW = WORK / "batch-d" / "raw"
OUT = WORK.parent / "outputs" / "html" / "d"
OUT.mkdir(parents=True, exist_ok=True)
firms = []


def metadata(domain, stage):
    return json.loads((RAW / domain / (stage + ".json")).read_text(encoding="utf-8"))


def source_html(domain, stage):
    return BeautifulSoup((RAW / domain / (stage + ".html")).read_text(encoding="utf-8"), "html.parser")


def snapshot(domain, stage):
    return (RAW / domain / (stage + ".txt")).read_text(encoding="utf-8")


def value(text):
    return html.escape(str(text or ""), quote=True)


def remove_executable(soup):
    for tag in soup.select("script,iframe,object,embed,base,meta[http-equiv='refresh' i]"):
        tag.decompose()
    for tag in soup.find_all(True):
        for key in list(tag.attrs):
            if key.lower().startswith("on") or key.lower() in {"srcdoc", "formaction"}:
                del tag[key]
        if tag.get("href", "").strip().lower().startswith(("javascript:", "data:")):
            del tag["href"]


def add(domain, firm, state, method, notes, investments="", stages=("portfolio",), url=None, hide=None):
    domain_folder = OUT / domain.removeprefix("www.")
    domain_folder.mkdir(exist_ok=True)
    items = []
    stage_urls = {}
    for stage in stages:
        if (RAW / domain / (stage + ".json")).exists():
            stage_urls[stage] = metadata(domain, stage)["url"]
    url = url or next(iter(stage_urls.values()), "https://" + domain)
    if isinstance(investments, str):
        investments = investments.strip().splitlines()
    for entry in investments:
        if isinstance(entry, dict):
            items.append(entry)
            continue
        cols = [c.strip() for c in entry.split("|")]
        if cols[0]:
            name, company, status, source = (cols + [""] * 4)[:4]
            items.append({"name": name, "url": company, "status": status or method, "source": source or url})
    if len({row["name"].casefold() for row in items}) != len(items):
        raise ValueError(f"Duplicate names in {domain}")
    source_links = []
    for stage, source in stage_urls.items():
        soup = source_html(domain, stage)
        remove_executable(soup)
        if hide and stage in hide:
            for node in soup.select(hide[stage]):
                node.decompose()
        for tag in soup.find_all(True):
            for attr in ("href", "src", "poster"):
                if (link := tag.get(attr)) and not link.startswith(("#", "data:", "mailto:", "tel:")):
                    tag[attr] = urljoin(source, link)
        page = soup.body if soup.body else soup
        changes = " Browser-rendered HTML. Scripts and frames are removed. External styling and assets may require the original site."
        note = ""
        if hide and stage in hide:
            note = " Portfolio markup outside the selected status was removed to preserve the view."
        if soup.body:
            banner = soup.new_tag("aside", style="position:relative;z-index:2147483647;padding:12px;background:#eef6f5;color:#183c41;font:16px Arial")
            banner.append(f"{firm} | {stage.replace('-', ' ').title()} | 23 November 2026.{changes}{note} ")
            link = soup.new_tag("a", href=source)
            link.string = "Original page"
            banner.append(link)
            page.insert(0, banner)
        filename = stage + "-browser.html"
        (domain_folder / filename).write_text(str(soup), encoding="utf-8")
        source_links.append(f'<li><a href="{value(filename)}">{value(stage.replace("-", " ").title())} browser capture</a> · <a href="{value(source)}">Original page</a></li>')
    rows = []
    for item in items:
        company = f'<a href="{value(item["url"])}">{value(item["name"])}</a>' if item.get("url") else value(item["name"])
        evidence = item.get("source") or url
        rows.append(f'<tr><td>{company}</td><td>{value(item.get("status", method))}</td><td><a href="{value(evidence)}">Source</a></td></tr>')
    table = f'<table><thead><tr><th>Company or asset</th><th>Status evidence</th><th>Source</th></tr></thead><tbody>{"".join(rows)}</tbody></table>' if rows else "<p>No company names could be verified under this review status.</p>"
    backup = domain_folder / "index.html"
    backup.write_text(f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{value(firm)} portfolio evidence</title>
<style>body{{font:16px/1.55 system-ui,sans-serif;color:#17343a;margin:2.5rem auto;padding:0 1.4rem;max-width:1020px}}h1{{line-height:1.15}}a{{color:#08675e}}table{{width:100%;border-collapse:collapse}}th,td{{padding:.6rem .75rem;text-align:left;vertical-align:top;border-bottom:1px solid #cee0dd}}th{{background:#164e53;color:white}}tbody tr:nth-child(even){{background:#eff7f6}}.muted{{color:#4c6368}}</style></head>
<body><h1>{value(firm)}</h1><p class="muted">23 November 2026 · {value(state)} · {len(items)} active investment records</p>
<p>{value(method)}. {value(notes)}</p><p><a href="{value(url)}">Public source</a></p>
{table}
<h2>Browser HTML</h2>
<p>This index lists the extracted names in an offline-readable format. Browser captures preserve the source view used for the status check.</p>
<ul>{"".join(source_links)}</ul>
</body></html>""", encoding="utf-8")
    firms.append({
        "domain": domain, "firm": firm, "url": url, "state": state, "method": method,
        "notes": notes, "backups": [backup.relative_to(OUT.parent.parent).as_posix()],
        "archive_extras": [(domain_folder / (stage + "-browser.html")).relative_to(OUT.parent.parent).as_posix() for stage in stage_urls],
        "investments": items,
    })


def finalize():
    (WORK / "batch-d" / "results.json").write_text(json.dumps(firms, indent=2, ensure_ascii=False), encoding="utf-8")
    print(len(firms), "firms,", sum(len(f["investments"]) for f in firms), "active company records")
