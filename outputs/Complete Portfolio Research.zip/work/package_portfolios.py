import html
import json
import re
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import quote, urlparse
from zipfile import ZipFile, ZIP_DEFLATED

WORK = Path(__file__).resolve().parent
OUTPUTS = WORK.parent / "outputs"
BATCHES = ["a", "b", "c", "d"]
EXPECTED = (WORK / "agents-sites.txt").read_text().splitlines() + (WORK / "root-sites.txt").read_text().splitlines()
STATES = {"Verified", "Partial", "Unverified", "No public portfolio"}


def host(domain):
    return urlparse(domain if "://" in domain else "https://" + domain).netloc.lower().removeprefix("www.")


def safe_link(url):
    return url if urlparse(url).scheme in {"https", "http"} else ""


def escape(value):
    return html.escape(str(value or ""), quote=True)


all_firms = {}
missing_batches = []
for batch in BATCHES:
    path = WORK / f"batch-{batch}" / "results.json"
    if not path.is_file():
        missing_batches.append(batch)
        continue
    records = json.loads(path.read_text(encoding="utf-8-sig"))
    for record in records:
        key = host(record["domain"])
        if key in all_firms:
            raise ValueError(f"Duplicate domain: {key}")
        all_firms[key] = record

missing = [domain for domain in EXPECTED if host(domain) not in all_firms]
override_file = WORK / "team-overrides.json"
if override_file.is_file():
    for firm in json.loads(override_file.read_text(encoding="utf-8")):
        key = host(firm["domain"])
        original = all_firms[key]
        firm["archive_extras"].extend(original["backups"] + original.get("archive_extras", []))
        all_firms[key] = firm
extra = all_firms.keys() - {host(domain) for domain in EXPECTED}
if extra or (missing and "--allow-incomplete-batches" not in sys.argv):
    raise ValueError(f"Missing batches: {missing_batches}. Missing domains: {missing}. Unexpected: {sorted(extra)}")
for domain in missing:
    all_firms[host(domain)] = {
        "firm": domain,
        "state": "Unverified",
        "method": "Review incomplete",
        "notes": "No reviewed portfolio record was available.",
        "url": "https://" + domain,
        "backups": [],
        "investments": [],
    }

firms = [all_firms[host(domain)] for domain in EXPECTED]
all_backup_paths = set()
for firm, domain in zip(firms, EXPECTED, strict=True):
    firm["domain"] = domain
    firm["url"] = safe_link(firm["url"])
    if firm["state"] not in STATES:
        raise ValueError(f"Invalid coverage status for {domain}: {firm['state']}")
    names = []
    for investment in firm["investments"]:
        investment["name"] = " ".join(investment["name"].split())
        investment["url"] = safe_link(investment.get("url") or "")
        investment["source"] = safe_link(investment.get("source") or firm["url"])
        names.append(investment["name"].casefold())
    if "" in names or len(set(names)) != len(names):
        raise ValueError(f"Missing or duplicate names for {domain}: {names}")
    if names and firm["state"] in {"Unverified", "No public portfolio"}:
        raise ValueError(f"Unexpected active rows for {domain}")
    for relative in firm["backups"] + firm.get("archive_extras", []):
        path = (OUTPUTS / relative).resolve()
        if not path.is_relative_to(OUTPUTS.resolve()) or not path.is_file() or path.suffix != ".html":
            raise ValueError(f"Invalid backup path for {domain}: {relative}")
        all_backup_paths.add(path)
    if names and not firm["backups"]:
        raise ValueError(f"Active records have no HTML evidence file for {domain}")

(WORK / "portfolio-data.json").write_text(json.dumps(firms, ensure_ascii=False, indent=2), encoding="utf-8")
portfolio_count = sum(len(firm["investments"]) for firm in firms)
statuses = Counter(firm["state"] for firm in firms)
if "--prepare-only" in sys.argv:
    print(f"Prepared {portfolio_count} investment records from {len(firms) - len(missing)} reviewed websites")
    sys.exit(0)
rows = []
for index, firm in enumerate(firms, 1):
    backup = "<br>".join(f'<a href="{quote(path)}">HTML backup {n}</a>' for n, path in enumerate(firm["backups"], 1))
    original = f'<a href="{escape(firm["url"])}">{escape(firm["domain"])}</a>' if firm["url"] else escape(firm["domain"])
    rows.append(f'<tr><td>{index}</td><td>{escape(firm["firm"])}<br>{original}</td><td>{escape(firm["state"])}</td><td>{len(firm["investments"])}</td><td>{backup}</td><td>{escape(firm["notes"])}</td></tr>')

index = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Portfolio HTML archive</title>
<style>body{{font:15px/1.5 system-ui,sans-serif;max-width:1350px;margin:2rem auto;padding:0 1.4rem;color:#173b40}}h1{{line-height:1.2}}a{{color:#06685e}}table{{width:100%;border-collapse:collapse}}th,td{{padding:.6rem .65rem;text-align:left;vertical-align:top;border-bottom:1px solid #cee0dd}}th{{background:#184b51;color:#fff;position:sticky;top:0}}tr:nth-child(even){{background:#eef6f6}}.note{{max-width:850px;color:#455c60}}</style></head>
<body><h1>Portfolio HTML archive</h1><p>23 November 2026 · {len(firms)} websites · {portfolio_count:,} active investment records</p>
<p class="note">Extract the archive, then open this page. A backup may be a filtered browser capture, a readable export of source cards, or a record of the available source when portfolio status was incomplete. The workbook lists the evidence for each investment.</p>
<table><thead><tr><th>#</th><th>Firm and original URL</th><th>Coverage</th><th>Active rows</th><th>Backup</th><th>Review notes</th></tr></thead><tbody>{"".join(rows)}</tbody></table></body></html>"""
zip_path = OUTPUTS / "Portfolio HTML Backups.zip"
with ZipFile(zip_path, "w", ZIP_DEFLATED, compresslevel=6) as zipped:
    zipped.writestr("index.html", index)
    for path in sorted(all_backup_paths):
        zipped.write(path, path.relative_to(OUTPUTS.resolve()).as_posix())
with ZipFile(zip_path) as zipped:
    assert zipped.testzip() is None
    assert len(zipped.namelist()) == len(all_backup_paths) + 1
    assert all(backup in zipped.namelist() for firm in firms for backup in firm["backups"])
print(json.dumps({"sites": len(firms), "active_rows": portfolio_count, "sites_with_rows": sum(bool(firm["investments"]) for firm in firms), "coverage": dict(statuses), "html_files": len(all_backup_paths) + 1, "sites_with_backup": sum(bool(firm["backups"]) for firm in firms), "missing": missing}, ensure_ascii=False))
