"""Read public portfolio UI with Chrome and retain rendered evidence."""
import asyncio
import json
import re
import sys
from pathlib import Path
from urllib.parse import urljoin

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "batch-d" / "raw"
CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe"
DOMAINS = (ROOT / "root-sites.txt").read_text().splitlines()
NAVIGATION = re.compile(r"\b(portfolio|investments|companies|investing|partners|track record|holdings|platforms|transactions)\b", re.I)
NAV_LINKS = """() => [...document.querySelectorAll('a[href]')].filter(a => a.getClientRects().length).map(a => [((a.innerText || a.getAttribute('aria-label') || '').trim()), a.href])"""


async def observation(page, folder, filename, cards=None):
    try:
        await page.locator("body").wait_for(timeout=10000)
        await page.wait_for_load_state("domcontentloaded", timeout=7000)
    except Exception:
        pass
    folder.mkdir(parents=True, exist_ok=True)
    text, links, markup = await asyncio.gather(
        page.locator("body").inner_text(timeout=6500),
        page.evaluate(NAV_LINKS),
        page.content(),
    )
    (folder / (filename + ".html")).write_text(markup, encoding="utf-8")
    (folder / (filename + ".txt")).write_text(text, encoding="utf-8")
    captured_cards = {}
    for selector in cards or []:
        captured_cards[selector] = await page.locator(selector).evaluate_all("""nodes => nodes.map(el => ({
          text: el.innerText, html: el.outerHTML, id: el.id,
          images: Array.from(el.querySelectorAll('img')).map(i => [i.alt, i.currentSrc || i.src]),
          links: Array.from(el.querySelectorAll('a[href]')).map(a => [a.innerText, a.href])
        }))""")
    (folder / (filename + ".json")).write_text(
        json.dumps({"url": page.url, "title": await page.title(), "links": links, "cards": captured_cards}, ensure_ascii=False),
        encoding="utf-8",
    )
    print(folder.name, filename, page.url, len(text), flush=True)
    return links


def portfolio_choice(links):
    choices = {}
    for label, url in links:
        if not url.startswith(("https://", "http://")) or not label or len(label) > 70:
            continue
        clean = " ".join(label.lower().split())
        if clean in {"portfolio", "our portfolio", "investments", "our investments", "companies", "our companies", "portfolio companies", "current investments", "selected investments"}:
            score = 50
        elif NAVIGATION.search(clean) and re.search(r"/(portfolio|investments|companies|transactions|track-record)(?:[-/#?]|$)", url, re.I):
            score = 30
        else:
            continue
        choices[url] = max(score, choices.get(url, 0))
    return max(choices, key=choices.get) if choices else None


async def navigate(page, url):
    await page.goto(url, wait_until="commit", timeout=17500)


async def inspect(context, semaphore, domain, config=None):
    async with semaphore:
        folder = RAW / domain
        page = await context.new_page()
        try:
            if config is None:
                if (folder / "home.json").is_file():
                    links = json.loads((folder / "home.json").read_text(encoding="utf-8"))["links"]
                else:
                    await navigate(page, f"https://{domain}")
                    links = await observation(page, folder, "home")
                portfolio = portfolio_choice(links)
                if portfolio and portfolio != page.url and not (folder / "portfolio.json").is_file():
                    await navigate(page, portfolio)
                    await observation(page, folder, "portfolio")
            else:
                for item in config:
                    await navigate(page, item["url"])
                    if item.get("wait_for"):
                        await page.locator(item["wait_for"]).first.wait_for(timeout=9000)
                    for step in item.get("actions", []):
                        locator = page.locator(step["selector"]).nth(step.get("index", 0))
                        if "select" in step:
                            await locator.select_option(label=step["select"], timeout=6000)
                        elif "select_value" in step:
                            await locator.select_option(value=step["select_value"], timeout=6000)
                        elif "press" in step:
                            await locator.press(step["press"], timeout=6000)
                        else:
                            await locator.click(timeout=12000, force=step.get("force", False))
                        if step.get("wait_for"):
                            await page.locator(step["wait_for"]).first.wait_for(timeout=6500)
                        if step.get("wait_hidden"):
                            await page.locator(step["wait_hidden"]).first.wait_for(state="hidden", timeout=7500)
                    await observation(page, folder, item["id"], item.get("cards"))
        except Exception as error:
            print("ERROR", domain, str(error).splitlines()[0], flush=True)
        finally:
            await page.close()


async def main():
    config_path = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    configs = json.loads(config_path.read_text(encoding="utf-8-sig")) if config_path else None
    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            str(ROOT / "batch-d" / "chrome-profile"), executable_path=CHROME, headless=True,
            viewport={"width": 1440, "height": 1000},
            args=["--disable-gpu", "--disk-cache-size=8388608"],
        )
        limit = asyncio.Semaphore(5)
        if config_path and config_path.name == "team-bio-config.json":
            jobs = [inspect(context, limit, domain, [item]) for domain, items in configs.items() for item in items]
        else:
            domains = configs.keys() if configs is not None else DOMAINS
            jobs = [inspect(context, limit, domain, configs[domain] if configs is not None else None) for domain in domains]
        await asyncio.gather(*jobs)
        await context.close()


if __name__ == "__main__":
    asyncio.run(main())
