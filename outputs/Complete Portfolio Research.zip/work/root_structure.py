import json
import re
import sys
from pathlib import Path
from bs4 import BeautifulSoup

for directory in sorted((Path(__file__).parent / "batch-d" / "raw").iterdir()):
    if not any(s.lower() in directory.name.lower() for s in sys.argv[1:]):
        continue
    path = directory / "portfolio.html"
    path = path if path.exists() else directory / "home.html"
    if not path.exists():
        continue
    soup = BeautifulSoup(path.read_text(encoding="utf-8"), "html.parser")
    print("\n" + directory.name, flush=True)
    for elem in soup.select("img[alt],h2,h3,h4,select,button,li, a, [role='tab']"):
        value = elem.get_text(" ", strip=True)
        alt = elem.get("alt", "").strip()
        if alt:
            value = alt
        if elem.find_parent(["header", "footer", "nav"]):
            continue
        if not value or len(value) > 95:
            continue
        if elem.name == "a" and not re.search("current|active|partner|strateg|invest|exited|realiz|portfolio|visit|company|next|#|learn", value + (elem.get("href") or ""), re.I):
            continue
        parents = [f"{p.name}.{'.'.join(p.get('class', []))}" + (f"#{p['id']}" if p.get("id") else "") for p in list(elem.parents)[:3]]
        print(elem.name, value, elem.get("class"), elem.get("id"), elem.get("href"), elem.get("data-filter"), " < ".join(parents))
