"""Package the portfolio research and review registers using only Python's standard library."""

import csv
import hashlib
import io
import json
import os
import re
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OUT = ROOT / "outputs"
NAME = "Complete Portfolio Research.zip"
AS_OF = "2026-11-23"
WORKBOOK = "Current and Active Investments.xlsx"
ORIGINAL_BACKUP = "Portfolio HTML Backups.zip"

SKIP_DIRS = {
    "node_modules", "__pycache__", "artifact-tmp", "browser-tmp", "chrome-tmp",
    "chrome-profile", "daemon", ".git", ".venv", "venv", ".cache", "site-packages",
}
RUNTIME_PREFIXES = ("profile-", "playwright_chromiumdev_profile-")
RAW_SUFFIXES = {".html", ".htm", ".json", ".txt", ".yml", ".yaml", ".log"}
SCRIPT_SUFFIXES = {".py", ".js", ".mjs", ".cjs", ".ps1", ".sh"}

LABELS = {"Verified": "Verified", "Partial": "Partial", "No public portfolio": "Unavailable", "Unverified": "Unverified"}
EXPLICIT = {
    "current", "active", "active filter", "current filter", "unrealized", "private",
    "listed under active portfolio", "listed in all and outside realizations",
    "active investments section and explicit card status", "active status on portfolio cards",
    "current portfolio companies and unrealized status in all six card details",
    "active status on each selected investment tile", "current status on portfolio card",
    "current companies in investor biography", "current in 2026 announcement",
    "current group company or brand", "named current portfolio company or board position in firm biography",
    "current (after partial exit)", "active following recapitalization",
    "partial exit (hcp i), private (hep ii)", "exited (hep ii), private (hpp i)",
    "partial exit (hcp i), private (hpp i & hep iii)",
}


def link_paths(firm, key):
    return " | ".join("outputs/" + path for path in firm.get(key, []))


def coverage_flags(firm):
    state = firm["state"]
    notes = firm["notes"]
    if state == "No public portfolio":
        return "No public current portfolio was available. A blank portfolio cannot establish zero holdings."
    if state == "Partial":
        return "Only part of the firm's current portfolio could be established from public evidence."
    if state == "Unverified":
        return "The available evidence does not resolve current status."
    reasons = []
    if re.search(r"selected investments|selection of investments|representative|illustrative|does not include all|omitted from its site|not announced|not a complete", notes, re.I):
        reasons.append("The firm limits what it publishes.")
    if re.search(r"December 31, 2024", notes, re.I):
        reasons.append("The firm dates its portfolio disclosure to December 31, 2024.")
    if re.search(r"pending confirmation|logo-only|generic name|separate 13F filings", notes, re.I):
        reasons.append("See the scope or evidence issue in the coverage notes.")
    return " ".join(reasons)


def investment_flags(firm, item):
    name = item["name"]
    status = item["status"].strip().casefold()
    reasons = []
    if re.search(r"to be announced|unnamed|undisclosed|confidential|project paprika", name, re.I):
        reasons.append("The public evidence uses an anonymous label or project name.")
    if "name from logo" in status:
        reasons.append("The name was identified from a logo.")
    elif status.startswith("decheng 13f"):
        reasons.append("The evidence is a dated quarter-end securities filing.")
    elif status not in EXPLICIT:
        reasons.append("Current status relies on the listed source or inference rather than an explicit current or active label.")
    if firm["domain"] == "www.leavittequity.com":
        reasons.append("Firm disclosure is dated December 31, 2024.")
    return " ".join(reasons)


def csv_bytes(header, rows, excel=True):
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(header)
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8-sig" if excel else "utf-8")


def filtered_files(directory):
    for base, folders, files in os.walk(directory, followlinks=False):
        parent = Path(base)
        folders[:] = sorted(
            folder for folder in folders
            if folder.casefold() not in SKIP_DIRS
            and not folder.casefold().startswith(RUNTIME_PREFIXES)
            and not (parent / folder).is_symlink()
            and not (parent / folder).is_junction()
        )
        for filename in sorted(files):
            path = parent / filename
            lower = filename.casefold()
            if path.is_symlink() or lower in {".env", "cookies", "login data", "local state", "storage-state.json"}:
                continue
            if lower.startswith(".env.") or path.suffix.casefold() in {".pyc", ".pyo", ".pyd", ".dll", ".exe", ".so"}:
                continue
            yield path


firms = json.loads((WORK / "portfolio-data.json").read_text(encoding="utf-8"))
coverage_rows, investment_rows, review_rows = [], [], []
for firm in firms:
    domain, investor, state = (firm[field] for field in ("domain", "firm", "state"))
    coverage = LABELS[state]
    flags = coverage_flags(firm)
    site_review = "Yes" if flags else "No"
    backups = link_paths(firm, "backups")
    evidence = link_paths(firm, "archive_extras")
    coverage_rows.append([
        domain, investor, coverage, state, site_review, len(firm["investments"]),
        firm["url"], firm["method"], flags, firm["notes"], backups, evidence, AS_OF,
    ])
    if flags:
        review_rows.append(["Firm", domain, investor, "", coverage, "", flags, firm["notes"], firm["url"], backups, AS_OF])
    for item in firm["investments"]:
        row_reason = investment_flags(firm, item)
        investment_rows.append([
            domain, investor, item["name"], item["status"], item["source"], item["url"],
            coverage, site_review, "Yes" if row_reason else "No", row_reason, backups, AS_OF,
        ])
        if row_reason:
            review_rows.append([
                "Investment", domain, investor, item["name"], coverage, item["status"],
                row_reason, "", item["source"], backups, AS_OF,
            ])

tabular = {
    "data/active_investments.csv": csv_bytes([
        "domain", "investor", "company_or_asset", "status_evidence", "status_source_url", "company_or_detail_url",
        "firm_coverage", "firm_review_needed", "investment_review_needed", "investment_review_reason", "html_backup_paths", "review_date",
    ], investment_rows),
    "data/website_coverage.csv": csv_bytes([
        "domain", "investor", "coverage", "original_coverage_status", "review_needed", "investment_rows",
        "primary_url", "method", "review_reason", "coverage_notes", "html_backup_paths", "companion_html_paths", "review_date",
    ], coverage_rows),
    "data/review_needed.csv": csv_bytes([
        "record_type", "domain", "investor", "company_or_asset", "firm_coverage", "status_evidence",
        "review_reason", "coverage_notes", "source_url", "html_backup_paths", "review_date",
    ], review_rows),
}

counts = Counter(row[2] for row in coverage_rows)
review_counts = Counter(row[0] for row in review_rows)
assert len({row[0] for row in coverage_rows}) == len(coverage_rows) == 115
assert len({(row[0], row[2].casefold()) for row in investment_rows}) == len(investment_rows) == 1703
assert sum(row[5] for row in coverage_rows) == len(investment_rows)

readme = f"""# Portfolio research archive

Review date: 23 November 2026

Start with `data/website_coverage.csv` for the {len(coverage_rows)} requested domains or `data/active_investments.csv` for the {len(investment_rows):,} investor–investment rows. Open `outputs/index.html` after extraction to browse the HTML evidence. The delivered Excel workbook is in `outputs/`.

## Coverage and review

- **Verified ({counts['Verified']} sites)** means the identifiable public current portfolio was reviewed. Some firms limit what they publish. The source coverage and any additional review flag are shown separately.
- **Partial ({counts['Partial']} sites)** means the public record supports only a subset or leaves unresolved status or disclosure questions.
- **Unavailable ({counts['Unavailable']} sites)** means a public current portfolio was not available. Zero extracted rows do not establish zero holdings.
- **Review needed** identifies specific exceptions in `data/review_needed.csv`. It contains {review_counts['Firm']} firm-level entries and {review_counts['Investment']} investment-level entries. The two review fields in the investment CSV let you filter a firm-level gap separately from a record-level evidence issue.

The CSVs retain the original status evidence and source URLs. Their review flags distinguish inferences, dates and naming limits without changing the original investment roster.

## Archive layout

- `outputs/` contains the delivered workbook, the HTML index and the evidence files. Local links resolve within this directory. The earlier HTML-only ZIP is expanded here, so it does not need to be unpacked separately.
- `work/` retains scripts, configurations, raw HTML/text/JSON, intermediate extracts, original batch results, validation files and previews in their original paths. Raw and intermediate captures may show exited, historical, duplicated, blocked or superseded material. The consolidated CSVs and workbook identify the final selections. Browser-rendered raw HTML can include original site scripts or external resources. Use the evidence index for ordinary browsing.
- `file_manifest.csv` lists every included member other than itself, with its path, role, byte count and SHA-256 digest.

Dependency directories, browser profiles/session state, runtime caches and compiled libraries are excluded. The copied workbook in the working directory is omitted when its bytes match the delivered workbook. The original research scripts may reference locally installed Chrome, Python packages or the artifact-tool runtime. No dependencies are required to open the CSVs or read the HTML index.
"""


def file_role(name, path):
    if name.startswith("outputs/html/"):
        return "HTML evidence"
    if name.startswith("outputs/"):
        return "Delivered output"
    if path.suffix.lower() in SCRIPT_SUFFIXES:
        return "Script"
    if path.suffix.lower() in RAW_SUFFIXES:
        return "Research data, source capture or configuration"
    return "Working artifact"


manifest = []
target = OUT / NAME
stage = WORK / (NAME + ".building")


def store(zipped, path, data, role):
    zipped.writestr(path, data)
    manifest.append([path, role, len(data), hashlib.sha256(data).hexdigest()])


with ZipFile(stage, "w", compression=ZIP_DEFLATED, compresslevel=7) as zipped:
    store(zipped, "README.md", readme.encode("utf-8"), "Guide")
    for name, data in tabular.items():
        store(zipped, name, data, "Final data export")
    with ZipFile(OUT / ORIGINAL_BACKUP) as old:
        for name in old.namelist():
            data = old.read(name)
            disk = OUT / name
            if disk.is_file():
                assert disk.read_bytes() == data, f"HTML changed since delivery: {name}"
            store(zipped, "outputs/" + name, data, "HTML index" if name == "index.html" else "HTML evidence")
    included = {entry[0] for entry in manifest}
    for directory in (OUT, WORK):
        for path in filtered_files(directory):
            relative = path.relative_to(ROOT).as_posix()
            if relative in included or path in {stage, target, OUT / ORIGINAL_BACKUP}:
                continue
            data = path.read_bytes()
            if path == WORK / WORKBOOK and data == (OUT / WORKBOOK).read_bytes():
                continue
            store(zipped, relative, data, file_role(relative, path))
    zipped.writestr("file_manifest.csv", csv_bytes(["path", "role", "bytes", "sha256"], manifest))

with ZipFile(stage) as zipped:
    members = set(zipped.namelist())
    assert len(members) == len(zipped.namelist()) == len(manifest) + 1
    assert all("outputs/" + path in members for firm in firms for path in firm["backups"] + firm.get("archive_extras", []))
    assert zipped.testzip() is None
    for path, _, size, digest in manifest:
        data = zipped.read(path)
        assert len(data) == size and hashlib.sha256(data).hexdigest() == digest
    for name, expected in (
        ("active_investments", len(investment_rows)),
        ("website_coverage", len(coverage_rows)),
        ("review_needed", len(review_rows)),
    ):
        payload = zipped.read(f"data/{name}.csv").decode("utf-8-sig")
        assert sum(1 for _ in csv.DictReader(io.StringIO(payload))) == expected

stage.replace(target)
print(json.dumps({
    "files": len(manifest) + 1, "bytes": target.stat().st_size, "websites": len(coverage_rows),
    "investments": len(investment_rows), "coverage": counts, "review_queue": review_counts,
    "scripts": sum(role == "Script" for _, role, _, _ in manifest),
}, ensure_ascii=False))
