import asyncio
import os
from pathlib import Path
import json
import re
import sys
from playwright.async_api import async_playwright

ROOT = Path(__file__).parent
DOMAINS = '''shorecp.com aquiline.com svhealthinvestors.com frazierhealthcare.com websterequitypartners.com vivocapital.com ewhealthcare.com gppfunds.com rccf.com ampersandcapital.com vistria.com cpfounders.com dfwcapital.com avistahealthcare.com nms-capital.com waterstreet.com cresseyco.com bpoc.com firmament.com revelation-partners.com decheng.com altariscap.com archimed.group fulcrumep.com revelstokecapital.com windrose.com pharosfunds.com rs2healthcare.com'''.split()
PORTFOLIOS = dict([x.split('|') for x in '''
ewhealthcare.com|https://ewhealthcare.com/portfolio/
rccf.com|https://rccf.com/portfolio/
websterequitypartners.com|https://websterequitypartners.com/portfolio-category/current/
vistria.com|https://vistria.com/portfolio/
vistria-re|https://vistria.com/portfolio-real-estate/
cpfounders.com|https://cpfounders.com/founders-companies/
dfwcapital.com|https://dfwcapital.com/our-portfolio/
avistahealthcare.com|https://www.avistahealthcare.com/portfolio/
nms-capital.com|https://nms-capital.com/portfolio/
waterstreet.com|https://waterstreet.com/companies
cresseyco.com|https://www.cresseyco.com/partnerships
bpoc.com|https://www.bpoc.com/portfolio/
bpoc-all|https://www.bpoc.com/all-investments/
firmament.com|https://firmament.com/portfolio/
revelation-partners.com|https://revelation-partners.com/portfolio/
decheng.com|https://www.decheng.com/portfolio.html
altariscap.com|https://altariscap.com/our-companies
archimed.group|https://www.archimed.group/our-companies/
fulcrumep.com|https://www.fulcrumep.com/portfolio/
revelstokecapital.com|https://revelstokecapital.com/portfolio/
windrose.com|https://windrose.com/companies/
pharosfunds.com|https://www.pharosfunds.com/portfolio
rs2healthcare.com|https://rs2healthcare.com/portfolio/
'''.strip().splitlines()])

HOME_LINKS = '''() => [...document.querySelectorAll('a[href]')].map(a=>[(a.innerText||a.textContent||a.getAttribute('aria-label')||'').trim().replace(/\\s+/g,' ').slice(0,120),a.href]).filter(([label,url])=>/portfolio|investment|companies|partners|backed/i.test(label+' '+url)).filter(([label,url])=>/^https?:/i.test(url)).filter((x,i,a)=>a.findIndex(y=>y[1]===x[1])===i).slice(0,90)'''

async def inspect(context, domain, urls=None):
    p=await context.new_page()
    data={}
    try:
        urls = urls or ['https://www.'+domain+'/']
        for url in urls:
            try:
                await p.goto(url,wait_until='domcontentloaded',timeout=16000)
            except Exception:
                if p.url.startswith('about:') or 'chrome-error' in p.url: raise
        await p.wait_for_timeout(1100)
        data={'url':p.url,'title':await p.title(),'links':await p.evaluate(HOME_LINKS)}
        if domain in PORTFOLIOS and urls[0]==PORTFOLIOS[domain]:
            await p.locator('body').evaluate("el=>el.innerText")
            for offset in (350,1000,1600,0):
                await p.evaluate('(y)=>window.scrollTo(0,y)',offset)
                await p.wait_for_timeout(150)
            data['brief']=await p.evaluate(r'''() => {const v=e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden';const tx=e=>(e.textContent||'').trim().replace(/\s+/g,' ').slice(0,200);return { headings:[...document.querySelectorAll('main h1,main h2,main h3,main h4,main h5,article h1, article h2, h1,h2')].filter(v).slice(0,24).map(e=>[tx(e),e.className,e.parentElement.className]), controls:[...document.querySelectorAll('select,input,button,a,span,label')].filter(e=>v(e)&&e.children.length<3&&(/^(status|current|active|exited|realized|unrealized|prior|previous|see all|load more|show more|view more|next|all (status|portfolio|investment)|our (investment|compan))/i.test(tx(e))||e.tagName==='SELECT')).slice(0,40).map(e=>e.outerHTML.slice(0,550)), controls2:[...document.querySelectorAll('main select,main input,main [data-filter],main [data-status],main [class*=status]')].slice(0,12).map(e=>e.outerHTML.slice(0,350)), body:document.body.innerText.slice(0,9000) };}''')
            (ROOT/(domain+'.portfolio.html')).write_text(await p.content(),encoding='utf-8')
    except Exception as e:
        data={'error':str(e),'url':p.url}
    await p.close()
    suffix='portfolio' if domain in PORTFOLIOS and urls[0]==PORTFOLIOS[domain] else 'home'
    (ROOT/(domain+'.'+suffix+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(domain,data.get('title',data.get('error',''))[:160],flush=True)

async def browse(domains, stage):
    tmp=ROOT/'browser-tmp'
    tmp.mkdir(exist_ok=True)
    async with async_playwright() as pw:
        local=Path.home()/r'AppData\Local\ms-playwright\chromium-1234\chrome-win64\chrome.exe'
        browser=await pw.chromium.launch(executable_path=str(local),headless=True,env={**os.environ,'TEMP':str(tmp),'TMP':str(tmp)},args=['--disable-gpu','--disable-features=PersistentCache'])
        context=await browser.new_context()
        for offset in range(0,len(domains),8):
            await asyncio.gather(*(inspect(context,domain,[PORTFOLIOS[domain]] if stage=='port' else None) for domain in domains[offset:offset+8]))
        await browser.close()

if __name__=='__main__':
    stage='port' if 'port' in sys.argv else 'home'
    domains=[d for d in sys.argv[1:] if d!='port'] or (list(PORTFOLIOS) if stage=='port' else DOMAINS)
    asyncio.run(browse(domains,stage))
