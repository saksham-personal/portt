import asyncio,json,re,sys
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
from browser import ROOT,PORTFOLIOS
from extract import CONFIG,write_file,maybe_cookie,detail_get

async def revelation(ctx,p):
    active=p.locator('a[data-hash-id="active"]')
    await active.click(timeout=10000)
    grid=p.locator('#uc_post_grid_elementor_4035155')
    await grid.wait_for(state='attached',timeout=16000)
    for i in range(15):
        measure=await p.evaluate("()=>[...document.querySelectorAll('.uc-filter-load-more__data')].filter(e=>e.parentElement.getClientRects().length).map(e=>[e.dataset.more,e.dataset.nextoffset,e.parentElement.getBoundingClientRect().top])")
        count=await grid.locator('a[data-postid]').count()
        print('REVELATION PROGRESS',i,count,measure,flush=True)
        if measure and all(row[0]=='0' for row in measure):break
        await grid.evaluate("e=>window.scrollTo({top:e.getBoundingClientRect().bottom+window.scrollY-innerHeight/2,behavior:'instant'})")
        try:
            more=p.locator('.uc-filter-load-more__link:visible').first
            if await more.is_visible():await more.click(timeout=2000)
        except Exception:pass
        try:await p.wait_for_function("n=>document.querySelectorAll('#uc_post_grid_elementor_4035155 a[data-postid]').length>n",count,timeout=3600)
        except Exception:
            if i>=3:break
    return await p.evaluate(r'''()=>({url:location.href, controls:document.querySelector('a[data-hash-id="active"]').parentElement.outerHTML+([...document.querySelectorAll('.uc-filter-load-more__data')].filter(e=>e.parentElement.getClientRects().length).map(e=>e.outerHTML).join('')), cards:[...document.querySelectorAll('#uc_post_grid_elementor_4035155 a[data-postid]')].map(a=>({name:a.querySelector('img')?.alt||'',href:a.href,html:a.closest('.ue_post_grid_item').outerHTML}))})''')

async def chicago(ctx,p):
    async def complete(stage):
        def event(r):return 'admin-ajax.php' in r.url and r.request.method=='POST'
        async with p.expect_response(event,timeout=12000) as info:
            await p.locator(f'#CompanyMenu [data-slug="{stage}"] a').click(timeout=8000)
        response=await info.value
        print('CPF',stage,response.status,flush=True)
        (ROOT/f'cpf-{stage}-response.txt').write_text((await response.text())[:400000],encoding='utf-8')
        await p.wait_for_timeout(900)
        return await p.locator('#CompanyGrid a.item').evaluate_all('(e)=>e.map(a=>a.dataset.id)')
    initial=await p.locator('#CompanyGrid a.item').evaluate_all('(e)=>e.map(a=>a.dataset.id)')
    inactive=await complete('Exited')
    active=await complete('Active')
    print('CPF IDS',initial,inactive,active,flush=True)
    if active==initial or set(active)&set(inactive):return None
    data=await p.evaluate('''()=>({url:location.href,controls:document.querySelector('#CompanyMenu').outerHTML,cards:[...document.querySelectorAll('#CompanyGrid > a.item')].map(e=>({name:e.querySelector('img').src,href:'',html:e.outerHTML}))})''')
    (ROOT/'cpf-active-only.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    return None

async def archimed(ctx,p):
    current=p.locator('button[name="current_past"][value="current"]')
    await current.evaluate('e=>e.scrollIntoView({block:"center"})')
    try: await current.click(timeout=8500)
    except Exception as e:print('ARCHIMED CLICK',str(e)[:180],p.url,flush=True)
    await p.wait_for_load_state('domcontentloaded',timeout=12000)
    await p.wait_for_timeout(1500)
    if 'current_past=current' not in p.url:
        form=await current.evaluate('e=>new URL(e.form.action,location.href).href')
        url=form.split('#')[0]+'?current_past=current#company-list-anchor'
        await p.goto(url,wait_until='domcontentloaded',timeout=16000)
    await p.wait_for_timeout(2200)
    print('ARCHIMED',p.url,await p.locator('.bloc-carte-entreprise').count(),flush=True)
    return await p.evaluate('''()=>({url:location.href, controls:[...document.querySelectorAll('form.cards-filters-form')].map(e=>e.outerHTML).join(''),cards:[...document.querySelectorAll('.bloc-carte-entreprise a[href*="/companies/"]')].map(e=>({name:(e.querySelector('h2,h3,h4,strong')?.textContent||e.innerText||e.querySelector('img')?.alt||'').trim(),href:e.href,html:e.outerHTML}))})''')

async def task(ctx,key,func):
    p=await ctx.new_page()
    try:
        await p.goto(PORTFOLIOS[key],wait_until='domcontentloaded',timeout=22000)
        await p.wait_for_timeout(2500)
        await maybe_cookie(p)
        data=await func(ctx,p)
        if data:
            (ROOT/(key+'.recovery.json')).write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
        (ROOT/(key+'.recovery.html')).write_text(await p.content(),encoding='utf-8')
    except Exception as e:
        print('RECOVERY ERROR',key,str(e)[:700],flush=True)
        try:(ROOT/(key+'.recovery.html')).write_text(await p.content(),encoding='utf-8')
        except Exception:pass
    finally:
        await p.close()

async def main():
    async with async_playwright() as pw:
        local=Path.home()/r'AppData\Local\ms-playwright\chromium-1234\chrome-win64\chrome.exe'
        browser=await pw.chromium.launch(executable_path=str(local),headless=True,args=['--disable-gpu','--disable-features=PersistentCache'])
        ctx=await browser.new_context()
        keys={'revelation-partners.com':revelation,'archimed.group':archimed,'cpfounders.com':chicago}
        await asyncio.gather(*(task(ctx,k,func) for k,func in keys.items() if not sys.argv[1:] or k in sys.argv[1:]))
        await browser.close()

if __name__=='__main__':asyncio.run(main())
