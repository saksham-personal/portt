from pathlib import Path
from collections import Counter
from bs4 import BeautifulSoup
import html
import json
import re
from urllib.parse import urljoin, urlsplit
from browser import DOMAINS,PORTFOLIOS,ROOT
from extract import CONFIG,OUT,write_file

AVISTA=['Bentec Medical','Birchwell Consumer Health','Cooper Consumer Health','Cosette Pharmaceuticals','EBI','eMolecules','GCM','Northern Bio','OmniAb, Inc.','Organogenesis','PK Benelux','Probo Medical','Sanotact Group GmbH','Solmetex','Spear Education','Taconic Biosciences','Terrats Medical','Trillium','United BioSource Corporation','Vision Healthcare','Wellspring Consumer Healthcare','XiFin']
RC=['Theragen','Captive Radiology','Q Laboratories','The Blanchard Institute','Mosaic Diagnostics','Elucent Medical','Avive Solutions','Aligned Cardiovascular Partners','ModifyHealth','Cognitive Research Corporation','OnCall Staffing','Mindpath Health','Checkpoint Surgical','Endodontic Practice Partners','Spineology','Catalyst OrthoScience','Q’Apel Medical','Liquibase','OrthAlign','Urgent Team','Reputation','Netsertive','DialogTech']
WATER=['ALCOR Scientific','Allucent','Avantik','Brundage Group','Capstone','Catalyx','Discovery Life Sciences','EBMS','enableCV','EVERSANA','GlobalMed Logistix','Hansen Hunter','Imagine360','Liviniti','Long Grove Pharmaceuticals','Lumelight','Medical Guardian','MedSpeed','Pathnostics','Pillr Health','Renovo Solutions','Safeguard Medical','Solvias','Viant']
PHAROS=['Tribal Health','Family Treatment Network','Vantage Outsourcing','THEMA Health Services','Baroco Corporation','Sanderling','RhythMedix','Renal Care 360','FasPsych','Complete Health']
ARCHIMED=['3verest','Aliri','ARK Diagnostics','Arkstone','Biodextris','Biomark Scientific','BioVendor Group','Cardioline','CARSO','Cellese','Ceva Animal Health','Clean Biologics','Corealis','Cube Biotech','Dermapharm','Direct Healthcare Group','Esperion Therapeutics','ExcellGene','FIM Medical','Genetica','Groupe Laboratoire Rivadis','Instem','IRAB','IrriMax','Jeisys Medical','NAMSA','Natus Neuro','Natus Sensory','Organika','PlasmidFactory','Prollenium','Provepharm','Renata Medical','SeqCenter','Stago','Stragen','Suanfarma','Symbio','Title21 Health Solutions','WiQo','ZimVie','ZYTOMICS']
REVELATION=['Alpheus Medical','Arbor Biotechnologies','Artiva Biotherapeutics','Aspen Neuroscience','Biotheryx','BioTissue','Bluesight','Bristol Hospice','Cala Health','Carrick Therapeutics','Carrum Health','Cerapedics','Cityblock Health','Click Therapeutics','CNS Cares','Endeavor BioMedicines']
CPF_NAMES=['Allymar Health','Ascend Vision Partners','ATRIO Health Plans','CPF Living Communities','Duo Health','Gold Kidney Health Plan','Impact Advisors','SightMD','Marquee Dental Partners','Motion PT Group','MyCare Medical','Northpoint Behavioral Health','OMNY Health','P3 Health Partners','PEEQ Health','Pieper Veterinary','Pinnacle Dermatology','Qoros Cardiovascular Care','Recovery Ways','SAGE Veterinary Centers','Sage Health','Grace Management','Tredence','TriasMD','WellBe Senior Medical']
DEFAULTS={'ewhealthcare.com':('EW Healthcare Partners','The public portfolio is labeled Selected Portfolio Companies and mixes investment statuses. The site offers sector filters only.'),'decheng.com':('Decheng Capital','The public portfolio has sector filters and tags some acquisitions or IPOs, but does not mark or filter current holdings. IPO status alone does not establish whether shares are still held.'),'firmament.com':('Firmament','The public portfolio shows representative transactions across multiple pages. No current/realized status filter or complete active list was identified.'),'archimed.group':('ARCHIMED','The Current control was available, but the current-company grid did not render with names.'),'revelation-partners.com':('Revelation Partners','The Active grid is dynamic and the complete public list was not captured.'),'cpfounders.com':('Chicago Pacific Founders','The Active filter retained the same 25 logo cards as All after selection. The company popups and filter requests did not supply reliable active-only statuses for the retained entries.'),'rccf.com':('RC Capital','The status filter returned an active grid but its logo-only companies could not be normalized.'),'waterstreet.com':('Water Street Healthcare Partners','The Current Companies tab was found, but the output could not be validated.'),'pharosfunds.com':('Pharos Capital Group','The Current tab was found, but the output could not be validated.'),'rs2healthcare.com':('RS2 Healthcare Partners','The current portfolio could not be verified.')}

def load(p):
    return json.loads(p.read_text(encoding='utf-8'))

def fallback(url):
    return urlsplit(url).path.strip('/').rsplit('/',1)[-1].replace('-',' ').title()

def correct_avista():
    source=load(ROOT/'avistahealthcare.com.filtered.raw.json')
    if len(source['cards'])!=len(AVISTA): return
    for c,name in zip(source['cards'],AVISTA):
        c['name']=name
    cfg={**CONFIG['avistahealthcare.com'],'method':'Applied Current and matched the resulting company logos to their link labels'}
    write_file('avistahealthcare.com',source,cfg)

def add_portfolios():
    p=ROOT/'rccf.com.filtered.raw.json'
    if p.exists():
        source=load(p)
        if len(source['cards'])==len(RC) and source.get('val')=='Active':
            for c,n in zip(source['cards'],RC):c['name']=n
            write_file('rccf.com',source,{**CONFIG['rccf.com'],'method':'Applied Status > Active and identified the logos using the investment links'})
    for domain,filename,selector,control,names in [
        ('waterstreet.com','waterstreet.com.filtered.raw.html','#companies-current li a','nav.filters',WATER),
        ('pharosfunds.com','pharosfunds.com.portfolio.html','#w-tabs-0-data-w-pane-1 a.portfolio-grid_item','.w-tab-menu',PHAROS),
        ('rs2healthcare.com','rs2healthcare.com.portfolio.html','button.card[data-status=current]:not([hidden])','#portfolio-filter-status-value',None),
    ]:
        p=ROOT/filename
        if not p.exists():continue
        b=BeautifulSoup(p.read_text(encoding='utf-8'),'lxml')
        selected=b.select(selector)
        if names and len(selected)!=len(names): continue
        url=PORTFOLIOS[domain]
        data={'url':url,'controls':str(b.select_one(control)),'cards':[{'name':names[i] if names else e.select_one('.name').get_text(' ',strip=True),'href':urljoin(url,e.get('href')) if e.has_attr('href') else '', 'html':str(e)} for i,e in enumerate(selected)]}
        method={'waterstreet.com':'Opened the Current Companies tab and identified its linked company logos','pharosfunds.com':'Read the firm’s dedicated Current tab panel, matched to the visible Current filter','rs2healthcare.com':CONFIG[domain]['method']}[domain]
        write_file(domain,data,{**CONFIG[domain],'method':method})

def correct_vistria():
    p=ROOT/'vistria-re.filtered.raw.json'
    if not p.exists():return
    source=load(p)
    counts=Counter(c['name'] for c in source['cards'])
    for c in source['cards']:
        if counts[c['name']]>1:
            markup=BeautifulSoup(c['html'],'lxml')
            location=markup.select_one('.property-location').get_text(' ',strip=True)
            c['name']+=f' ({location})'
            if sum(z['name']==c['name'] for z in source['cards'])>1:
                when=markup.select_one('.property-date').get_text(' ',strip=True)
                c['name']+=f' ({when})'
    write_file('vistria-re',source,{**CONFIG['vistria-re'],'method':'Read the real estate portfolio and used the Acquisition, Development and Realized categories on the portfolio cards to exclude realized properties'})

def add_recovered():
    for domain,names in [('archimed.group',ARCHIMED),('revelation-partners.com',REVELATION)]:
        p=ROOT/(domain+'.recovery.json')
        if not p.exists():continue
        src=load(p)
        if len(src['cards'])!=len(names): continue
        for row,name in zip(src['cards'],names):row['name']=name
        opt=CONFIG[domain].copy()
        if domain=='revelation-partners.com':
            opt['notes']='The site discloses that some holdings are not public. After multiple scroll attempts the active grid remained on its first 16 entries, even while its pagination control reported more.'
            opt['method']='Selected Active with all categories and exported the rendered first batch'
            archive_path=ROOT/'revelation-archive-pages.json'
            record_path=ROOT/'rev-records.extra.json'
            taxonomy_path=ROOT/'rev-status.extra.json'
            if archive_path.exists() and record_path.exists() and taxonomy_path.exists():
                pages=load(archive_path)
                published=json.loads(load(record_path)['text'])
                taxonomy={t['slug']:t for t in json.loads(load(taxonomy_path)['text'])}
                active=taxonomy['active']
                if len(published)==active['count'] and not pages[-1]['next']:
                    full={c['href']:c for p in pages for c in p['cards']}
                    full.update({c['href']:c for c in src['cards'] if c['href'] not in full})
                    observed=(ROOT/'revelation-partners.com.active-cua.txt').read_text(encoding='utf-8')
                    for row in published:
                        if row['link'] not in full and row['link'] in observed:
                            detail=ROOT/'rev-dren.extra.json'
                            fragment=''
                            if detail.exists() and load(detail)['url']==row['link']:
                                document=BeautifulSoup(load(detail)['evidence'],'lxml')
                                headline=document.select_one('h1')
                                fragment=str(headline) if headline else ''
                            full[row['link']]={'href':row['link'],'name':row['title']['rendered'],'html':fragment+f'<p>Listed in the rendered Active grid and its published status records.</p><pre>{html.escape(json.dumps(row,ensure_ascii=False))}</pre>'}
                    if {r['link'] for r in published}==set(full):
                        src['cards']=[{**full[row['link']],'name':html.unescape(row['title']['rendered'])} for row in published]
                        src['controls']+='<p>Official Active classification: 55 published holdings.</p>'+''.join(f'<p>{html.escape(page["url"])}</p>' for page in pages)
                        opt['method']='Selected Active, followed all six pages of the official company archive, and reconciled the 55 published Active holdings with the site’s own status count'
                        opt['notes']='The firm states that some investments are withheld for permissions reasons. The public Active records include one company, Dren Bio, that was present in the filtered grid and absent from the category archive.'
        write_file(domain,src,opt)
    p=ROOT/'cpfounders.com.filtered.raw.json'
    b=ROOT/'cpf-Active-response.txt'
    if p.exists() and b.exists():
        src=load(p)
        s=BeautifulSoup(b.read_text(encoding='utf-8'),'lxml')
        entries=s.select('a.item[data-id]')
        if len(entries)==len(CPF_NAMES)==len(src['cards']):
            full=[]
            for node,name in zip(entries,CPF_NAMES):
                if name in ('SAGE Veterinary Centers','Motion PT Group','Pinnacle Dermatology','PEEQ Health','Grace Management'):continue
                full.append({'name':name,'href':'','html':str(node)})
            src['cards']=full
            cfg={**CONFIG['cpfounders.com'],'state':'Partial','method':'Applied Active and identified the publicly displayed company logos','notes':'CPF lists 27 current holdings on its overview and says that this grid is representative. Older cards with documented or unresolved status conflicts were omitted, including SAGE Veterinary Centers, Motion MSK, PeeqHealth and Pinnacle Dermatology. An additional logo with an uncertain identity was omitted.'}
            write_file('cpfounders.com',src,cfg)

def add_bpoc():
    p=ROOT/'bpoc-all.filtered.raw.json'
    dental=ROOT/'bpoc-dental.extra.json'
    xy=ROOT/'bpoc-renew.extra.json'
    if not (p.exists() and dental.exists() and xy.exists()):return
    src=load(p)
    d1=load(dental)
    nr=load(xy)
    if not ('Current' in d1['text'] and '(Partial) Exit Date' in d1['text'] and 'announced strategic investments' in nr['text']):return
    for name,doc in [('D4C Dental Brands',d1),('Master Medical Equipment',nr),('ReNew Biomedical',nr)]:
        s=BeautifulSoup(doc['evidence'],'lxml')
        entry=s.select_one('main') or s
        for e in entry.select('script,iframe,style,form'):e.decompose()
        src['cards'].append({'name':name,'href':doc['url'],'html':str(entry)})
    cfg={**CONFIG['bpoc-all'],'method':'Reconciled All Investments against the Current case-study status and a subsequent official investment announcement','notes':'D4C Dental Brands is still labeled Current after a partial exit. Master Medical Equipment and ReNew Biomedical are covered by BPOC’s August 24, 2026 investment announcement.'}
    write_file('bpoc-all',src,cfg)
    rowpath=ROOT/'bpoc.com.active.rows.json'
    data=load(rowpath)
    for r in data['investments']:
        if r['name']=='D4C Dental Brands':r['status']='Current (after partial exit)'
    rowpath.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')

def add_firmament():
    assets=[('firmament-home','h3','Firmament-Backed Matador Gas','Matador Gas'),('firmament-home','h3','Firmament-Backed BP Environmental Services','BP Environmental Services'),('firmament-prn','h2','Firmament Leads Strategic Combination of PRN Healthcare','PRN Healthcare (Nurses PRN)')]
    src={'url':PORTFOLIOS['firmament.com'],'controls':'Firmament publishes representative transactions. Recent dated primary-source stories establish the three holdings below.' ,'cards':[]}
    for key,sel,start,name in assets:
        p=ROOT/(key+'.extra.json')
        if not p.exists():continue
        doc=load(p)
        s=BeautifulSoup(doc['evidence'],'lxml')
        for x in s.select(sel):
            if not x.get_text(' ',strip=True).startswith(start):continue
            f=x.parent
            if key=='firmament-prn':
                title=x
                first=next((y for y in x.find_all_next('p') if 'June 22, 2026' in y.get_text(' ',strip=True)),None)
                fragment=str(title)+(str(first) if first else '')
            else:fragment=str(f)
            src['cards'].append({'name':name,'href':doc['url'],'html':fragment})
            break
    cfg={'firm':'Firmament','state':'Partial','status':'Current in 2026 announcement','suffix':'active','method':'Reviewed the unfiltered representative portfolio and confirmed three ongoing holdings from 2026 primary-source announcements','notes':'The mixed portfolio does not disclose an exhaustive current list. Add-ons described in the announcements were counted under their investment platforms.'}
    write_file('firmament.com',src,cfg)
    p=ROOT/'firmament.com.active.rows.json'
    if p.exists():
        d=load(p)
        d['backups']+=unresolved_backup('firmament.com','Firmament',PORTFOLIOS['firmament.com'],DEFAULTS['firmament.com'][1])
        p.write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')

def unresolved_backup(domain,firm,url,notes):
    p=ROOT/(domain+'.portfolio.html')
    if not p.exists(): return []
    stem=domain.replace('.','-')+'-mixed-portfolio.html'
    s=BeautifulSoup(p.read_text(encoding='utf-8'),'lxml')
    for e in s.select('script, iframe, style, link, object, embed, form'):e.decompose()
    message=s.new_tag('header')
    message['style']='padding:1rem; background:#f1f6fb; font:16px system-ui; border:1px solid #9bbacc;'
    h=s.new_tag('h1');h.string=firm+' — mixed portfolio source';message.append(h)
    t=s.new_tag('p');t.string='Captured 23 November 2026. '+notes;message.append(t)
    l=s.new_tag('a',href=url);l.string=url;message.append(l)
    s.body.insert(0,message)
    meta=s.new_tag('meta');meta['http-equiv']='Content-Security-Policy';meta['content']="default-src 'none'; img-src https: data:; style-src 'unsafe-inline';";s.head.insert(0,meta)
    (OUT/stem).write_text(str(s),encoding='utf-8')
    return ['html/a/'+stem]

def correct_gpp():
    rr=ROOT/'gppfunds.com.active.rows.json'
    if not rr.exists(): return
    d=load(rr)
    target='MLM Medical Labs'
    d['investments']=[c for c in d['investments'] if c['name']!=target]
    d['notes']='The firm calls its public portfolio list incomplete. Its September 9, 2026 announcement of the sale of MLM Medical Labs to Labcorp overrides the stale Current label. See https://www.gppfunds.com/news-insights/.'
    rr.write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')
    for b in d['backups']:
        out=OUT.parents[1]/b
        page=out.read_text(encoding='utf-8')
        page=re.sub(r'<article><h2>MLM Medical Labs</h2>.*?</article>','',page,flags=re.S)
        page=page.replace('15 visible portfolio entries in this capture.','14 current investments verified from 15 visible filtered entries. MLM Medical Labs is excluded based on the firm’s September 9, 2026 sale announcement.')
        out.write_text(page,encoding='utf-8')

def correct_shore():
    path=ROOT/'shorecp.com.active.rows.json'
    doc=load(path)
    doc['notes']='Two active platform cards share the name To Be Announced (Healthcare). Entry numbers distinguish their separate URLs.'
    out=OUT/'shorecp-com-active.html'
    data=out.read_text(encoding='utf-8')
    for idx,row in enumerate([r for r in doc['investments'] if r['name'].startswith('To Be Announced (Healthcare)')],1):
        base='To Be Announced (Healthcare)'
        new=f'{base} — entry {idx}'
        data=data.replace(f'<a href="{row["url"]}">{base}</a></h2>',f'<a href="{row["url"]}">{new}</a></h2>')
        row['name']=new
    out.write_text(data,encoding='utf-8')
    path.write_text(json.dumps(doc,ensure_ascii=False),encoding='utf-8')

def combine():
    records=[]
    for domain in DOMAINS:
        paths=sorted(ROOT.glob(domain+'.*.rows.json'))
        if domain=='cpfounders.com' and paths and 'https://' in load(paths[0])['investments'][0]['name']:
            paths=[]
        if not paths:
            firm,notes=DEFAULTS.get(domain,(domain,'No active list was verified.'))
            url=PORTFOLIOS.get(domain,'https://www.'+domain+'/')
            records.append({'domain':domain,'firm':firm,'url':url,'state':'Unverified','method':'Inspected the official public portfolio page and its controls','notes':notes,'backups':unresolved_backup(domain,firm,url,notes),'investments':[]})
            continue
        data=[load(x) for x in paths]
        data.sort(key=lambda x:x['url'].count('/') if domain=='websterequitypartners.com' else int('real-estate' in ''.join(x['backups'])))
        first=data[0]
        first['backups']=list(dict.fromkeys(b for d in data for b in d['backups']))
        if len(data)>1:
            first['method']='; '.join(dict.fromkeys(d['method'] for d in data))
            first['notes']=' '.join(dict.fromkeys(d['notes'] for d in data if d['notes']))
        first['investments']=list({((i['name'].casefold(),i['url']) if i['name'].casefold().startswith(('to be announced','company confidential')) else (i['name'].casefold(),'')): i for d in data for i in d['investments']}.values())
        records.append(first)
    (ROOT/'results.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
    print('SUMMARY',Counter(x['state'] for x in records),'TOTAL INVESTMENTS',sum(map(lambda x:len(x['investments']),records)))
    for r in records:
        print(r['state'],r['domain'],len(r['investments']),len(r['backups']))
        for b in r['backups']:
            path=OUT.parents[1]/b
            assert path.exists(), path
    assert len(records)==len({r['domain'] for r in records})==28

if __name__=='__main__':
    correct_avista()
    correct_gpp()
    correct_shore()
    add_portfolios()
    correct_vistria()
    add_recovered()
    add_bpoc()
    add_firmament()
    combine()
