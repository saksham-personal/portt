from pathlib import Path
from bs4 import BeautifulSoup as BS
import sys

select={
'avistahealthcare.com':'.portfolio-section__post',
'archimed.group':'a[href*="/companies/"],.cards-entreprise-filters',
'bpoc.com':'button[aria-label="Filter Button"]',
'bpoc-all':'h2',
'cpfounders.com':'#CompanyMenu,.category[data-category],img[alt],.companies-menu + *',
'cresseyco.com':'main a[href*="/partnerships/"]',
'decheng.com':'a[href*="http"],img',
'dfwcapital.com':'.portfolio-title',
'ewhealthcare.com':'.et_pb_portfolio_item',
'firmament.com':'a[href*="portfolio"],img[alt]',
'fulcrumep.com':'.portfolio-status.active, .custom-dropdown, #dropdown-status li',
'nms-capital.com':'.status-dropdown, article',
'pharosfunds.com':'a[href*="/portfolio/"]',
'revelation-partners.com':'a[data-hash-id="active"],.r-tabs-panel img[alt]',
'revelstokecapital.com':'.investment-tile__logo',
'rs2healthcare.com':'button.card,.select-option',
'vistria.com':'.fusion-portfolio-post',
'vistria-re':'.property-item',
'waterstreet.com':'#companies-current li a',
'windrose.com':'.portfolio-item[data-slug="current"]',
}
for d in sys.argv[1:] or select:
 s=BS(Path(__file__).with_name(d+'.portfolio.html').read_text(encoding='utf-8'),'lxml'); print('\n'+d,flush=True)
 for i,e in enumerate(s.select(select[d])):
  if i>6: break
  for t in [e,e.parent,e.parent.parent]:
   print(t.name, t.attrs, [(x.name,x.attrs, x.get_text(' ',strip=True)[:80]) for x in t.find_all(recursive=False)[:4]])
