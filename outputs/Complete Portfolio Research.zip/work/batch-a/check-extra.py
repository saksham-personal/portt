from pathlib import Path
import asyncio,json,re
import sys
from playwright.async_api import async_playwright
from browser import ROOT

URLS={
'rev-tax':'https://revelation-partners.com/portfolio-categories/all/',
'rev-index':'https://revelation-partners.com/wp-json/',
'rev-status':'https://revelation-partners.com/wp-json/wp/v2/portfolio-status?per_page=100',
'rev-records':'https://revelation-partners.com/wp-json/wp/v2/portfolio?portfolio-status=16&per_page=100&_fields=id,title,link,portfolio-status,portfolio-categories',
'bpoc-dental':'https://www.bpoc.com/portfolio/d4c-dental-brands/',
'bpoc-renew':'https://www.bpoc.com/insights/bpoc-partners-with-master-medical-equipment-and-renew-biomedical/',
'firmament-home':'https://firmament.com/',
'firmament-prn':'https://www.prnhealthservices.com/prn-joins-forces',
'rev-dren':'https://revelation-partners.com/portfolio/dren-bio/',
}

async def archive(ctx):
    p=await ctx.new_page()
    url='https://revelation-partners.com/portfolio-status/active/'
    pages=[]
    try:
        while url and len(pages)<20:
            await p.goto(url,wait_until='domcontentloaded',timeout=18000)
            data=await p.evaluate(r'''()=>({url:location.href,controls:document.querySelector('main h1,h1')?.outerHTML||'', cards:[...document.querySelectorAll('article.post h2.entry-title a')].map(a=>({name:a.innerText.trim(),href:a.href,html:a.closest('article').outerHTML})), next:[...document.querySelectorAll('a[href]')].find(a=>/^next\b/i.test(a.innerText.trim())&&a.href.includes('/portfolio-status/active/page/'))?.href||''})''')
            print('ACTIVE ARCHIVE',data['url'],len(data['cards']),flush=True)
            if not data['cards']:break
            pages.append(data)
            url=data['next']
            (ROOT/'revelation-active-pages.json').write_text(json.dumps(pages,ensure_ascii=False),encoding='utf-8')
    finally:
        await p.close()

async def one(ctx,key,url):
    p=await ctx.new_page()
    try:
        r=await p.goto(url,wait_until='domcontentloaded',timeout=18000)
        d=await p.evaluate(r'''()=>({url:location.href, title:document.title,text:document.body.innerText, evidence:document.querySelector('main')?.outerHTML||document.body.outerHTML, links:[...document.querySelectorAll('a[href]')].map(e=>[e.innerText,e.href])})''')
        (ROOT/(key+'.extra.json')).write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')
        if key=='rev-index':
            try:
                j=json.loads(d['text']);print(key,[x for x in j.get('routes',{}) if 'portfolio' in x[:70]],flush=True)
            except Exception:print(key,d['text'][:150],flush=True)
        else:print(key,r.status,d['title'],d['text'][:140],flush=True)
    except Exception as e:print(key,str(e)[:250],flush=True)
    finally:await p.close()

async def main():
    async with async_playwright() as pw:
        local=Path.home()/r'AppData\Local\ms-playwright\chromium-1234\chrome-win64\chrome.exe'
        br=await pw.chromium.launch(executable_path=str(local),headless=True,args=['--disable-gpu'])
        ctx=await br.new_context()
        keys=sys.argv[1:] or ['rev-records','rev-status']
        await asyncio.gather(*(one(ctx,k,URLS[k]) for k in keys))
        await br.close()

if __name__=='__main__':asyncio.run(main())
