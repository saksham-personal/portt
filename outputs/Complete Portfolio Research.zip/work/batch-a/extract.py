import asyncio
import html
import json
import os
import re
import sys
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
from browser import ROOT, PORTFOLIOS

OUT=ROOT.parents[1]/'outputs'/'html'/'a'

def d(firm, selector, name=None, *, attr=None, card=None, link=None, control='', action=None, method='', status='Current', notes='', state='Verified', detail=False, suffix='active', match=None):
    return dict(firm=firm, selector=selector, name=name, attr=attr, card=card, link=link, control=control, action=action, method=method, status=status, notes=notes, state=state, detail=detail, suffix=suffix, match=match)

CONFIG={
 'rccf.com':d('RC Capital','.post-list-ajax .cell > a','img',attr='alt',control='#all-statuses',action='rc',method='Applied Status > Active, then identified the companies on the linked detail pages',status='Active',detail=True),
 'vistria.com':d('The Vistria Group','.fusion-portfolio-post:not(.realizations)','.fusion-image-wrapper a',attr='aria-label',link='.fusion-image-wrapper a',control='.fusion-filters',method='Reviewed the flagship portfolio and removed cards classified by the site in its Realizations category',notes='Flagship equity. Realizations is the official exit category.'),
 'vistria-re':d('The Vistria Group','.property-item:not(.realized)','.property-title',control='.property-status-filters',action='vistria-re',method='Applied the Acquisition and Development filters separately and excluded the Realized category',notes='Real estate assets. Acquisition and Development are the statuses used for non-realized holdings.',suffix='active-real-estate'),
 'cpfounders.com':d('Chicago Pacific Founders','#CompanyGrid > a.item','img',attr='alt',control='#CompanyMenu',action='cpf',method='Applied Active and read the company details behind every visible logo',status='Active'),
 'dfwcapital.com':d('DFW Capital Partners','.portfolio-grid-widget:not(.portfolio-completed-grid-widget) .portfolio-title',card='.single-portfolio-item',link='a[href^="http"]',method='Read the Platform Companies section and the separately headed Exited Companies list',control='h1,h2,h3',action='dfw'),
 'avistahealthcare.com':d('Avista Healthcare Partners','.portfolio-section__post','img',attr='alt',link='a',control='.portfolio-section__filter',action='avista',method='Applied Current across the full public portfolio and checked company names on the linked investment pages',detail=True),
 'nms-capital.com':d('NMS Capital','.portfolio.filterable[data-filters~="current"] .portfolio-name',card='.portfolio.filterable',control='.status-dropdown',action='nms',method='Applied Status > Current with all industries selected'),
 'waterstreet.com':d('Water Street Healthcare Partners','#companies-current li a','img',attr='alt',control='nav.filters',action='water',method='Opened the Current Companies tab and identified the companies from their linked detail pages',detail=True),
 'cresseyco.com':d('Cressey & Company','#partners > li > a','img',attr='alt',control='#filter-current,#filter-prior,#partners-heading',action='cressey',method='Applied Current and identified the companies from their linked partnership pages',detail=True),
 'bpoc-all':d('BPOC','h2.ctUTsU',card='.text-box',control='h1',action='bpoc',method='Read the full All Investments disclosure and verified investment dates and absence of a full exit date',notes='BPOC identifies this as the full list. A partial exit was excluded unless independently shown as active.',status='Current'),
 'revelation-partners.com':d('Revelation Partners','.r-tabs-panel.r-tabs-state-active img[alt]',attr='alt',control='a[data-hash-id]',action='revelation',method='Opened the Active tab with all categories selected',status='Active',notes='The site states some holdings are omitted for lack of permission rights.',state='Partial'),
 'altariscap.com':d('Altaris','main button.group img[alt]',attr='alt',card='button',control='main h1,main section button:not(.group)',method='Used the main Our Companies grid, which links separately to prior companies',notes='Altaris describes the published list as illustrative and incomplete.',state='Partial'),
 'archimed.group':d('ARCHIMED','a[href*="/companies/"]','h3',control='form.cards-filters-form',action='archimed',method='Applied the Current status across all sectors and territories'),
 'fulcrumep.com':d('Fulcrum Equity Partners','.portfolio-status.active',card='.item',link='a[href*="/portfolio-details/"]',control='#portfolio-filter',action='fulcrum',method='Used the Active status on each row of the all-investments grid and identified companies on detail pages',status='Active',detail=True),
 'revelstokecapital.com':d('Revelstoke Capital Partners','.investment-tile[data-apm-investment-tile-filters~="current"] h3',card='.investment-tile',link='a[href]',control='.investment-grid-header__filters',action='revelstoke',method='Applied the Current filter and read each visible investment tile'),
 'windrose.com':d('WindRose Health Investors','.portfolio-item[data-slug="current"]',attr='data-name',control='.filters-container',action='windrose',method='Verified the default Current filter and extracted the corresponding portfolio cards'),
 'pharosfunds.com':d('Pharos Capital Group','.w-tab-pane.w--tab-active a.portfolio-grid_item','img',attr='alt',control='.w-tab-menu',action='pharos',method='Opened the Current tab and identified each investment from its linked detail page',detail=True,state='Partial',notes='Pharos says its displayed investments are illustrative. The complete list is available from the firm on request.'),
 'rs2healthcare.com':d('RS2 Healthcare Partners','button.card[data-status="current"]','.name',control='[data-portfolio-filter="status"],#portfolio-filter-status-value',method='Verified that the Status selector defaults to Current with both Healthcare and Technology included'),
}

JS=r'''o=>{
 const txt=e=>(e?.textContent||'').trim().replace(/\s+/g,' '); const vis=e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden';
 let es=[...document.querySelectorAll(o.selector)].filter(vis);
 return {url:location.href,title:document.title,controls:o.control?[...document.querySelectorAll(o.control)].slice(0,15).map(e=>e.outerHTML).join('\n'):'', cards:es.flatMap(e=>{
  const c=o.card?e.closest(o.card):e;
  if(!c)return [];
  if(o.action==='bpoc'&&(!/Investment Date/i.test(txt(c))||/Exit Date/i.test(txt(c))))return [];
  const n=o.name?e.querySelector(o.name):e;
  let name=o.attr?n?.getAttribute(o.attr)||'':txt(n);
  if(o.action==='cpf')name=n?.getAttribute('src')||'';
  if(o.action==='archimed'&&!name)name=txt(c.querySelector('h2,h3,h4,strong'))||c.querySelector('img[alt]')?.alt||txt(c);
  if(o.action==='fulcrum')name=c.querySelector('img[alt]')?.alt||'';
  if(o.action==='vistria-re'&&!name)name=txt(c.querySelector('h2,h3,h4,h5,strong'));
  let a=o.link?c.querySelector(o.link):c.closest('a[href]')||c.querySelector('a[href]');
  let href=a?.getAttribute('href')||'';
  if(!/^(https?:|\/|#[^#])/i.test(href))href='';else href=new URL(href,location.href).href;
  if(o.action==='bpoc')href='';
  return [{name,href,html:c.outerHTML}];
 })};
}'''

async def wait_change(p, selector, previous, timeout=6500):
    try:
        await p.wait_for_function('([s,h])=>document.querySelector(s)?.innerHTML!==h',[selector,previous],timeout=timeout)
    except Exception:
        await p.wait_for_timeout(500)

async def maybe_cookie(p):
    buttons=p.get_by_role('button',name=re.compile(r'^(?:Reject All(?: Cookies)?|Reject|Decline(?: All)?|Necessary Only|Only Necessary Cookies)$',re.I))
    for b in await buttons.all():
        if await b.is_visible():
            try: await b.click(timeout=1200)
            except Exception: pass
            break

async def act(p,o):
    action=o['action']
    if action=='rc':
        before=await p.locator('.post-list-ajax').first.evaluate('e=>e.innerHTML')
        await p.locator('.input-status2').click(timeout=8000)
        await p.locator('.statuses-list2 label[data-post="active"]').click(timeout=6500)
        await wait_change(p,'.post-list-ajax',before)
        await p.wait_for_function("()=>document.querySelector('.input-status2')?.value.toLowerCase()==='active'",timeout=3500)
    elif action=='cpf':
        await p.locator('#CompanyMenu [data-slug="Active"] a').click(timeout=5000)
        await p.wait_for_timeout(1700)
    elif action=='avista':
        before=await p.locator('#portfolio-section-posts').first.evaluate('e=>e.innerHTML')
        await p.get_by_role('button',name='Current',exact=True).click(timeout=6500)
        await wait_change(p,'#portfolio-section-posts',before)
    elif action=='nms':
        await p.locator('.status-dropdown').select_option('current',timeout=5000)
        await p.wait_for_timeout(1000)
    elif action=='water':
        await p.locator('#filter-current').click(timeout=6000)
    elif action=='cressey':
        before=await p.locator('#partners').first.evaluate('e=>e.innerHTML')
        await p.locator('#filter-current').click(timeout=6500)
        await wait_change(p,'#partners',before)
    elif action=='revelation':
        await p.locator('a[data-hash-id="active"]').click(timeout=5000)
        await p.wait_for_timeout(1200)
    elif action=='archimed':
        await p.locator('button[name="current_past"][value="current"]').click(timeout=6000)
        await p.wait_for_timeout(1300)
    elif action=='revelstoke':
        await p.locator('[data-apm-investment-grid-filter="current"]').click(timeout=6000)
    elif action=='pharos':
        await p.get_by_role('tab',name='Current',exact=True).click(timeout=6500)
    if action:
        await p.wait_for_timeout(550)

detail_sem=asyncio.Semaphore(5)
async def detail_get(ctx,source,card):
    if not card['href'] or urlsplit(card['href']).netloc!=urlsplit(source).netloc:
        return card
    async with detail_sem:
        p=await ctx.new_page()
        try:
            await p.goto(card['href'],wait_until='domcontentloaded',timeout=14000)
            h=await p.evaluate(r'''()=>{const txt=e=>(e?.textContent||'').trim().replace(/\s+/g,' ');const h=[...document.querySelectorAll('main h1,article h1,h1')].find(x=>txt(x)&&!x.classList.contains('sr-only'));return {name:txt(h),html:h?.outerHTML||'',title:document.title,meta:document.querySelector('meta[property="og:title"]')?.content}}''')
            name=h['name'] or h.get('meta') or h['title']
            name=re.split(r'\s+[|–-]\s+(?:RC Capital|Avista Healthcare|Pharos Capital Group|Fulcrum(?: Equity Partners)?|Water Street|Cressey & Company).*',name)[0]
            if name and name.lower() not in ('rc capital','water street','portfolio','access denied','home','error','fulcrum'):
                card['name']=name
                card['detail']=h['html']
        except Exception as e:
            print('DETAIL ERROR',card['href'],str(e)[:100],flush=True)
        finally:
            await p.close()
        return card

def write_file(key,data,o):
    domain={'vistria-re':'vistria.com','bpoc-all':'bpoc.com'}.get(key,key)
    title=f"{o['firm']} — {o['status']}"
    esc=html.escape
    seen=set()
    rows=[]
    cards=[]
    for row in data['cards']:
        name=re.sub(r'\s+(?:Logo|Logotype)$','',row['name'],flags=re.I).strip()
        if not name or name.casefold() in seen:
            continue
        seen.add(name.casefold())
        url=row['href']
        rows.append({'name':name,'url':url,'status':o['status']})
        frag=row['html']+row.get('detail','')
        frag=re.sub(r'<(?:script|iframe)[\s\S]*?</(?:script|iframe)>','',frag,flags=re.I)
        frag=re.sub(r'\s+on[a-z]+=(?:"[^"]*"|\'[^\']*\'|[^\s>]+)','',frag,flags=re.I)
        link=f'<a href="{esc(url)}">{esc(name)}</a>' if url else esc(name)
        cards.append(f'<article><h2>{link}</h2><details><summary>Original portfolio entry markup</summary>{frag}</details></article>')
    print(key,len(rows),[r['name'] for r in rows[:5]],flush=True)
    if not rows:
        return
    filename=domain.replace('.','-')+'-'+o['suffix']+'.html'
    doc=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src https: data:; style-src 'unsafe-inline';"><title>{esc(title)}</title><style>body{{font:16px system-ui,sans-serif;margin:2rem auto;max-width:1100px;padding:0 1.3rem;color:#172534}}h1{{margin-bottom:.2rem}}header{{border-bottom:2px solid #3b6679;padding-bottom:1rem}}article{{border-bottom:1px solid #d6e0e5;padding:1rem 0}}article h2{{font-size:1.12rem;margin:.3rem 0}}img,svg{{max-width:240px;max-height:100px;object-fit:contain}}a,summary{{color:#365d6e}}pre{{white-space:pre-wrap}}</style><header><h1>{esc(title)}</h1><p><a href="{esc(data['url'])}">{esc(data['url'])}</a></p><p>Captured 23 November 2026. {esc(o['method'])}. {len(rows)} entries.</p><p>{esc(o['notes'])}</p><p>Rendered portfolio entries are preserved below as static HTML using the live browser DOM.</p><details><summary>Captured filter or section markup</summary><pre>{esc(data['controls'])}</pre></details></header><main>{''.join(cards)}</main></html>'''
    (OUT/filename).write_text(doc,encoding='utf-8')
    result=dict(domain=domain,firm=o['firm'],url=data['url'],method=o['method'],notes=o['notes'],state=o['state'],backups=['html/a/'+filename],investments=rows)
    (ROOT/(domain+'.'+o['suffix']+'.rows.json')).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')

async def inspect(ctx,key):
    o=CONFIG[key]
    p=await ctx.new_page()
    try:
        await p.goto(PORTFOLIOS[key],wait_until='domcontentloaded',timeout=22000)
        await p.wait_for_timeout(1000)
        await maybe_cookie(p)
        try:
            await act(p,o)
        except Exception as e:
            print(key,'ACTION ERROR',str(e)[:220],flush=True)
            (ROOT/(key+'.failed.html')).write_text(await p.content(),encoding='utf-8')
            return
        for offset in (450,900,1450,0):
            await p.evaluate('(y)=>window.scrollTo(0,y)',offset)
            await p.wait_for_timeout(100)
        data=await p.evaluate(JS,o)
        (ROOT/(key+'.filtered.raw.html')).write_text(await p.content(),encoding='utf-8')
        (ROOT/(key+'.filtered.raw.json')).write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    except Exception as e:
        print(key,'ERROR',str(e)[:260],flush=True)
        return
    finally:
        await p.close()
    if o['detail']:
        data['cards']=await asyncio.gather(*(detail_get(ctx,data['url'],c) for c in data['cards']))
        (ROOT/(key+'.filtered.details.json')).write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    write_file(key,data,o)

async def main(keys):
    async with async_playwright() as pw:
        local=Path.home()/r'AppData\Local\ms-playwright\chromium-1234\chrome-win64\chrome.exe'
        browser=await pw.chromium.launch(executable_path=str(local),headless=True,args=['--disable-gpu','--disable-features=PersistentCache'])
        ctx=await browser.new_context()
        for offset in range(0,len(keys),8):
            await asyncio.gather(*(inspect(ctx,k) for k in keys[offset:offset+8]))
        await browser.close()

if __name__=='__main__':
    asyncio.run(main(sys.argv[1:] or list(CONFIG)))
