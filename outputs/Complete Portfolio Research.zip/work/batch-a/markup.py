from bs4 import BeautifulSoup
from pathlib import Path
import re, sys

for n in sys.argv[1:]:
    f=Path(__file__).with_name(n+'.portfolio.html')
    if not f.exists(): continue
    ss=BeautifulSoup(f.read_text(encoding='utf-8'),'lxml')
    def info(e):
        return f'{e.name}#{e.get("id","")}.{e.get("class",[])} {e.get("href","")} {e.get("data-slug","")} {e.get("alt","")} {e.get_text(" ",strip=True)[:75]}'
    print('\n',n)
    for match in [lambda x: x.name in ['button','a','li','option','span','label'] and re.fullmatch(r'(?:current|active|prior|past|realized|exited|unrealized|current companies|view prior companies|status|realizations|acquisition|development)\s*', x.get_text(' ',strip=True), re.I),lambda x: x.name in ['img'] and x.find_parent(['main','article']) is not None and not re.search(r'bg|background|icon|pattern|hero|^$',x.get('alt',''),re.I)]:
        for e in ss.find_all(match,limit=6):
            print(' | '.join(info(x) for x in [e,e.parent,e.parent.parent,e.parent.parent.parent]))
