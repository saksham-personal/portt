import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const work = path.dirname(fileURLToPath(import.meta.url));
const output = process.argv.includes("--preview") ? work : path.resolve(work, "../outputs");
const firms = JSON.parse(await fs.readFile(path.join(work, "portfolio-data.json"), "utf8"));
const workbook = Workbook.create();
const investments = firms.flatMap(firm => firm.investments.map(item => ({
  firm: firm.firm,
  domain: firm.domain,
  name: item.name,
  evidence: item.status || firm.method,
  source: item.source || firm.url,
  company: item.url && item.url !== (item.source || firm.url) ? item.url : "",
})));
const verified = firms.filter(firm => firm.state === "Verified").length;
const firmWithRows = firms.filter(firm => firm.investments.length > 0).length;

function columnName(index) {
  return String.fromCharCode(65 + index);
}

function layout(sheet, name, subtitle, columns, entries, tableName) {
  sheet.showGridLines = false;
  sheet.tabColor = "#176764";
  const lastColumn = columnName(columns.length - 1);
  const endRow = entries.length + 4;
  sheet.getRange(`A1:${lastColumn}${endRow}`).format.font = { name: "Aptos", size: 11, color: "#20353B" };
  sheet.mergeCells(`A1:${lastColumn}1`);
  sheet.mergeCells(`A2:${lastColumn}2`);
  sheet.getRange("A1").values = [[name]];
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange(`A1:${lastColumn}1`).format = {
    fill: "#143C42", font: { name: "Aptos", size: 20, bold: true, color: "#FFFFFF" },
    rowHeight: 37, verticalAlignment: "center",
  };
  sheet.getRange(`A2:${lastColumn}2`).format = {
    fill: "#E7F4F2", font: { name: "Aptos", size: 11, color: "#245354" },
    rowHeight: 27, verticalAlignment: "center",
  };
  for (const [index, column] of columns.entries()) {
    const letter = columnName(index);
    sheet.getRange(`${letter}:${letter}`).format.columnWidthPx = column.width;
  }
  sheet.getRange(`A4:${lastColumn}4`).values = [columns.map(column => column.header)];
  if (entries.length) sheet.getRange(`A5:${lastColumn}${endRow}`).values = entries;
  const table = sheet.tables.add(`A4:${lastColumn}${Math.max(endRow, 5)}`, true, tableName);
  table.style = "TableStyleMedium2";
  table.showFilterButton = true;
  sheet.getRange(`A4:${lastColumn}4`).format = {
    fill: "#1C6566", font: { name: "Aptos", size: 11, bold: true, color: "#FFFFFF" },
    rowHeight: 25, verticalAlignment: "center",
  };
  if (entries.length) {
    const body = sheet.getRange(`A5:${lastColumn}${endRow}`);
    body.format.verticalAlignment = "center";
    body.format.wrapText = true;
    body.format.autofitRows();
  }
  sheet.freezePanes.freezeRows(4);
}

const active = workbook.worksheets.add("Active Investments");
layout(active, "Current and active investments",
  `${investments.length.toLocaleString("en-US")} investor–investment records across ${firmWithRows} sites  |  Reviewed 23 November 2026`,
  [
    { header: "Investor", width: 230 },
    { header: "Company or asset", width: 295 },
    { header: "Status evidence", width: 290 },
    { header: "Status source URL", width: 360 },
    { header: "Company or detail URL", width: 325 },
    { header: "Input domain", width: 210 },
  ],
  investments.map(row => [row.firm, row.name, row.evidence, row.source, row.company, row.domain]),
  "ActiveInvestments");

const coverage = workbook.worksheets.add("Website Coverage");
layout(coverage, "Website coverage",
  `${firms.length} requested sites  |  ${verified} with all identifiable active entries from the public source  |  HTML paths refer to the companion archive`,
  [
    { header: "Input domain", width: 210 },
    { header: "Investor or organization", width: 245 },
    { header: "Coverage", width: 155 },
    { header: "Active rows", width: 96 },
    { header: "Method", width: 275 },
    { header: "Notes and limits", width: 440 },
    { header: "Primary URL", width: 350 },
    { header: "HTML backup path", width: 260 },
  ],
  firms.map(firm => [firm.domain, firm.firm, firm.state, firm.investments.length, firm.method, firm.notes, firm.url, firm.backups.join("\n")]),
  "WebsiteCoverage");

for (const [index, firm] of firms.entries()) {
  if (firm.state === "Verified") continue;
  const status = coverage.getRange(`C${index + 5}`);
  status.format.fill = firm.state === "Partial" ? "#FFF1D5" : "#F1E9EC";
  status.format.font = { name: "Aptos", color: "#59361C", bold: true, size: 11 };
}

workbook.recalculate();
for (const [sheet, lastColumn] of [[active, "F"], [coverage, "H"]]) {
  const check = await workbook.inspect({
    kind: "table", range: `'${sheet.name}'!A4:${lastColumn}8`,
    include: "values", tableMaxRows: 5, tableMaxCols: 8,
  });
  console.log(check.ndjson);
  const preview = await workbook.render({ sheetName: sheet.name, range: `A1:${lastColumn}9`, scale: 1, format: "png" });
  await fs.writeFile(path.join(work, `${sheet.name.toLowerCase().replaceAll(" ", "-")}.png`), new Uint8Array(await preview.arrayBuffer()));
}
const file = await SpreadsheetFile.exportXlsx(workbook);
const name = "Current and Active Investments.xlsx";
const stagingPath = path.join(work, name);
await file.save(stagingPath);
if (output !== work) await fs.copyFile(stagingPath, path.join(output, name));
