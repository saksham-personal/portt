import json
import re
import sys
from pathlib import Path
from urllib.parse import urljoin
from bs4 import BeautifulSoup

raw = Path(__file__).parent / "batch-d" / "raw"
matches = sys.argv[1:]
for directory in sorted(raw.iterdir()):
    if matches and not any(s.lower() in directory.name.lower() for s in matches):
        continue
    print("\n" + directory.name.upper())
    for metadata_path in sorted(directory.glob("*.json")):
        stage = metadata_path.stem
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        print(stage, metadata["title"], metadata["url"])
        soup = BeautifulSoup(metadata_path.with_suffix(".html").read_text(encoding="utf-8"), "html.parser")
        main = soup.find("main") or soup.body
        if main is None:
            continue
        if stage == "home" and (directory / "portfolio.json").exists():
            continue
        headings = [" ".join(t.stripped_strings) for t in main.select("h1,h2,h3,h4,h5")]
        print("Headings", " | ".join(dict.fromkeys(x for x in headings if x))[:3500])
        text = metadata_path.with_suffix(".txt").read_text(encoding="utf-8")
        print("Status", " | ".join(dict.fromkeys(x.strip()[:220] for x in text.splitlines() if re.search(r"active|current|realized|exit|prior|legacy|historical|next|load more|view all|see more|previous|past portfolio", x, re.I)))[:1500])
        options = [(x.get("value"), x.get_text(strip=True)) for x in main.select("select option")]
        if options:
            print("Options", options)
        print("Links", "  ".join(f"{label[:47]} → {url}" for label, url in dict.fromkeys(tuple(x) for x in metadata["links"]) if label and len(label) < 80)[:4400])
        alts = [x.get("alt", "").strip() for x in main.select("img[alt]") if x.get("alt", "").strip()]
        print("Images", " | ".join(dict.fromkeys(alts))[:3500])
