import asyncio,json,re
from playwright.async_api import async_playwright
from explore import HERE,DETAILS
from supplement import wait_page,click

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(channel='chrome',args=['--disable-background-networking','--disable-gpu'])
  c=await b.new_context(viewport={'width':1400,'height':1000})
  await c.route('**/*',lambda r:r.abort() if r.request.resource_type in ('font','image','media') else r.continue_())
  async def health():
   pg=await c.new_page(); await wait_page(pg,'https://healthedgepartners.com/portfolio/'); await pg.wait_for_timeout(2500)
   for option in ('#onetrust-reject-all-handler','.cky-btn-reject','button:has-text("Reject all")'):
    if await pg.locator(option).count(): await click(pg,option); break
   ls=pg.locator('section[id^="section-iconbox-0"] a[href*="popup"]')
   summary=[]
   for i in range(await ls.count()):
    link=ls.nth(i)
    try: await link.click(timeout=2500)
    except Exception: await link.dispatch_event('click')
    await pg.wait_for_timeout(750)
    target=pg.locator('[data-elementor-type=popup]:visible,[role=dialog]:visible')
    data=[]
    for modal in await target.all(): data.append(await modal.inner_text())
    summary.append(data)
    if data:
     (HERE/f'healthedgepartners.com.popup-{i+1}.html').write_text(await pg.content(),encoding='utf8')
     close=pg.locator('.dialog-close-button:visible').last
     if await close.count(): await close.click(force=True)
     else: await pg.keyboard.press('Escape')
    print('HE',i+1,repr(data)[:380],flush=True)
   (HERE/'healthedgepartners.com.popups.json').write_text(json.dumps(summary,ensure_ascii=False),encoding='utf8')
  async def heritage():
   pg=await c.new_page(); await wait_page(pg,'https://heritagegroupusa.com/portfolio/')
   await click(pg,'a[data-category-filter="current-investments"]')
   (HERE/'heritagegroupusa.com.supp-2.html').write_text(await pg.content(),encoding='utf8')
  async def other():
   pg=await c.new_page()
   for d,u in [('leavittequity.com','https://leavittequity.com/team/'),('zenythpartners.com','https://www.manulifeim.com/institutional/global/en/about-us/press-releases/zenyth-partners-announces-successful-closing-of-continuation-fund-led-by-funds-managed-by-blackrock-and-mim'),('regalhcp.com','https://www.regalhcp.com/news'),('healthquestcapital.com','https://www.healthquestcapital.com/news/histosonics-announces-225b-acquisition-by-consortium-of-top-tier-investors')]:
    try:
     await wait_page(pg,u); info=await pg.evaluate(DETAILS)
     (HERE/f'{d}.extra.html').write_text(await pg.content(),encoding='utf8')
     (HERE/f'{d}.extra.json').write_text(json.dumps(info,ensure_ascii=False),encoding='utf8')
    except Exception as e: print(u,e,flush=True)
  await asyncio.gather(health(),heritage(),other(),return_exceptions=True)
  await b.close()

if __name__=='__main__': asyncio.run(main())
