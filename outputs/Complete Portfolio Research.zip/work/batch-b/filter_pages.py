import asyncio, json, re, sys
from pathlib import Path
from playwright.async_api import async_playwright
from explore import HERE, DETAILS

CONFIG={
 'sheridancp.com': ('https://sheridancp.com/portfolio/', "button[data-slug=current]", None),
 'leavittequity.com': ('https://leavittequity.com/portfolio/', ".aep-filter-bar.desktop a[data-term-id='13']", None),
 'thebeekmangroup.com': ('https://thebeekmangroup.com/portfolio/', None, None),
 'thurstongroup.com': ('https://www.thurstongroup.com/portfolio', 'Active', None),
 'martiscapital.com': ('https://www.martiscapital.com/our-companies/', "[data-filter='.portfolio_category-current']", None),
 'roundtablehp.com': ('https://roundtablehp.com/portfolio.html', 'h5.current.f1', None),
 'latticeworkcapital.com': ('https://latticeworkcapital.com/portfolio/', '.elementor-portfolio__filter[data-filter="15"]', None),
 'ghocapital.com': ('https://ghocapital.com/healthcare/portfolio/', 'label:has(input[value=current])', '.paging__loadmore'),
 'thpartners.net': ('https://thpartners.net/portfolio/', 'li:has(> input[value=active]) label', 'Next'),
 'varsityhealthcarepartners.com': ('https://varsityhealthcarepartners.com/portfolio/', 'Current', None),
 'hepfund.com': ('https://hepfund.com/portfolio/', 'Current', None),
 'councilcapital.com': ('https://councilcapital.com/portfolio-companies/', "#investment-status-dropdown li[data-value=active]", None),
 'intandemcapital.com': ('https://intandemcapital.com/portfolio/', "a[data-value='.term-32']", None),
 'excellere.com': ('https://excellere.com/portfolio/', "select:has(option[value='.expa-filter-investment-status-active'])", None),
 'healthedgepartners.com': ('https://healthedgepartners.com/portfolio/', '.premium-tabs-nav-list-item[data-list-index="0"] a', None),
 'tritonpacific.com': ('https://tritonpacific.com/portfolio/', 'Current', None),
 'eirpartners.com': ('https://eirpartners.com/investment-portfolio/', 'Current', None),
}

async def process(browser, domain, sem):
 async with sem:
  url, control, paginator=CONFIG[domain]
  context=await browser.new_context(viewport={'width':1400,'height':980})
  await context.route('**/*', lambda route: route.abort() if route.request.resource_type in ('font','media','image') else route.continue_())
  page=await context.new_page()
  def selector(target):
   return page.locator(target) if re.search(r'[\[.:>]',target) else page.get_by_text(target,exact=True)
  details={'url':url,'selected':False,'pages':[]}
  try:
   await page.goto(url,wait_until='commit',timeout=22000)
   try: await page.wait_for_load_state('domcontentloaded',timeout=7000)
   except Exception: pass
   await page.wait_for_timeout(750)
   if domain=='councilcapital.com':
    opener=page.locator('#investment-status-dropdown .selected');
    if not await opener.count(): opener=page.locator('#investment-status-dropdown')
    await opener.first.click(timeout=3000)
   loc=selector(control) if control else None
   if loc is not None and not await loc.count():
    for possible in ('Current Investments','Active Investments','Active','Current Portfolio','Active Portfolio'):
     loc=page.get_by_text(possible,exact=True)
     if await loc.count(): break
   if loc is not None and await loc.count():
    elem=None
    for item in await loc.all():
     if await item.is_visible(): elem=item; break
    if elem:
     details['control']=await elem.evaluate('(e)=>e.outerHTML')
     if re.search(r'(h[1-6]|div|label|input)[> ]',details['control']) and 'filters' not in details['control'] and control=='Current':
      details['control_check']='Generic status label; inspect its surrounding markup before treating as filter.'
     try:
      if domain=='excellere.com': await elem.select_option('.expa-filter-investment-status-active',timeout=4500)
      else: await elem.click(timeout=4500)
      details['selected']=True
     except Exception as e: details['click_error']=str(e).splitlines()[0]
   await page.wait_for_timeout(1900)
   for ix in range(1,12):
    info=await page.evaluate(DETAILS)
    details['pages'].append(info)
    (HERE/f'{domain}.filtered-{ix}.html').write_text(await page.content(),encoding='utf8')
    if not paginator: break
    more=selector(paginator)
    if not await more.count() or not await more.first.is_visible(): break
    try: await more.first.click(timeout=4500)
    except Exception as e: details['paging_error']=str(e).splitlines()[0]; break
    await page.wait_for_timeout(1300)
    if (await page.evaluate(DETAILS))['links']==info['links']: break
  except Exception as e: details['error']=str(e).splitlines()[0]
  finally:
   (HERE/f'{domain}.filtered.json').write_text(json.dumps(details,ensure_ascii=False),encoding='utf8')
   print(domain, details.get('selected'),len(details['pages']),details.get('error',''),str(details.get('control',''))[:160],flush=True)
   await context.close()

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='chrome',args=['--disable-background-networking','--disable-gpu','--disable-gpu-shader-disk-cache'])
  sem=asyncio.Semaphore(6)
  await asyncio.gather(*(process(browser,d,sem) for d in (sys.argv[1:] or CONFIG.keys())))
  await browser.close()

if __name__=='__main__': asyncio.run(main())
