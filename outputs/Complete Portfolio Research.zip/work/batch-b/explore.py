import asyncio, json, os, re, sys
from pathlib import Path
from playwright.async_api import async_playwright

HERE = Path(__file__).parent
TEMP = HERE / 'browser-tmp'
TEMP.mkdir(exist_ok=True)
os.environ['TEMP'] = os.environ['TMP'] = str(TEMP)
DOMAINS = '''sheridancp.com leavittequity.com thebeekmangroup.com enhancedhealthcare.com thurstongroup.com martiscapital.com dwhp.com healthquestcapital.com roundtablehp.com transformcap.com regalhcp.com ghocapital.com latticeworkcapital.com newcapitalpartners.com hepfund.com zenythpartners.com councilcapital.com newharborcap.com thpartners.net varsityhealthcarepartners.com intandemcapital.com heritagegroupusa.com excellere.com persistencecapital.com healthedgepartners.com mbfhp.com tritonpacific.com eirpartners.com'''.split()
OVERRIDE = {'sheridancp.com':'https://sheridancp.com/portfolio/','enhancedhealthcare.com':'https://www.enhancedhealthcare.com/portfolio-2'}
DETAILS = '''() => {
  const compact = s => s?.trim().replace(/\\s+/g, ' ');
  const visible = el => Boolean(el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
  const label = el => compact(el.innerText) || el.getAttribute('aria-label') || el.getAttribute('title') || Array.from(el.querySelectorAll('img')).map(i=>i.alt || i.src.split('/').pop()).join(' / ');
  return {
    url:document.location.href,title:document.title,
    text:document.body.innerText,
    heads:[...document.querySelectorAll('h1,h2,h3,h4,h5')].filter(visible).map(e=>[e.tagName,label(e),e.className]),
    links:[...document.querySelectorAll('a[href]')].filter(visible).map(e=>[label(e),e.href,e.className]),
    controls:[...document.querySelectorAll('button,select,[role=tab],input[type=radio],input[type=checkbox]')].map(e=>[label(e),e.outerHTML.slice(0,700)]),
    files:[...document.querySelectorAll('img')].filter(visible).map(e=>[e.alt,e.src.split('/').pop(),compact(e.parentElement.innerText).slice(0,200),e.className]),
  };
}'''

async def inspect(browser, domain, sem):
    async with sem:
        context = await browser.new_context(viewport={'width':1400,'height':980})
        await context.route('**/*', lambda route: route.abort() if route.request.resource_type in ('font','media','image') else route.continue_())
        page = await context.new_page()
        records=[]
        async def visit(url):
            try:
                response=await page.goto(url, wait_until='commit', timeout=13500)
                try: await page.wait_for_load_state('domcontentloaded', timeout=5200)
                except Exception: pass
                await page.wait_for_timeout(1050)
                info=await page.evaluate(DETAILS)
                info['status']=response.status if response else None
                records.append(info)
                (HERE/f'{domain}.{len(records)}.html').write_text(await page.content(), encoding='utf-8')
                return info
            except Exception as e:
                records.append({'url':url,'error':str(e).splitlines()[0]})
        try:
            home=await visit('https://'+domain)
            if not home or home.get('status',0)>=400 or not home['text'].strip():
                home=await visit('https://www.'+domain)
            if domain in OVERRIDE:
                await visit(OVERRIDE[domain]); return
            if not home: return
            urls=[]
            for label,href,_ in home['links']:
                if re.fullmatch(r'(our |view |explore |see |meet )?(acting |active |current |all |investment )?(portfolio( companies)?|companies|investments|our partnerships|partners|portfolio & impact)', label or '', re.I) and href.startswith('http'):
                    if href not in urls: urls.append(href)
            if not urls:
                for label,href,_ in home['links']:
                    if re.search(r'/(portfolio|investments|companies)/?(?:$|#|\?)', href, re.I) and href not in urls:
                        urls.append(href)
            if not urls:
                urls = ['https://'+domain+'/portfolio/','https://'+domain+'/investments/']
            for url in urls[:4]:
                await visit(url)
        finally:
            (HERE/f'{domain}.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
            print(domain, [(i['url'], len(i.get('text','')),i.get('status')) for i in records], flush=True)
            await context.close()

async def main():
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(channel='chrome',args=['--disable-background-networking','--disable-gpu','--disable-gpu-shader-disk-cache'])
        sem=asyncio.Semaphore(8)
        await asyncio.gather(*(inspect(browser,d,sem) for d in (sys.argv[1:] or DOMAINS)))
        await browser.close()

if __name__=='__main__': asyncio.run(main())
