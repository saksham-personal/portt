from bs4 import BeautifulSoup as B
from pathlib import Path
from html import escape
from urllib.parse import urljoin, urlsplit, unquote
import json, re, sys
from explore import DOMAINS, HERE

OUT=HERE.parents[1]/'outputs'
BATCH=OUT/'html'/'b'
FIRMS=['Sheridan Capital Partners','Leavitt Equity Partners','The Beekman Group','Enhanced Healthcare Partners','Thurston Group','Martis Capital','DW Healthcare Partners','HealthQuest Capital','RoundTable Healthcare Partners','Transformation Capital','Regal Healthcare Capital Partners','GHO Capital','Latticework Capital Management','New Capital Partners','Health Enterprise Partners','Zenyth Partners','Council Capital','New Harbor Capital','Telegraph Hill Partners','Varsity Healthcare Partners','InTandem Capital Partners','Heritage Group','Excellere Partners','Persistence Capital Partners','HealthEdge Investment Partners','MBF Healthcare Partners','Triton Pacific Capital Partners','Eir Partners']

def soup(path): return B(path.read_text(encoding='utf8'),'html.parser')
def text(e): return re.sub(r'\s+',' ',e.get_text(' ',strip=True)).strip() if e else ''
def alt(e):
 img=e if e.name=='img' else e.find('img')
 return re.sub(r'\s+logo$','',img.get('alt',''),flags=re.I).strip() if img else ''
def href(e):
 a=e if e.name=='a' else e.find('a',href=True)
 return a.get('href','') if a else ''
def slug(u): return unquote(urlsplit(u).path.rstrip('/').rsplit('/',1)[-1]).replace('-',' ').title()
def headed(s,name): return next((e for e in s.select('h1,h2,h3,h4,h5,h6') if text(e).casefold()==name.casefold()),None)
def walk_between(a,b,css):
 return [e for e in a.find_all_next() if e is not b and b in e.find_all_next() and e in a.find_all_next() and e in a.find_parent('body').select(css)]
def siblings(h, tag):
 for e in h.next_siblings:
  if getattr(e,'name',None)==tag: break
  if getattr(e,'name',None) is not None: yield e
def load(d,file):
 p=HERE/f'{d}.{file}.html'
 return soup(p) if p.exists() else None

def firm(d,name):
 r=dict(domain=d,firm=name,url='https://'+d,state='Verified',method='',notes='',backups=[],investments=[])
 rows=json.loads((HERE/f'{d}.json').read_text(encoding='utf8'))
 good=[(i,x) for i,x in enumerate(rows,1) if x.get('text') and x.get('status')==200 and not x['url'].endswith('/#')]
 ix,j=good[-1]; r['url']=j['url']; base=r['url']; initial=load(d,ix)
 sf=sorted(HERE.glob(f'{d}.supp-*.html')); ff=HERE/f'{d}.filtered-1.html'
 source=sf[-1] if sf else (ff if ff.exists() else HERE/f'{d}.{ix}.html')
 s=soup(source)
 evidence=[]
 seen=set()
 status='Current'
 def add(label,node=None,url=None,stat=None):
  label=re.sub(r'\s+',' ',label or '').strip()
  if not label or label.casefold() in seen: return
  seen.add(label.casefold())
  link=url or (href(node) if node is not None else '')
  link=urljoin(r['url'],link) if link and link!='#' and not link.startswith('javascript:') else ''
  r['investments'].append({'name':label,'url':link,'status':stat or status})
  if node is not None:
   img=node if node.name=='img' else node.find('img')
   logo=(img.get('data-src') or img.get('src') or img.get('data-image') or '') if img else ''
   logo=urljoin(r['url'],logo) if logo else ''
   attrs=' '.join([f'{k}="{" ".join(v) if isinstance(v,list) else v}"' for k,v in node.attrs.items() if k in ('class','data-title','data-slug','data-status','data-term','title','aria-label','onclick')])
   evidence.append((label,logo,f'<{node.name} {attrs}>' if attrs else ''))
  else: evidence.append((label,'',''))
 def how(q,notes='',state='Verified'):
  r.update(method=q,notes=notes,state=state)

 if d=='sheridancp.com':
  how('Current filter','Selected Current and reconciled the shown cards against the source Current category.')
  for e in s.select('a.portfolio-card[data-slug=current]'): add(e.get('data-title'),e)
 elif d=='leavittequity.com':
  how('Active filter attempted','The portfolio is labeled as of December 31, 2024. The Active control did not produce a verifiable filtered result in Chrome; mixed results omitted.','Unverified')
  q=HERE/f'{d}.active.json'
  if q.exists():
   x=json.loads(q.read_text(encoding='utf8')); how(x['method'],x['notes'],x['state'])
   for n in x['rows']: add(n[0],url=n[1],stat='Active')
 elif d=='thebeekmangroup.com':
  how('Active status filter'); status='Active'
  details=HERE/f'{d}.details.json'; titles={x['url'].rstrip('/'):x['title'].split('|')[0].strip() for x in json.loads(details.read_text(encoding='utf8'))} if details.exists() else {}
  for e in s.select('.portfolio-item.active'):
   u=href(e); add(titles.get(u.rstrip('/')) or slug(u),e)
 elif d=='enhancedhealthcare.com':
  how('Active captions on select portfolio','The firm states that its site presents only selected investments. Completed deals without a disclosed company name are omitted.'); status='Active'
  for e in s.select('figure:has(figcaption)'):
   p=[text(x) for x in e.select('figcaption p')]; nonempty=[x for x in p if x]
   if len(nonempty)>1 and nonempty[-1].upper()=='ACTIVE': add(nonempty[0].replace('Inc .','Inc.'),e)
 elif d=='thurstongroup.com':
  how('Active carousel','Used the 11-card Active panel and checked its distinct names against the All and Realized panels.'); status='Active'
  panels=[e for e in s.select('#slider .inner-slider') if len(e.select('div.portfolio'))]
  if len(panels)>=2:
   for e in panels[1].select('div.portfolio'): add(alt(e),e)
 elif d=='martiscapital.com':
  how('Current filter','The firm describes the portfolio as illustrative and says it excludes some investments.')
  for e in s.select('.grve-portfolio-item.portfolio_category-current:not(.portfolio_category-exited)'):
   a=e.select_one('.grve-item-url'); add(a.get('title') or a.get('aria-label') or text(e) or slug(href(e)),e)
 elif d=='dwhp.com':
  how('Current section by fund')
  for e in s.select('.dwhp_company a[onclick]'):
   m=re.search(r"dwhp_company_profile\('Active',\s*'(.+?)'\);",e.get('onclick',''))
   if m: add(m[1].replace("\\'","'"),e)
 elif d=='healthquestcapital.com':
  how('Active Investments section','The site says its list includes selected investments. Ajax Health appears in both Active and Exited sections; Alcresta Therapeutics is also in both sections and the firm announced its acquisition by Linden. Both are omitted pending confirmation of a retained interest.'); status='Active'
  for e in s.select('[class*=PortfolioList_group__]:first-child [class*=PortfolioItem_block]'):
   n=e.select_one('h3,h4,h5,[class*=PortfolioItem_title]'); label=text(n) or re.sub(r'\s*Arrow Button\s*$','',text(e));
   if label not in {'Ajax Health','Alcresta Therapeutics'}: add(label or alt(e),e)
 elif d=='roundtablehp.com':
  how('Current Investments filter')
  for e in s.select('ul.investments li.current'): add(alt(e),e)
 elif d=='transformcap.com':
  how('Active status on company cards'); status='Active'
  for e in s.select('.portfolio-company-link'):
   st=next((text(h.find_next_sibling()) for h in e.select('h3') if text(h).upper()=='STATUS'),'')
   if st=='Active': add(text(e.select_one('.partner-name-custom-style')),e)
 elif d=='regalhcp.com':
  how('Portfolio description and firm announcement','The portfolio is anonymous by sector. InFocus Eyecare is inferred from the matching eyecare description and the firm’s formation release. Other portfolio names and statuses were not verified.','Partial')
  add('InFocus Eyecare',url='https://www.regalhcp.com/2022/06/13/1885',stat='Current (inferred)')
 elif d=='ghocapital.com':
  how('Current filter, then Load more','The final filter returned 19 Current cards. Excluded Biocare Medical and VISUfarma because the sponsors subsequently reported their completed sales on June 25, 2026 and April 2, 2026, respectively.')
  for e in s.select('.company--current'):
   label=text(e.select_one('.tile__heading'))
   if label not in {'Biocare Medical','VISUfarma'}: add(label,e)
  if len(s.select('.company--current'))<19:
   r.update(state='Partial',notes='The first result page was captured. Additional entries may remain behind Load more.')
 elif d=='latticeworkcapital.com':
  how('Active filter','American Veterinary Group has a realized original investment and a separate active investment confirmed on its official profile.'); status='Active'
  for e in s.select('article.elementor-filter-15'):
   if 'elementor-filter-16' in e.get('class',[]):
    if 'american-veterinary-group' in href(e): add('American Veterinary Group',e)
   else: add(alt(e) or slug(href(e)),e)
 elif d=='newcapitalpartners.com':
  how('Active Investments section'); status='Active'
  h=headed(s,'Active Investments')
  if h:
   for node in siblings(h,'h2'):
    for e in node.select('a:has(img)'): add(alt(e),e)
 elif d=='hepfund.com':
  how('Highlighted current investments filter','The site states that the published portfolio does not include all investments or investment history.')
  for e in s.select('.portfolio__item[data-term="highlighted-current-investments"]'): add(alt(e),e)
 elif d=='zenythpartners.com':
  how('Portfolio pages and sponsor announcements','The portfolio grid lacks status labels. The Smilist, ReFocus and Helping Hands Family were retained through a continuation transaction. A June 2026 advisor release identifies Align as a Zenyth portfolio company. Zenyth announced its investment in LifeCare, which is still listed.','Partial')
  q=HERE/f'{d}.active.json'
  if q.exists():
   for n in json.loads(q.read_text(encoding='utf8')): add(n[0],url=n[1],stat='Current (inferred)' if n[0]=='LifeCare Home Health Family' else 'Current')
 elif d=='councilcapital.com':
  how('Investment Status → Active'); status='Active'
  q=HERE/f'{d}.labels.json'; labels=json.loads(q.read_text(encoding='utf8')) if q.exists() else {}
  for e in s.select('.company-card[data-status=active]'):
   u=href(e); host=urlsplit(u).hostname or ''; add(labels.get(host.removeprefix('www.'), ''),e)
  if len(r['investments'])<len(s.select('.company-card[data-status=active]')): r.update(state='Partial',notes='Some logo-only cards still need a verified display name.')
 elif d=='newharborcap.com':
  how('Current Investments page')
  for e in s.select('h3.post-title'): add(text(e),e.find_parent('.card-link') or e.parent)
 elif d=='thpartners.net':
  r['url']='https://thpartners.net/portfolio/?_sft_portfolio_category=active'
  how('Active filter','The Active selector reports 19 results.'); status='Active'
  for f in sorted(sf):
   a=soup(f)
   aliases={'Dynex-Technologies':'Dynex Technologies','EditCo':'EditCo','Etherfax':'ETHERFAX','Frontier-Psychiatry':'Frontier Psychiatry','Kytopen':'Kytopen','Mosaic':'Mosaic','n6-Technologies':'n6 Technologies','Panome-Bio':'Panome Bio','Promptly':'Promptly','RevMedica':'RevMedica','Thomson':'Thomson Instrument Company','Welcony':'Welcony'}
   for e in a.select('.dce-post-block .elementor-widget-image img'):
    label=re.sub(r'^telegraph hill partners\s*','',alt(e),flags=re.I)
    if not label:
     src=e.get('src') or ''; label=next((v for k,v in aliases.items() if f'Logo-{k}' in src),'')
    add(label,e.find_parent('a') or e)
  if len(r['investments'])!=19: r.update(state='Partial',notes=f'Active filter reports 19 results; {len(r["investments"])} names could be read from the rendered result.')
 elif d=='varsityhealthcarepartners.com':
  r['url']='https://varsityhealthcarepartners.com/select-investments/'
  how('Current Investments section on Select Investments page','The site labels this as a selection of investments.')
  a=False
  for e in s.select('h3,h4'):
   if text(e)=='Realized Investments': break
   if text(e)=='Current Investments': a=True
   if a and e.name=='h3': add(text(e),e.find_parent('a') or e.parent)
 elif d=='intandemcapital.com':
  how('Active filter'); status='Active'
  for e in s.select('.lae-portfolio-item.term-32:not(.term-33)'):
   u=href(e); label=alt(e) or slug(u)
   label={'Atlas Health':'Atlas Health','Your Health':'Your Health','Bebright':'beBright'}.get(label,label)
   add(label,e)
 elif d=='heritagegroupusa.com':
  how('Current Investments filter and archive','Current portfolio cards were matched to the firm’s dedicated Current Investments archive.')
  r['url']='https://heritagegroupusa.com/project_category/current-investments/'
  for e in s.select('.project_category-current-investments:not(.project_category-realized) a.et_pb_lightbox_post_popup'):
   add(alt(e),e,(e.get('data-ajaxurl') or '').split('?')[0])
 elif d=='excellere.com':
  how('Active status filter','The portfolio is labeled representative.'); status='Active'
  for e in s.select('.expa-filter-investment-status-active'):
   label=alt(e); target=href(e); modal=s.find(id=target[1:]) if target.startswith('#') else None
   add(label,e,href(modal) if modal else None)
 elif d=='persistencecapital.com':
  how('Our current investments section')
  for e in s.find_all(['h1','figure']):
   if text(e).casefold()=='our exited investments.': break
   if e.name=='figure':
    label=text(e.select_one('figcaption p strong')); more=e.select_one('figcaption a[href]'); add(label,e,href(more) if more else None)
 elif d=='healthedgepartners.com':
  how('Current tab','The tab displays 10 logo-only cards. Names were decoded from the logo asset labels and matched to public company or firm material where available.')
  section=s.select_one('.premium-tabs-content-section.content-current') or s.select_one('section[id^="section-iconbox-0"]')
  q=HERE/f'{d}.labels.json'; labels=json.loads(q.read_text(encoding='utf8')) if q.exists() else {}
  if section:
   stylesheet=section.style.get_text() if section.style else ''
   for e in section.select('a[href*="popup"]'):
    cls=next((i for i in e['class'] if i.startswith('elementor-element-')),'')
    m=re.search(re.escape(cls)+r'[^}]*background-image:url\("([^"]+)',stylesheet)
    logo=m[1].split('/')[-1] if m else ''
    label=labels.get(logo)
    if label: add(label,e,stat='Current (name from logo)' if label=='Alatus' else None)
  if len(r['investments'])!=10: r.update(state='Partial',notes='Current tab has 10 logo-only cards; listings without a verified display name are omitted.')
 elif d=='mbfhp.com':
  how('Unrealized Investments section'); status='Unrealized'
  h=next((e for e in s.select('.label') if text(e).upper()=='UNREALIZED INVESTMENTS'),None)
  if h:
   for e in h.find_next_sibling().select('.portfolio-card'):
    u=href(e); n={'Arete Health':'Arete Health','Aba Connect':'BrightPath Behavior (formerly ABA Connect)','Palm Medical Centers':'Palm Medical Centers'}.get(slug(u),slug(u)); add(n,e)
 elif d=='tritonpacific.com':
  how('Current investment tab','Included cards under the portfolio Current tab. Tasty King, Tasty Hut and Tasty Delites are displayed as brands under Tasty Restaurant Group.')
  for e in s.select('#tab-current .flip-box-back .inner'):
   u=href(e); label=text(e.select_one('h4'))
   if label in ('Tasty King','Tasty Hut','Tasty Delites'): continue
   if not label: label=next((n for n in ('Already Autism Health','Integrated Pain Associates','Unio','IWP','DWP','Blue Bridge') if text(e).startswith(n)),'')
   if label=='IWP': label='Injured Workers Pharmacy (IWP)'
   add(label,e)
 elif d=='eirpartners.com':
  how('Active Portfolio Investments section','Partially exited companies appear in the firm’s Exited section and are omitted from these results.'); status='Active'
  active=False
  for e in s.select('h2,h3.t-entry-title'):
   if text(e)=='Exited Portfolio Investments': break
   if text(e)=='Active Portfolio Investments': active=True
   if active and e.name=='h3': add(text(e),e.parent.parent)

 if not r['investments'] and r['state'] in ('Verified','Partial'): r['state']='Unverified'
 if source.exists():
  path=BATCH/f'{d}.html'
  original=BATCH/f'{d}-browser.html'
  raw=soup(source)
  for node in raw.select('script,iframe,frame,object,embed,meta[http-equiv="refresh" i]'): node.decompose()
  for node in raw.select('*'):
   for key in list(node.attrs):
    if key.startswith('on'): del node[key]
  if raw.head:
   for x in raw.head.select('base'): x.decompose()
   base_tag=raw.new_tag('base',href=r['url']); raw.head.insert(0,base_tag)
  original.write_text(str(raw),encoding='utf8')
  r['archive_extras']=[original.relative_to(OUT).as_posix()]
  items=[]
  for row, (_,logo,attrs) in zip(r['investments'],evidence):
   title=escape(row['name']); u=escape(row['url'],quote=True)
   title=f'<a href="{u}">{title}</a>' if u else title
   attrs=f'<p class="meta">{escape(attrs)}</p>' if attrs else ''
   items.append(f'<li>{title} <span>{escape(row["status"])}</span>{attrs}</li>')
  path.write_text(f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{escape(name)} | Portfolio evidence</title><style>body{{font:16px/1.5 system-ui,sans-serif;max-width:70rem;margin:2rem auto;padding:0 1rem;color:#192830}}li{{padding:.45rem .6rem;border-bottom:1px solid #d7dfe3}}li span{{font-size:.8em;color:#405867;margin-left:.6em}}.meta{{font:12px ui-monospace,monospace;color:#485963;overflow-wrap:anywhere;margin:.3rem 0}}</style><main><h1>{escape(name)}</h1><p><a href="{escape(r['url'],quote=True)}">Official portfolio page</a> · 23 November 2026</p><p>{escape(r['method'])} · {len(items)} extracted records</p><p>{escape(r['notes'])}</p><p>This standalone HTML records the selected portfolio entries and any stated inference. The <a href="{original.name}">companion browser HTML</a> preserves source markup with executable elements removed. The site may load styles and logos from the web, and the stored markup can contain hidden cards or other tabs.</p><ol>{''.join(items)}</ol></main></html>''',encoding='utf8')
  r['backups']=[path.relative_to(OUT).as_posix()]
 return r

def main():
 recs=[]
 for d,n in zip(DOMAINS,FIRMS):
  try: recs.append(firm(d,n))
  except Exception as exc:
   print('PARSE ERROR',d,repr(exc),file=sys.stderr)
   recs.append(dict(domain=d,firm=n,url='https://'+d,state='Unverified',method='Browser portfolio review',notes=f'Capture required manual review ({type(exc).__name__}).',backups=[],investments=[]))
 (HERE/'results.json').write_text(json.dumps(recs,ensure_ascii=False,indent=2),encoding='utf8')
 for r in recs: print(r['domain'],r['state'],len(r['investments']),r['notes'])

if __name__=='__main__': main()
