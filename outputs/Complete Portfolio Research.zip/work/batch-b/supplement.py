import asyncio, json, re, sys
from urllib.parse import urljoin
from playwright.async_api import async_playwright
from explore import HERE, DETAILS

JOBS={
'leavittequity.com':('https://leavittequity.com/portfolio/', 'leavitt'),
'thurstongroup.com':('https://www.thurstongroup.com/portfolio','thurston'),
'ghocapital.com':('https://ghocapital.com/healthcare/portfolio/','gho'),
'hepfund.com':('https://hepfund.com/portfolio/','hep'),
'thpartners.net':('https://thpartners.net/portfolio/?_sft_portfolio_category=active','thp'),
'varsityhealthcarepartners.com':('https://varsityhealthcarepartners.com/select-investments/','varsity'),
'zenythpartners.com':('https://www.zenythpartners.com/portfolio','zenyth'),
'heritagegroupusa.com':('https://heritagegroupusa.com/portfolio/','heritage'),
'thebeekmangroup.com':('https://thebeekmangroup.com/portfolio/','beekman'),
}

async def wait_page(page, url):
 try:
  await page.goto(url,wait_until='domcontentloaded',timeout=16000)
 except Exception:
  if page.url=='about:blank': raise
 await page.wait_for_timeout(450)

async def click(page, css):
 target=page.locator(css).first
 if not await target.count(): return False
 try: await target.click(timeout=2500)
 except Exception: await target.dispatch_event('click')
 await page.wait_for_timeout(1600)
 return True

async def work(browser, domain, sem):
 async with sem:
  url,job=JOBS[domain]
  context=await browser.new_context(viewport={'width':1490,'height':1040})
  await context.route('**/*',lambda route: route.abort() if route.request.resource_type in ('font','media','image') or any(x in route.request.url for x in ('facebook.net/','googletagmanager','google-analytics','hotjar','clarity.ms','cdn.cookielaw.org')) else route.continue_())
  page=await context.new_page(); details=[]; errors=[]
  async def snapshot(label):
   info=await page.evaluate(DETAILS); info['capture']=label; details.append(info)
   (HERE/f'{domain}.supp-{len(details)}.html').write_text(await page.content(),encoding='utf8')
  async def details_for(urls):
   async def open_sub(url,index):
    async with workerpool:
     if not url.startswith(('http://','https://')): return
     tab=await context.new_page()
     try:
      await wait_page(tab,url)
      info=await tab.evaluate(DETAILS)
      (HERE/f'{domain}.detail-{index}.html').write_text(await tab.content(),encoding='utf8')
      info['html']=f'{domain}.detail-{index}.html'
      return info
     except Exception as exc: errors.append([url,str(exc).splitlines()[0]])
     finally: await tab.close()
   infos=await asyncio.gather(*(open_sub(u,i) for i,u in enumerate(dict.fromkeys(urls),1)))
   (HERE/f'{domain}.details.json').write_text(json.dumps([i for i in infos if i],ensure_ascii=False),encoding='utf8')
  workerpool=asyncio.Semaphore(4)
  try:
   await wait_page(page,url)
   if job=='leavitt':
    for i in range(1,5):
     if i>1: await wait_page(page,url+f'page/{i}/')
     await click(page,".aep-filter-bar.desktop [data-term-id='13']")
     await snapshot(f'Active selector, page {i}')
     if not await page.locator(f'.page-numbers[data-ae-page-id="{i+1}"]').count(): break
   elif job=='thurston':
    await click(page,".page-nav .fx-nav:has-text('Active')")
    await snapshot('Active selector')
   elif job=='gho':
    for sel in ('#onetrust-reject-all-handler','#onetrust-accept-btn-handler','button:has-text("Reject all")'):
     if await page.locator(sel).count() and await page.locator(sel).first.is_visible():
      await click(page,sel); break
    elt=page.locator('input[name=status][value=current]')
    if await elt.count():
     await click(page,'label:has(input[name=status][value=current]) .filters__fieldset__field__label')
     if not await elt.is_checked(): await elt.evaluate('(el) => el.click()')
    for i in range(1,6):
     await snapshot(f'Current, load state {i}')
     more=page.locator('.paging__loadmore')
     if not await more.count() or not await more.first.is_visible(): break
     old=await page.locator('.tile--company').count()
     await click(page,'.paging__loadmore')
     if old==await page.locator('.tile--company').count(): break
   elif job=='hep':
    for sel in ('.cky-btn-reject','.cky-btn-accept'):
     if await page.locator(sel).count(): await click(page,sel); break
    await click(page,'[data-filter-value="highlighted-current-investments"]')
    await snapshot('Highlighted current investments')
   elif job=='thp':
    await snapshot('Active-filter URL')
    urls=await page.locator('.pagination a.page-numbers,a.next.page-numbers').evaluate_all('(a)=>a.map(e=>e.href)')
    for u in dict.fromkeys(urls):
     await wait_page(page,u); await snapshot('Active-filter pagination')
   elif job=='varsity':
    await snapshot('Select investments')
    await details_for(await page.locator('a[href*="/portfolio/"]').evaluate_all('(a)=>a.map(e=>e.href).filter(u=>/portfolio\\/[^/]+/.test(u))'))
   elif job=='zenyth':
    await snapshot('Our Portfolio')
    await details_for(await page.locator('.sqs-block-image-link').evaluate_all('(a)=>a.map(e=>e.href)'))
   elif job=='heritage':
    await snapshot('Portfolio grid')
    await details_for(await page.locator('a.et_pb_lightbox_post_popup').evaluate_all('(a)=>a.map(e=>e.getAttribute("data-ajaxurl")?.split("?")[0]).filter(Boolean)'))
   elif job=='beekman':
    if await page.locator('.selectric-portfolio--filter-status .selectric').count():
     await click(page,'.selectric-portfolio--filter-status .selectric')
     await click(page,'.selectric-portfolio--filter-status li[data-index="1"]')
    await snapshot('Active status filter')
    await details_for(await page.locator('.portfolio-item.active > a').evaluate_all('(a)=>a.map(e=>e.href)'))
  except Exception as exc: errors.append([url,str(exc).splitlines()[0]])
  finally:
   (HERE/f'{domain}.supp.json').write_text(json.dumps({'pages':details,'errors':errors},ensure_ascii=False),encoding='utf8')
   print(domain,len(details),errors[:4],flush=True)
   await context.close()

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='chrome',args=['--disable-background-networking','--disable-gpu','--disable-gpu-shader-disk-cache'])
  sem=asyncio.Semaphore(5)
  await asyncio.gather(*(work(browser,d,sem) for d in (sys.argv[1:] or JOBS.keys())))
  await browser.close()

if __name__=='__main__': asyncio.run(main())
