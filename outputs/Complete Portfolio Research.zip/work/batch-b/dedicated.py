import asyncio, json, re
from playwright.async_api import async_playwright
from explore import HERE, DETAILS
from supplement import wait_page

LEP='https://leavittequity.com'
HER='https://heritagegroupusa.com/project_category/current-investments/'

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(channel='chrome',args=['--disable-background-networking','--disable-gpu'])
  c=await b.new_context()
  await c.route('**/*',lambda r:r.abort() if r.request.resource_type in ('media','font','image','stylesheet','script') else r.continue_())
  active=[]; temp=[]; sem=asyncio.Semaphore(5); source=[]
  async def record(url,d,i,check):
   async with sem:
    x=await c.new_page()
    try:
     r=await x.goto(url,timeout=12000,wait_until='domcontentloaded')
     if r.status==200:
      h=await x.content(); info=await x.evaluate(DETAILS)
      (HERE/f'{d}.archive-{i}.html').write_text(h,encoding='utf8')
      if check:
       status=x.locator('a[href$="/tag/active/"]')
       n=x.locator('main h1,header.entry-header h1,.entry-title').first
       if await status.count() and await n.count(): active.append((await n.inner_text(),x.url))
       temp.append((x.url,await status.count(),x.url.split('/')[-2]))
      return info
    except Exception as e: print(url,str(e).splitlines()[0],flush=True)
    finally: await x.close()
  async def heritage():
   await asyncio.gather(*(record(HER+(f'page/{i}/' if i>1 else ''),'heritagegroupusa.com',i,False) for i in range(1,6)))
  async def leavitt():
   x=await c.new_page(); urls=[]
   for path in ('/wp-sitemap-posts-lep_portfolio-1.xml','/lep_portfolio-sitemap.xml','/wp-json/wp/v2/lep_portfolio?per_page=100','/lep_portfolio/apollo-intelligence/'):
    try:
     rr=await x.goto(LEP+path,timeout=6500,wait_until='domcontentloaded'); h=await rr.text()
     (HERE/f'leavitt-source-{path.split("/")[1].split("?")[0]}.html').write_text(h,encoding='utf8')
     urls+=re.findall(r'https?://leavittequity\.com/lep_portfolio/[\w%-]+/?',h)
     print('Leavitt discovery',path,rr.status,len(set(urls)),flush=True)
     if len(set(urls))>15: break
    except Exception as e: print(path,str(e).splitlines()[0],flush=True)
   await x.close()
   urls=list(dict.fromkeys(u.rstrip('/')+'/' for u in urls))
   await asyncio.gather(*(record(u,'leavittequity.com',i,True) for i,u in enumerate(urls,1)))
   (HERE/'leavittequity.com.active.json').write_text(json.dumps({'method':'Active tag on individual official company pages','notes':f'Checked {len(temp)} separate portfolio records for an explicit Active tag. The main portfolio disclosure dates its list to December 31, 2024.','state':'Verified' if len(temp)>=25 else 'Partial','rows':sorted(set(active))},ensure_ascii=False,indent=2),encoding='utf8')
  await asyncio.gather(heritage(),leavitt())
  await b.close()

if __name__=='__main__': asyncio.run(main())
