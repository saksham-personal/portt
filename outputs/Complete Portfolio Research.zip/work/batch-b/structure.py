from bs4 import BeautifulSoup
from pathlib import Path
import json,re,sys
W=Path(__file__).parent
selectors={
 'dwhp.com':'h2,h3,.wp-block-image',
 'healthquestcapital.com':'[class*=groupTitle],[class*=PortfolioList_item]',
 'thurstongroup.com':'.page-nav span,#content img,.fx-card,[class*=portfolio] img',
 'roundtablehp.com':'h5.current,.portfolio-link,a[href*="portfolio/"]',
 'martiscapital.com':'[data-filter],.portfolio_category-current',
 'latticeworkcapital.com':'.elementor-portfolio__filter,.elementor-portfolio-item',
 'transformcap.com':'.partner-name-custom-style',
 'ghocapital.com':'input[value=current],.tile__company-status,.paging__loadmore',
 'newharborcap.com':'h2,h3,a[href*="/company"],a[href*="/investments/"]',
 'thpartners.net':'input[value=active], img[alt*="telegraph hill partners"]',
 'zenythpartners.com':'.sqs-block-image-link, section[data-section-id]',
 'varsityhealthcarepartners.com':'h1,h2,[data-filter],.portfolio a,.portfolio img',
 'tritonpacific.com':'h2,h3,[data-filter],a[href*="portfolio/"]',
 'eirpartners.com':'h2,h3,[data-filter],a[href*="portfolio/"]',
}
for d in sys.argv[1:] or list(selectors):
 p=W/f'{d}.json'
 if not p.exists(): continue
 for ix, row in enumerate(json.loads(p.read_text(encoding='utf8'))):
  if ix==0 or 'text' not in row or row['url'].endswith('/#') or row['url'].rstrip('/').endswith(d): continue
  s=BeautifulSoup((W/f'{d}.{ix+1}.html').read_text(encoding='utf8'),'html.parser')
  print('\n',d,ix+1, row['url'])
  print('small head',row['heads'][:8]); print('lines',[x for x in row['text'].splitlines()[:45] if x][:25])
  def idt(x): return x.name+(':'+x['id'] if x.get('id') else '')+('.'+'.'.join(x.get('class',[])[:7]) if x.get('class') else '')
  for el in s.select(selectors.get(d,'main h1,main h2,main h3,[data-filter]'))[:12]:
   print(idt(el), el.get('alt') or el.get('title') or el.get_text(' ',strip=True)[:55],el.get('href') or el.get('data-filter') or '', ' :: ', '/'.join(idt(a) for a in list(el.parents)[:6]), [ [i.get('alt'), (i.get('src') or '').split('/')[-1]] for i in el.select('img')[:2]])
