from pathlib import Path
from bs4 import BeautifulSoup as B
from cards import cls

W=Path(__file__).parent
def s(f): return B((W/f).read_text(encoding='utf8'),'html.parser')
def show(f,filters):
 print('\n',f)
 b=s(f)
 for q in filters:
  els=b.select(q); print('SEL',q,len(els))
  for e in els[:3]:
   print('DOM',str(e)[:450], [cls(x) for x in list(e.parents)[:4]])
def txt(b,p): return b.find(string=lambda x:x and x.strip().lower()==p)
for f,p in [('dwhp.com.3.html','current'),('persistencecapital.com.2.html','our current investments.'),('mbfhp.com.2.html','unrealized investments'),('eirpartners.com.3.html','active portfolio investments'),('healthedgepartners.com.filtered-1.html','realized')]:
 b=s(f); e=txt(b,p).parent; print('\nHEADER',f,str(e)[:180],str(e.parent)[:800]); print('SIB',[(cls(a),str(a)[:350]) for a in list(e.find_next_siblings())[:6]])
show('sheridancp.com.filtered-1.html',['a.portfolio-card[data-slug=current]'])
show('councilcapital.com.filtered-1.html',['a.learn-more'])
show('intandemcapital.com.filtered-1.html',['.term-32'])
show('healthquestcapital.com.2.html',['[class*=PortfolioItem_block]'])
show('regalhcp.com.2.html',['img','[style*=background]'])
show('tritonpacific.com.filtered-1.html',['.wpb_tab.visible-tab','[id^=tab-] h4','.flip-box-back .inner'])
show('leavittequity.com.filtered-1.html',['.aep-post-item','.ae-post-block-item'])
show('thurstongroup.com.supp-1.html',['.page-nav .fx-nav','.fx-slide','div.portfolio'])
