from bs4 import BeautifulSoup
import json, re, sys
from pathlib import Path
W=Path(__file__).parent
S={
'sheridancp.com':('a.portfolio-card',None),
'leavittequity.com':('[class*=aep-portfolio] img,.aep-portfolio-list img',[1,2]),
'thebeekmangroup.com':('.portfolio--item,[data-status]', [1]),
'enhancedhealthcare.com':('figure figcaption', [1]),
'thurstongroup.com':('div.portfolio', [1,2,4]),
'dwhp.com':('main img', [1,2]),
'healthquestcapital.com':('[class*=PortfolioItem_item],[class*=Group_item]', [1,2]),
'regalhcp.com':('main h1,main h2,main h3,main h4,main h5', [1,2,3]),
'newcapitalpartners.com':('main h2,main h3,main a img', [1,2,3]),
'hepfund.com':('.portfolio__item',None),
'councilcapital.com':('a.learn-more', [1,2,3]),
'varsityhealthcarepartners.com':('main h1,main h2,main h3,main .entry-title', [1,2]),
'intandemcapital.com':('.lae-portfolio-item,[class*=term-32]', [1,2]),
'heritagegroupusa.com':('a.et_pb_lightbox_post_popup', [1,2,3]),
'excellere.com':('.expa-filter-investment-status-active', [1,2]),
'persistencecapital.com':('.sqs-block-image-link,.image-title,h1,h2,h3', [1,2]),
'healthedgepartners.com':('#premium-accordion-content-0 img, #premium-accordion-content-0 h2, #premium-accordion-content-0 h3, #premium-accordion-content-0 h4', [1,2]),
'mbfhp.com':('main h1,main h2,main h3,main a[href*="portfolio/"]', [1,2,3]),
'tritonpacific.com':('#tab-current h3,#tab-current h4,#tab-current h5,[id^=tab-].tab-pane h4',[1,2]),
'eirpartners.com':('.uncode_text_column h2,.uncode_text_column h3,.uncode_text_column h4', [1,2,3]),
'zenythpartners.com':('.sqs-block-image-link', [1,2,3]),
}
def t(e): return e.get_text(' ',strip=True) if e else ''
def cls(e): return e.name + ('#'+e.get('id') if e.get('id') else '') + (' '+'.'.join(e.get('class',[])[:6]) if e.get('class') else '')
for d in sys.argv[1:] or list(S):
 f=W/f'{d}.json'
 if not f.exists(): continue
 rows=json.loads(f.read_text(encoding='utf8')); ix=next((i for i in range(len(rows),0,-1) if (W/f'{d}.{i}.html').exists() and 'text' in rows[i-1]),None)
 if not ix: continue
 q=W/f'{d}.filtered-1.html'; starting=q if q.exists() else W/f'{d}.{ix}.html'; row=rows[ix-1]
 print('\n',d,starting.name,row['url'], ' :: ', row['text'][:1000].replace('\n',' | '))
 s=BeautifulSoup(starting.read_text(encoding='utf8'),'html.parser')
 pat,pr=S[d]
 for e in s.select(pat):
  imgs=' '.join((i.get('alt') or (i.get('src') or '').split('/')[-1]) for i in ([e] if e.name=='img' else e.select('img'))[:2]); a=e if e.name=='a' else e.find('a') or e.find_parent('a'); href=a.get('href','') if a else ''
  if not imgs and not t(e) and not href: continue
  print(cls(e), t(e)[:100], e.get('style',''), str(e.get('data-status','')), str(e.get('title','')), imgs[:100], href, '('+'/'.join(cls(list(e.parents)[i-1]) for i in pr if i<=len(list(e.parents)))+')' if pr else '')
