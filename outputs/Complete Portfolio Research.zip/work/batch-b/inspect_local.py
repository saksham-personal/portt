from pathlib import Path
import json, re, sys
from bs4 import BeautifulSoup

HERE=Path(__file__).parent
for domain in sys.argv[1:]:
    f=HERE/f'{domain}.json'
    if not f.exists(): continue
    rows=json.loads(f.read_text(encoding='utf8'))
    for ix, row in enumerate(rows):
        if ix==0 or 'text' not in row or row['url'].endswith('/#'): continue
        print('\n', domain, ix+1, row['url'])
        p=HERE/f'{domain}.{ix+1}.html'
        if not p.exists(): continue
        s=BeautifulSoup(p.read_text(encoding='utf8'),'html.parser')
        def desc(e):
            if e is None: return ''
            return e.name + (('#'+e['id']) if e.get('id') else '')+ (('.'+'.'.join(e.get('class',[])[:8])) if e.get('class') else '') + ('[' + str({k:v for k,v in e.attrs.items() if k.startswith('data-') or k in ('value','alt','title','href')})[:230]+']' if e.attrs else '')
        for node in s.find_all(string=re.compile(r'^\s*(?:active(?: investments?| portfolio)?|current(?: (?:portfolio(?: companies)?|investments?))?|realized(?: investments?)?|inactive(?: investments?)?|exited(?: investments?)?|portfolio|investment status|all companies|load more|view more|show more|status:?)\s*$',re.I))[:45]:
            node=node.parent
            print(' ',str(node.get_text(strip=True))[:60],':',' > '.join(desc(x) for x in [node.parent.parent,node.parent,node]), 'next:',desc(node.find_next_sibling()), 'prev:',desc(node.find_previous_sibling()))
        print('links:', [(t,u.split('/')[-2:] if u.startswith(row['url']) else u,c) for t,u,c in row['links'] if not any(x in u for x in ('linkedin','facebook','twitter','google','/about','/team','/contact','/privacy','/legal','/terms','#','/news/'))][:75])
        print('images:', [i[:2] for i in row['files']][:90])
