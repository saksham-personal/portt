from root_evidence import add, finalize, metadata, source_html


add("spindletopcapital.com", "Spindletop Capital", "Partial",
    "Unmarked entries in the firm portfolio with acquired and legacy entries identified separately",
    "The portfolio is mixed and has no status filter. The entries shown have no exit marker. Present stakes in listed public companies and the HNI Healthcare card hidden on all devices could not be verified.",
    """Tri City Pain Associates|https://tricitypainassociates.com|Firm portfolio, no exit marker
American Pain Consortium (APC)|https://www.americanpainconsortium.com/|Firm portfolio, no exit marker""")

add("www.vscpllc.com", "Vesey Street Capital Partners", "Verified", "Active filter",
    "The firm has separate Recapitalized and Exited views. The Active view displays six names.",
    """Elite Body Sculpture
Safecor Health
Inceptua Group
ComplexCare Solutions
Shemmassian Academic Consulting
Orthopaedic Solutions Management""", stages=("active",),
    hide={"active": "#qualitymetric,#pathgroup,#exponent-health,#imedex,#gastro-md"})

add("www.blackbernpartners.com", "Blackbern Partners", "No public portfolio",
    "Official site review", "The public website provides a firm description and contact email. It does not expose a current portfolio.", stages=("home",))

whistler = source_html("www.whistlercapital.com", "portfolio")
whistler_rows = []
for panel in whistler.select("#pf-jack-track .pf-panel"):
    whistler_rows.append({"name": panel.h3.get_text(strip=True), "url": panel.select_one(".pf-visit")["href"], "status": "Firm portfolio platform"})
for logo in whistler.select("#const-wall a img"):
    whistler_rows.append({"name": logo["alt"], "url": logo.parent["href"], "status": "Current strategic minority position as of August 2026"})
add("www.whistlercapital.com", "Whistler Capital Partners", "Verified",
    "Firm platforms and Strategic Investments sections",
    "Strategic positions are held by separate vehicles managed by Whistler or affiliates. The firm dates these positions to August 2026. Prior Firm Investments are attributed to past employers.",
    whistler_rows, hide={"portfolio": "section:has(.wall-grid):not(:has(#const-wall))"})

denali = metadata("www.denaligrowth.com", "news")
denali_rows = []
for name, term in [
    ("BEESY", "BEESY Announces"),
    ("MD Integrations", "MD Integrations Raises"),
    ("Slipstream", "Slipstream Announces"),
    ("Tobin Scientific", "Tobin Scientific Closes"),
    ("HiLabs", "HiLabs Announces"),
    ("Boston Veterinary Clinic", "Boston Veterinary Clinic"),
    ("Sollis Health", "Sollis Health Raises"),
]:
    first_party_releases = {
        "Sollis Health": "https://www.prnewswire.com/news-releases/sollis-health-closes-30-million-in-series-a-funding-led-by-torch-capital-and-denali-growth-partners-301467417.html",
        "Boston Veterinary Clinic": "https://www.bostonveterinary.com/wp-content/uploads/2022/05/BVC-Denali-FINAL-Press-Release-2022-2.pdf",
    }
    source = first_party_releases.get(name) or next((url for text, url in denali["links"] if term in text), denali["url"])
    denali_rows.append({"name": name, "url": "", "source": source, "status": "Named growth investment in firm news. Continuing ownership inferred."})
add("www.denaligrowth.com", "Denali Growth Partners", "Partial",
    "Official news and funding announcements",
    "The firm has no public current portfolio filter. Recent and named transactions are listed where the firm's role is documented. Ongoing ownership is inferred. NationsBenefits has a later General Atlantic-led deal and was left unresolved pending evidence of a retained Denali stake.",
    denali_rows, stages=("news", "about", "sitemap"))

five = source_html("www.5cpartners.com", "portfolio")
five_rows = []
for heading in five.select("h2.type-heading-4xl"):
    name = heading.get_text(" ", strip=True)
    if name in {"Radon Medical Imaging", "Portfolio"}:
        continue
    link = heading.parent.find("a", href=True)
    if link and name:
        five_rows.append({"name": name, "url": link["href"], "status": "Listed in All and outside Realizations"})
add("www.5cpartners.com", "5th Century Partners", "Verified", "All portfolio less the Realizations filter",
    "Radon Medical Imaging appears under Realizations. Peace Out and Estyle appear under All without an industry category.", five_rows,
    stages=("portfolio", "realizations", "healthcare", "services"))

add("archimedesinvestors.com", "Archimedes Investors", "No public portfolio", "Official site review",
    "The public page describes team members' prior investments and mentions no current company-level holdings.", stages=("home",))

add("www.ascendpartners.com", "Ascend Partners", "Partial", "Official Fund I and Fund II portfolio cards",
    "Nine public entries have investment dates and fund attributions. The site has no current-versus-exited filter. Allied Physicians Group and Adjuvant.Health are shown on a single investment card.",
    """Unison Therapy Services||Named as a Fund II investment by the firm|https://ascendpartners.com/ascend-capital-partners-closes-oversubscribed-fund-ii-above-target-at-791-million/
Seoul Medical Group (SMG)||Named as a Fund II investment by the firm|https://ascendpartners.com/ascend-capital-partners-closes-oversubscribed-fund-ii-above-target-at-791-million/
Elation Health
MSPB
Allied Physicians Group and Adjuvant.Health
Consensus Health
Ilumed
Essen Health Care
Rendr""", stages=("loaded", "news", "fund-ii"))

growth = metadata("www.growthcurvecapital.com", "portfolio")
growth_rows = [{"name": name, "source": url, "status": "Current portfolio listing. Holding status inferred."}
               for name, url in growth["links"] if name and "/portfolio/" in url and len(name) < 60]
add("www.growthcurvecapital.com", "GrowthCurve Capital", "Partial", "Official portfolio and company detail pages",
    "The public portfolio lists these companies without an exit/current status field. The page's filters are by industry.", growth_rows, stages=("portfolio", "news"))

add("hughes-co.com", "Hughes & Company", "Verified", "Active Investments section and explicit card status",
    "Azara Healthcare and LifeLoop are explicitly Active following majority recapitalizations. The firm discloses that certain investments are omitted from its site.",
    """Azara Healthcare|https://azarahealthcare.com/|Active following recapitalization
Encoda|https://encoda.com/
LifeLoop|https://lifeloop.com/|Active following recapitalization
Valer (Voluware)|https://valer.health/
Health Data Innovations (HDI)|http://hd-innovations.com/
Curvo|https://www.curvolabs.com/
PatientIQ|https://www.patientiq.io/""")

lead = source_html("leadcp.com", "active")
lead_names = {
    "family-ties": "Family Ties",
    "healthcare-services-company": "Healthcare Services Company (unnamed)",
    "ladd": "LADD",
    "lieberman-research": "Lieberman Research",
    "pedsone": "PedsOne",
    "preferred-dermatology-partners": "Preferred Dermatology Partners",
    "viva-day-spa-med-spa": "Viva Day Spa + Med Spa",
}
lead_rows = [{"name": lead_names[link["href"].strip("/").rsplit("/", 1)[-1]], "url": link["href"], "status": "Active filter"}
             for link in lead.select(".port-target.active .port-logo a[href]")]
assert len(lead_rows) == 7
add("leadcp.com", "Lead Capital Partners", "Verified", "Active filter",
    "One holding is displayed under a generic name. The company names on logo-only cards were checked against their portfolio detail markup.",
    lead_rows, stages=("active",), hide={"active": ".port-target.exited"})

add("www.duneglasscapital.com", "DuneGlass Capital", "Verified", "Thematic investments and operating platform section",
    "The official platform section lists four investments. It also identifies the growth investment in Allied OMS by a second investor.",
    """Allied OMS
BGS Alliance
Aviva Aesthetics
Phase 1 Equity""", stages=("platforms",))

add("loneviewcap.com", "Lone View Capital", "Partial", "Official portfolio and company detail listing",
    "The official site lists six direct holdings and does not show individual status fields. The page and news omit independently acquired add-ons as separate direct investments.",
    """CargoSprint|https://loneviewcap.com/portfolio/cargosprint/
HappyCo
Jumpmind
Parking Base
Smartlinx
TREND Health Partners""", stages=("portfolio", "news"))

add("www.havencapitalpartners.com", "Haven Capital Partners", "Verified", "Active status on portfolio cards",
    "The site explicitly labels Cognitus Exited. Five cards are labelled Active.",
    """Vision Specialty Contracting
Ascend Safety Collective
Saratoga Compliance Solutions
Human Capital Education
Technology Management Concepts""", hide={"portfolio": "#comp-mmtsn6sz__item-mmtzz3yo"})

add("www.frontlinehcp.com", "Frontline Healthcare Partners", "Verified", "Current Portfolio Companies and Unrealized status in all six card details",
    "Names were taken from the portfolio cards' Learn More dialogs, including cards whose front only displayed the service category.",
    """Bay Area Clinical Associates (BACA)|https://www.baca.org/
CaribouRx (Caribou Systems, Inc.)|https://caribousystems.com
Integracare|https://integracarehomecare.ca/
JoyBridge Kids|https://joybridgekids.com/
LivWell Infusions|https://www.livwellinfusions.com/
Porch Light Health|https://www.frontrangeclinics.com/""")

add("peakline.com", "Peakline Partners", "Partial", "Official investing spotlights and representative properties",
    "The sites disclose selected positions across private capital, venture and real estate. Leasing and construction labels describe asset operations. 303 Crossroads Building 1 was excluded because JLL confirms its 2025 acquisition at https://jllipt.com/resources/news/press-release/jll-income-property-trust-acquires-phoenix-area-industrial-facility.",
    """Project Paprika||Firm reports continuing work after close|https://peakline.com/private-capital/
Enveda Biosciences||Firm names its direct 2024 co-investment|https://peakline.com/venture-capital/
Saronic||Firm marks the logo as a direct co-investment|https://peakline.com/venture-capital/
The Finery||Official representative property with lease-up status|https://peaklinerealestate.com/
The Claire||Fund I property marked Under Construction|https://peaklinerealestate.com/btr/
EDEN Steel Creek||Fund I property marked Under Construction|https://peaklinerealestate.com/btr/
Clarius Park Hardeeville||Funds I and II property marked Under Construction|https://peaklinerealestate.com/logistics/
Fat Village||Fund II property marked Under Construction|https://peaklinerealestate.com/qoz/
Oxford||Fund II property marked Under Construction|https://peaklinerealestate.com/qoz/
Markley + Main||Fund III property marked Under Construction|https://peaklinerealestate.com/qoz/
Stevedore||Fund II property marked Lease Up|https://peaklinerealestate.com/qoz/
Easton Park||Fund II property marked Partially Stabilized|https://peaklinerealestate.com/qoz/
Ace Apartments||Fund III property marked Partially Stabilized|https://peaklinerealestate.com/qoz/
429 Houston||Fund III property marked Partially Stabilized|https://peaklinerealestate.com/qoz/
Fidelis Willis||Fund III property marked Partially Stabilized|https://peaklinerealestate.com/qoz/""",
    stages=("private-capital", "venture-capital", "real-estate", "qoz", "logistics", "build-to-rent"))

add("www.curewellcapital.com", "Curewell Capital", "Verified", "Current status on portfolio card",
    "The public portfolio discloses one holding.",
    "Wilmington PharmaTech|https://www.wilmingtonpharmatech.com/")

add("www.newvalecapital.com", "NewVale Capital", "Verified", "Active status on each selected investment tile",
    "The official website describes the displayed holdings as selected investments. Five tiles are marked Active.",
    """Aizon
Argonaut Manufacturing Services
Beaconcure
CAI
Noxilizer""", stages=("loaded",))

add("www.triple-tree.com", "TripleTree", "No public portfolio", "Firm website and Experience page",
    "This site identifies TripleTree as a healthcare investment bank. Its Experience page lists advisory transactions for clients. The separate TT Capital Partners investor was outside the supplied domain list.", stages=("home", "experience"))

add("www.1585healthcare.com", "1585 Healthcare Capital", "Partial", "Official portfolio listing without status labels",
    "Six names appear on the portfolio page. Current ownership is inferred from the listing. Provide A Ride is additionally supported by the deal advisor's dated release.",
    """Healthtek Solutions
Madison RCM
Accendo
Sunset Park Community Services
Alpine Care Home Health
Provide A Ride||Acquisition confirmed by transaction advisor|https://www.kroll.com/en/transactions/sell-side-advisor-provide-a-ride""")

add("www.epilogpartners.com", "Epilog Partners", "Partial", "Investor-issued announcement and recent SEC filing",
    "The firm's own site provides a contact address. Its release calls Care Connectors its third platform. The identities and current status of the other platform investments were not established.",
    "Care Connectors Medical Group||Named acquisition and investment vehicle in September 2026 filing|https://www.sec.gov/Archives/edgar/data/1372807/000119312526456879/R9.htm",
    stages=("home", "investment-announcement"))

add("www.couragecap.com", "Courage Capital Management", "No public portfolio", "Healthcare and Music strategy pages",
    "Both strategies describe their mandates. The official pages do not identify current companies or individual music-rights positions.", stages=("healthcare", "music"))

add("www.cuegrowthpartners.com", "CUE Growth Partners", "Partial", "Public company funding announcements and firm strategy pages",
    "The site does not provide a current holdings list. Field Medical is named in a co-led funding announcement. Amplitude Vascular Systems was acquired by Stryker.",
    "Field Medical|https://www.fieldmedicalinc.com/|Firm announced the co-led Series B in 2025|https://www.linkedin.com/posts/cue-growth-partners_field-medical-closes-oversubscribed-35-million-activity-7346585267492859904-w-Iu",
    stages=("about", "focus", "field-announcement"))

add("www.cedarinvestors.com", "Cedar Investors", "Partial", "Official Partnerships section",
    "The site describes three current partnerships without disclosing legal names. The descriptive labels are retained.",
    """Veterinary Services (unnamed Pacific Northwest general-practice hospital network)
Mental Health (unnamed group serving public-sector workers and veterans)
Dental Services (unnamed Eastern U.S. specialty dental support organization)""",
    stages=("strategy", "about"))

add("aphias.com", "Aphias Capital", "Partial", "Official News & Insights investment announcement",
    "The homepage distinguishes former-employer experience. The firm's news page announces one named strategic growth investment without a current portfolio index.",
    "SNZweig||Official announcement of strategic growth investment", stages=("news",))

add("www.invidiacap.com", "Invidia Capital Management", "Verified", "Official portfolio and matching official transaction announcements",
    "The two investments listed on the firm's portfolio are supported by current firm news.",
    """Now Optics
WIN (WINFertility)""", stages=("portfolio", "news"))

add("lincolnlibertycapital.com", "Lincoln Liberty Capital", "Verified", "Official Our Investments section",
    "One company appears in the firm's investment section. The firm also announced its deal with the company.",
    "P&A Group|https://www.padmin.com/", stages=("portfolio",))

add("www.silverminegrowth.com", "Silvermine Growth Partners", "No public portfolio", "Official website review",
    "The supplied website displays a Coming Soon page with no holdings.", stages=("home",))

add("newmoon-capital.com", "Newmoon Capital", "No public portfolio", "Official website and About and Approach sections",
    "The website describes the strategy and team without a named investment list.", stages=("home", "about", "approach"))

add("parkrd.com", "Park Road Partners", "No public portfolio", "Official site review",
    "The public landing page has contact and limited-partner login links and no named holdings.", stages=("home",))

boomerang = source_html("www.3boomerang.com", "current")
boomerang_rows = [{"name": t["data-title"], "url": t.get("data-website", ""), "status": "Current filter"}
                  for t in boomerang.select(".port-listing[data-status='Current']")]
assert len(boomerang_rows) == 5
add("www.3boomerang.com", "3 Boomerang Capital", "Verified", "Current filter and tile status metadata",
    "Five tiles have the Current status. Prior investments are described as prior-firm experience.",
    boomerang_rows, stages=("current",), hide={"current": ".port-listing[data-status='Prior']"})

finalize()
