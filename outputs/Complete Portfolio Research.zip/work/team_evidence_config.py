import json
from pathlib import Path
from urllib.parse import urlparse

work = Path(__file__).resolve().parent
raw = work / "batch-d" / "raw"
config = {}
for domain in ("www.decheng.com", "www.ewhealthcare.com"):
    seen = set()
    config[domain] = []
    metadata = json.loads((raw / domain / "team.json").read_text(encoding="utf-8"))
    for label, url in metadata["links"]:
        path = urlparse(url).path.strip("/")
        if domain == "www.decheng.com":
            if not path.endswith(".html") or path in {"team.html", "index.html", "news.html", "portfolio.html", "contact.html"}:
                continue
        elif not path.startswith("team/"):
            continue
        slug = path.rsplit("/", 1)[-1].removesuffix(".html")
        if slug in seen:
            continue
        seen.add(slug)
        config[domain].append({"id": "bio-" + slug, "url": url})
    if domain == "www.ewhealthcare.com":
        config[domain].extend([{"id": "news", "url": "https://ewhealthcare.com/news/"}, {"id": "portfolio", "url": "https://ewhealthcare.com/portfolio/"}])
    else:
        config[domain].extend([{"id": "news", "url": "https://www.decheng.com/news.html"}, {"id": "portfolio", "url": "https://www.decheng.com/portfolio.html"}])
(work / "team-bio-config.json").write_text(json.dumps(config), encoding="utf-8")
