import html
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

import openpyxl
from bs4 import BeautifulSoup

WORK = Path(__file__).resolve().parent
OUT = WORK.parent / "outputs"
firms = json.loads((WORK / "portfolio-data.json").read_text(encoding="utf-8"))


def comparable(value):
    text = unicodedata.normalize("NFKD", html.unescape(value)).casefold()
    return re.sub(r"[^a-z0-9]+", "", text)


archive = OUT / "Portfolio HTML Backups.zip"
unmatched = []
with ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    entries = set(zipped.namelist())
    index = BeautifulSoup(zipped.read("index.html"), "html.parser")
    assert len(index.select("tbody tr")) == len(firms)
    for firm in firms:
        company_evidence = []
        for backup in firm["backups"]:
            if backup not in entries:
                raise ValueError(f"Missing archive member: {backup}")
            data = zipped.read(backup).decode("utf-8-sig", errors="replace")
            soup = BeautifulSoup(data, "html.parser")
            for item in soup.select("script:not([type='application/json']),iframe"):
                item.decompose()
            company_evidence.append(comparable(soup.get_text(" ", strip=True)))
            company_evidence.append(comparable(" ".join(node.get("alt", "") for node in soup.find_all("img"))))
        evidence = " ".join(company_evidence)
        for investment in firm["investments"]:
            if comparable(investment["name"]) not in evidence:
                unmatched.append((firm["domain"], investment["name"], firm["backups"]))

workbook = openpyxl.load_workbook(OUT / "Current and Active Investments.xlsx", read_only=False, data_only=True)
assert workbook.sheetnames == ["Active Investments", "Website Coverage"]
active, coverage = workbook.worksheets
assert active.freeze_panes == coverage.freeze_panes == "A5"
assert len(active.tables) == len(coverage.tables) == 1
expected_counts = {firm["domain"]: len(firm["investments"]) for firm in firms}
observed_counts = Counter()
for row in active.iter_rows(min_row=5, values_only=True):
    investor, name, evidence, source, detail, domain = row
    assert investor and name and evidence and source and domain in expected_counts
    observed_counts[domain] += 1
for row in coverage.iter_rows(min_row=5, values_only=True):
    domain, _, _, count, *_ = row
    assert domain in expected_counts and count == expected_counts[domain] == observed_counts[domain]
assert coverage.max_row == len(firms) + 4
assert active.max_row == sum(expected_counts.values()) + 4
print(f"{len(firms)} coverage rows, {active.max_row - 4} investment rows, {len(entries)} archive members")
print(f"{len(unmatched)} names need manual comparison with archive markup")
for unmatched_row in unmatched[:45]:
    print(unmatched_row)
